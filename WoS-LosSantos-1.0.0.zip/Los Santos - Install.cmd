@echo off
rem Builds Los Santos from your GTA San Andreas + Web of Shadows files and installs it (exWoS\SA_ls_full).
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0WoS_LosSantos\scripts\Install.ps1" %*
echo.
pause
