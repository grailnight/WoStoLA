@echo off
rem Starts Web of Shadows with Los Santos (a normal launch stays New York). Errors appear in a message box.
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0WoS_LosSantos\scripts\Play.ps1"
