@echo off
rem Removes the built Los Santos map (exWoS\SA_ls_full) and its exWoS.config.ini entry.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0WoS_LosSantos\scripts\Uninstall.ps1" %*
echo.
pause
