# Los Santos for Spider-Man: Web of Shadows - installer.
# Builds the map from YOUR GTA San Andreas and Web of Shadows files (nothing
# from either game ships in this package), then installs it as the exWoS mod
# folder SA_ls_full. Run "Los Santos - Install.cmd" from the game folder.
param(
    [string]$SaPath = '',
    [switch]$KeepWork,
    [switch]$Yes
)
. (Join-Path $PSScriptRoot 'common.ps1')

function Fail([string]$Message) {
    Write-Host ''
    Write-Host "ERROR: $Message" -ForegroundColor Red
    exit 1
}

function Ask([string]$Question) {
    if ($Yes) { return $true }
    $r = Read-Host "$Question [y/N]"
    return ($r -match '^\s*(y|yes)\s*$')
}

function Step([string]$Text) { Write-Host ''; Write-Host "== $Text" -ForegroundColor Cyan }

function Find-SanAndreas {
    $list = New-Object System.Collections.Generic.List[string]
    foreach ($key in @('HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam')) {
        $steam = $null
        try {
            $p = Get-ItemProperty -Path $key -ErrorAction Stop
            if ($p.SteamPath) { $steam = $p.SteamPath } elseif ($p.InstallPath) { $steam = $p.InstallPath }
        } catch {}
        if (-not $steam) { continue }
        $libs = @($steam)
        $vdf = Join-Path $steam 'steamapps\libraryfolders.vdf'
        if (Test-Path -LiteralPath $vdf) {
            foreach ($m in [regex]::Matches([IO.File]::ReadAllText($vdf), '"path"\s+"([^"]+)"')) {
                $libs += $m.Groups[1].Value.Replace('\\', '\')
            }
        }
        foreach ($l in $libs) { $list.Add((Join-Path $l 'steamapps\common\Grand Theft Auto San Andreas')) }
    }
    foreach ($key in @('HKLM:\SOFTWARE\WOW6432Node\Rockstar Games\GTA San Andreas\Installation',
                       'HKLM:\SOFTWARE\Rockstar Games\GTA San Andreas\Installation')) {
        try {
            $p = Get-ItemProperty -Path $key -ErrorAction Stop
            if ($p.ExePath) { $list.Add((Split-Path -Parent $p.ExePath.Trim('"'))) }
        } catch {}
    }
    foreach ($d in @("${env:ProgramFiles(x86)}\Rockstar Games\GTA San Andreas",
                     "${env:ProgramFiles(x86)}\GTA San Andreas",
                     "$env:ProgramFiles\Rockstar Games\GTA San Andreas",
                     'C:\Games\GTA San Andreas')) { $list.Add($d) }
    $seen = @{}
    foreach ($d in $list) {
        if (-not $d) { continue }
        $full = [IO.Path]::GetFullPath($d)
        if ($seen.ContainsKey($full.ToLowerInvariant())) { continue }
        $seen[$full.ToLowerInvariant()] = $true
        if (Test-SanAndreas $full) { $full }
    }
}

function Test-SanAndreas([string]$Dir) {
    return (Test-Path -LiteralPath (Join-Path $Dir 'models\gta3.img')) -and
           (Test-Path -LiteralPath (Join-Path $Dir 'data\gta.dat'))
}

function Select-SanAndreas {
    $found = @(Find-SanAndreas)
    if ($found.Count -gt 0) {
        Write-Host 'Found GTA San Andreas:'
        for ($i = 0; $i -lt $found.Count; $i++) { Write-Host ("  [{0}] {1}" -f ($i + 1), $found[$i]) }
        if ($Yes) { return $found[0] }
        $r = Read-Host 'Number to use, or Enter for 1, or 0 to pick another folder'
        if ($r -eq '') { return $found[0] }
        $n = 0
        if ([int]::TryParse($r, [ref]$n) -and $n -ge 1 -and $n -le $found.Count) { return $found[$n - 1] }
    }
    Write-Host 'Select the GTA San Andreas folder (the one that has models\gta3.img).'
    try {
        Add-Type -AssemblyName System.Windows.Forms
        $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
        $dlg.Description = 'GTA San Andreas folder (with models\gta3.img)'
        if ($dlg.ShowDialog() -eq [Windows.Forms.DialogResult]::OK) { return $dlg.SelectedPath }
    } catch {}
    return (Read-Host 'GTA San Andreas folder')
}

Write-Host 'Los Santos for Spider-Man: Web of Shadows - installer' -ForegroundColor White

Step 'Checking Web of Shadows'
if (-not (Test-Path -LiteralPath $GameExe)) {
    Fail "No 'Spider-Man Web of Shadows.exe' next to the WoS_LosSantos folder. Extract the package INTO the game folder and run 'Los Santos - Install.cmd' from there."
}
if (Test-GameRunning) { Fail 'Web of Shadows is running. Close the game and run the installer again.' }
$info = Get-ExeInfo $GameExe
if ($null -eq $info) { Fail "$GameExe is not a valid Windows program." }
if ($info.Identity -ne $ExeIdentity) {
    Fail ("This 'Spider-Man Web of Shadows.exe' is not the PC version 1.1 (1.1.77076) build the map loader was made for " +
          "(identity $($info.Identity.Substring(0, 12))...). Other builds are not supported.")
}
Write-Host 'Game EXE: version 1.1 (1.1.77076).'
if (-not (Test-Path -LiteralPath $ExWoSConfig) -or -not (Test-Path -LiteralPath (Join-Path $GameDir 'ex_WoS.dll'))) {
    Fail 'exWoS (the Web of Shadows mod loader) is not installed: exWoS\exWoS.config.ini or ex_WoS.dll is missing. Install exWoS first, then run this installer again.'
}
foreach ($f in @('bin\SA_CollisionLoader.dll', 'bin\inject.exe', 'tools\ls_builder.py', 'data\city.ini', 'collision_loader\foundation_profile.h')) {
    if (-not (Test-Path -LiteralPath (Join-Path $ModDir $f))) { Fail "The package is incomplete: WoS_LosSantos\$f is missing. Extract the whole archive again." }
}
foreach ($d in @($GameDir, $ExWoSDir, $ModDir)) {
    if (-not (Test-Writable $d)) {
        Fail "Cannot write to $d. A game under 'Program Files' needs the installer run as administrator (right-click 'Los Santos - Install.cmd'), or move the game to another folder."
    }
}
$prev = Restore-Session
if ($prev) { Write-Host 'exWoS.config.ini values from an interrupted Los Santos session were put back.' }
# Asked now, applied only after a successful build.
$patchLaa = $false
if (-not $info.Laa) {
    Write-Host 'The EXE is not Large Address Aware (no "4 GB patch"). Los Santos needs more than 2 GB of memory and the game will run out without it.' -ForegroundColor Yellow
    if (Ask 'Set the Large Address Aware flag after the build (a backup of the EXE is kept)?') {
        try {
            $fs = [IO.File]::Open($GameExe, [IO.FileMode]::Open, [IO.FileAccess]::ReadWrite, [IO.FileShare]::Read)
            $fs.Dispose()
        } catch {
            Fail "Cannot write to $GameExe ($($_.Exception.Message)). Run the installer as administrator, or answer N."
        }
        $patchLaa = $true
    } else {
        Write-Host 'Continuing without it; expect crashes in Los Santos.' -ForegroundColor Yellow
    }
}

Step 'Checking Python'
$python = Find-Python
if (-not $python) {
    if ($PythonNote) { Write-Host "Not usable: $PythonNote." -ForegroundColor Yellow }
    Fail 'A 64-bit Python 3.10 or newer was not found. Install it from https://www.python.org/downloads/ (the "Windows installer (64-bit)"; tick "Add python.exe to PATH" or keep the "py" launcher), then run this installer again.'
}
Write-Host "Python: $python"
$r = Invoke-Native $python @('-c', 'import PIL, numpy, shapely')
if ($r.Code -ne 0) {
    Write-Host 'The build needs the Python packages pillow, numpy and shapely.' -ForegroundColor Yellow
    if (-not (Ask 'Install them now with pip (for your user only)?')) { Fail 'Python packages missing: pillow numpy shapely.' }
    & $python -m pip install --user pillow numpy shapely
    $r = Invoke-Native $python @('-c', 'import PIL, numpy, shapely')
    if ($r.Code -ne 0) { Fail "pip did not make pillow, numpy and shapely importable. Try: `"$python`" -m pip install --user pillow numpy shapely" }
}

Step 'Finding GTA San Andreas'
if (-not $SaPath) { $SaPath = Select-SanAndreas }
# "Copy as path" adds quotes; a trailing \ would escape the closing quote of
# the argument handed to Python.
$SaPath = ([string]$SaPath).Trim().Trim('"').Trim()
if ($SaPath -match '^[A-Za-z]:[\\/]?$') { $SaPath = $SaPath.Substring(0, 2) + '\.' }
elseif ($SaPath.Length -gt 3) { $SaPath = $SaPath.TrimEnd('\', '/') }
if (-not $SaPath -or -not (Test-SanAndreas $SaPath)) {
    Fail "'$SaPath' is not a GTA San Andreas folder (models\gta3.img and data\gta.dat are needed). The Definitive Edition is not supported."
}
Write-Host "GTA San Andreas: $SaPath"

$drive = New-Object IO.DriveInfo ([IO.Path]::GetPathRoot($GameDir))
if ($drive.AvailableFreeSpace -lt 4GB) {
    Fail ("The build needs about 4 GB free on {0} (free: {1:N1} GB)." -f $drive.Name, ($drive.AvailableFreeSpace / 1GB))
}

Step 'Building Los Santos (about 5-10 minutes)'
$builderArgs = @('-B', (Join-Path $ModDir 'tools\ls_builder.py'), '--sa', $SaPath, '--game', $GameDir)
if ($KeepWork) { $builderArgs += '--keep-work' }
$old = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
& $python @builderArgs
$code = $LASTEXITCODE
$ErrorActionPreference = $old
if ($code -ne 0) { Fail "The build stopped (exit $code). Nothing was installed; the reason is printed above." }
$stage = Join-Path $ModDir ('work\stage\' + $ProfileName)
if (-not (Test-Path -LiteralPath (Join-Path $stage 'sa_runtime\world.bin'))) { Fail "The build reported success but $stage is incomplete." }

Step 'Installing'
if (Test-GameRunning) { Fail "Web of Shadows was started during the build. Close it and run the installer again (the build is kept in $stage)." }
New-Item -ItemType Directory -Force -Path $BackupDir | Out-Null
$stamp = Get-Stamp
if ($patchLaa) {
    $copy = Join-Path $BackupDir ('Spider-Man Web of Shadows.exe.' + $stamp + '.bak')
    Copy-Item -LiteralPath $GameExe -Destination $copy
    # one byte: the Characteristics flags of the PE header
    $fs = [IO.File]::Open($GameExe, [IO.FileMode]::Open, [IO.FileAccess]::ReadWrite, [IO.FileShare]::Read)
    try {
        [void]$fs.Seek($info.PeOffset + 22, [IO.SeekOrigin]::Begin)
        $fs.WriteByte([byte]($info.Characteristics -bor 0x20))
    } finally { $fs.Dispose() }
    $check = Get-ExeInfo $GameExe
    if (-not $check.Laa -or $check.Identity -ne $ExeIdentity) {
        Copy-Item -LiteralPath $copy -Destination $GameExe -Force
        Fail 'Setting the Large Address Aware flag failed; the EXE was put back.'
    }
    Write-Host "Large Address Aware flag set. Original EXE: $copy"
}
# The previous build is replaced, not kept: it is rebuilt from the same files.
$previous = $null
if (Test-Path -LiteralPath $ProfileDir) {
    $previous = Join-Path $ModDir "work\previous_$ProfileName"
    if (Test-Path -LiteralPath $previous) { Remove-Item -LiteralPath $previous -Recurse -Force }
    Move-Item -LiteralPath $ProfileDir -Destination $previous
}
try {
    Move-Item -LiteralPath $stage -Destination $ProfileDir
} catch {
    if ($previous) { Move-Item -LiteralPath $previous -Destination $ProfileDir }
    Fail "Could not move the new map into exWoS ($($_.Exception.Message)); the previous one was put back."
}
if ($previous) {
    Remove-Item -LiteralPath $previous -Recurse -Force
    Write-Host "Replaced the previous exWoS\$ProfileName."
}
Copy-Item -LiteralPath $ExWoSConfig -Destination (Join-Path $BackupDir "exWoS.config.ini.$stamp")
# Off by default: "Los Santos - Play.cmd" switches it on for its own session
# only, so a normal launch is still plain New York.
Set-ModEntries $ExWoSConfig @{ $ProfileName = '0' }
Write-Host "Installed exWoS\$ProfileName (registered as $ProfileName=0 in exWoS.config.ini)."

if (Test-Path -LiteralPath $WosTweaksDir) {
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $TeleportFile) | Out-Null
    $clear = Join-Path $ProfileDir 'teleports\sa_ground_clear.txt'
    if (-not (Test-Path -LiteralPath $TeleportFile) -and (Test-Path -LiteralPath $clear)) {
        $p = ([IO.File]::ReadAllText($clear)).Trim() -split '\s+'
        $y = [double]::Parse($p[1], [Globalization.CultureInfo]::InvariantCulture) + 3.0
        $line = '{0} {1} {2}' -f $p[0], $y.ToString([Globalization.CultureInfo]::InvariantCulture), $p[2]
        [IO.File]::WriteAllText($TeleportFile, $line + "`r`n")
        [IO.File]::WriteAllText((Join-Path $BackupDir 'teleport_added.txt'), $TeleportFile)
        Write-Host "WOSTweaks teleport preset 'Los Santos' added."
    }
}

$work = Join-Path $ModDir 'work'
if (-not $KeepWork -and (Test-Path -LiteralPath $work)) { Remove-Item -LiteralPath $work -Recurse -Force }

Write-Host ''
Write-Host 'Done.' -ForegroundColor Green
Write-Host "Play: double-click 'Los Santos - Play.cmd' (a normal launch stays New York)."
Write-Host "Then load a save and teleport with WOSTweaks to the 'Los Santos' preset."
Write-Host 'Remove: Los Santos - Uninstall.cmd'
