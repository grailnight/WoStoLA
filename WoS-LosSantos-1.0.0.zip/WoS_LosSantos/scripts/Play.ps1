# Los Santos for Spider-Man: Web of Shadows - start the game with the map.
# Switches exWoS\SA_ls_full on (and mods replacing the same files off) for this
# session only, starts the game, loads SA_CollisionLoader.dll into it and puts
# the replaced exWoS.config.ini values back when the game exits; after a crash
# the next run does it (bin\session.json). Run "Los Santos - Play.cmd".
. (Join-Path $PSScriptRoot 'common.ps1')

$dll = Join-Path $ModDir 'bin\SA_CollisionLoader.dll'
$injector = Join-Path $ModDir 'bin\inject.exe'
$loaderLog = Join-Path $ModDir 'bin\collision_loader.log'
$runLog = Join-Path $ModDir 'bin\play.log'
$session = $false
$original = @{}
$game = $null
$failure = $null
$mutex = $null

function Log([string]$Text) { "$(Get-Date -Format o) $Text" | Add-Content -LiteralPath $runLog }

# The DLL logs "<pid> READY" as the last step of DllMain, so a zero exit from
# inject.exe already means READY. inject waits 15 s for LoadLibrary; when that
# runs out (cold disk, antivirus scan) the load may still finish, so look for
# the line in what the log gained since the launch.
function Wait-Ready([int]$ProcessId, [long]$Offset, [int]$Seconds) {
    $pattern = '(?m)^' + $ProcessId + ' READY '
    $deadline = [DateTime]::UtcNow.AddSeconds($Seconds)
    while ([DateTime]::UtcNow -lt $deadline) {
        try {
            $fs = New-Object IO.FileStream($loaderLog, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
            try {
                if ($fs.Length -gt $Offset) {
                    [void]$fs.Seek($Offset, [IO.SeekOrigin]::Begin)
                    $buf = New-Object byte[] ($fs.Length - $Offset)
                    $n = $fs.Read($buf, 0, $buf.Length)
                    if ([Text.Encoding]::ASCII.GetString($buf, 0, $n) -match $pattern) { return $true }
                }
            } finally { $fs.Dispose() }
        } catch {}
        if ($game.HasExited) { return $false }
        Start-Sleep -Milliseconds 250
    }
    return $false
}

try {
    $created = $false
    $m = [Threading.Mutex]::new($true, 'Local\WoS_LosSantos_Play', [ref]$created)
    if (-not $created) { $m.Dispose(); throw 'Los Santos is already being started.' }
    $mutex = $m
    if (Test-GameRunning) { throw 'Web of Shadows is already running. Close it, then use "Los Santos - Play.cmd" to start it with the map.' }
    $prev = Restore-Session
    if ($prev) { Log "previous session's exWoS.config.ini values put back ($prev)" }
    foreach ($f in @($GameExe, $dll, $injector, $ExWoSConfig,
                     (Join-Path $ProfileDir 'sa_runtime\world.bin'),
                     (Join-Path $ProfileDir 'sa_runtime\textures.bin'),
                     (Join-Path $ProfileDir 'L23\0x0001D211.L23.scgpc'))) {
        if (-not (Test-Path -LiteralPath $f)) { throw "Missing $f. Run ""Los Santos - Install.cmd"" first." }
    }
    if ((Test-Path -LiteralPath $loaderLog) -and (Get-Item -LiteralPath $loaderLog).Length -gt 8MB) {
        Move-Item -LiteralPath $loaderLog -Destination "$loaderLog.old" -Force
    }

    # Other enabled mods that replace the same files would win over the map.
    $conflicts = @(Get-ChildItem -LiteralPath $ExWoSDir -Directory | Where-Object {
        $_.Name -ne $ProfileName -and (Get-ModValue $ExWoSConfig $_.Name) -notin @($null, '', '0') -and
        (Get-ChildItem -LiteralPath $_.FullName -Recurse -File -ErrorAction SilentlyContinue | Where-Object {
            $_.Name -like '0xD9CB2AAA.*' -or $_.Name -like '0xD9CB2AAB.*' -or
            $_.Name -like '0x0001D211.*' -or $_.Name -like '*.megacity.pcapk'
        } | Select-Object -First 1)
    } | ForEach-Object { [string]$_.Name })

    $values = @{ $ProfileName = '1' }
    foreach ($c in $conflicts) { $values[$c] = '0' }
    foreach ($k in $values.Keys) { $original[$k] = Get-ModValue $ExWoSConfig $k }
    Write-Session 0 0 $original
    $session = $true
    Set-ModEntries $ExWoSConfig $values
    if ($conflicts.Count) { Log "switched off for this session (same files): $($conflicts -join ', ')" }

    $logOffset = 0L
    if (Test-Path -LiteralPath $loaderLog) { $logOffset = (Get-Item -LiteralPath $loaderLog).Length }
    $si = New-Object Diagnostics.ProcessStartInfo $GameExe
    $si.WorkingDirectory = $GameDir
    $si.UseShellExecute = $true
    $game = [Diagnostics.Process]::Start($si)
    if ($null -eq $game) { throw 'Windows did not start the game.' }
    $ticks = 0L
    try { $ticks = $game.StartTime.ToUniversalTime().Ticks } catch {}
    Write-Session $game.Id $ticks $original
    Log "started pid=$($game.Id)"

    # A process this young can refuse the module snapshot (inject exit 2): retry.
    $r = $null
    for ($try = 0; $try -lt 20; $try++) {
        $r = Invoke-Native $injector @([string]$game.Id, $dll)
        if ($r.Code -ne 2 -or $game.HasExited) { break }
        Start-Sleep -Milliseconds 250
    }
    $r.Output | ForEach-Object { Log "inject: $_" }
    $ready = $r.Code -eq 0
    if (-not $ready -and $r.Code -eq 7 -and (($r.Output -join ' ') -match 'wait=258')) {
        Log 'inject timed out waiting for LoadLibrary; watching the loader log'
        $ready = Wait-Ready $game.Id $logOffset 60
    }
    if (-not $ready) {
        throw "The map loader did not start (inject exit $($r.Code)). The game was closed so it does not run with half of the map; see $loaderLog."
    }
    Log "READY pid=$($game.Id)"
    $game.WaitForExit()
    Log "game exited (code $($game.ExitCode))"
} catch {
    $failure = $_.ToString()
    Log "ERROR: $failure"
    if ($game -and -not $game.HasExited) {
        try { $game.Kill(); [void]$game.WaitForExit(10000); Log 'game closed' } catch { Log "could not close the game: $_" }
    }
} finally {
    if ($session) {
        try {
            if ($game -and -not $game.HasExited) {
                Log 'game still running; exWoS.config.ini is put back by the next Play/Install/Uninstall'
            } else {
                if ($original.Count) { Set-ModEntries $ExWoSConfig $original }
                Remove-Item -LiteralPath $SessionFile -Force -ErrorAction SilentlyContinue
                Log 'exWoS.config.ini values put back'
            }
        } catch { Log "could not put exWoS.config.ini back: $_ (the next run retries)" }
    }
    if ($mutex) { $mutex.ReleaseMutex(); $mutex.Dispose() }
}
if ($failure) { Show-Message $failure 'Los Santos' }
