# Los Santos for Spider-Man: Web of Shadows - remove the built map.
# Deletes exWoS\SA_ls_full and its exWoS.config.ini line, the WOSTweaks
# preset this package added, and the build leftovers. The package files
# themselves (WoS_LosSantos and the three .cmd files) are left for you to delete.
param([switch]$Yes)
. (Join-Path $PSScriptRoot 'common.ps1')

if (Test-GameRunning) {
    Write-Host 'ERROR: Web of Shadows is running. Close it first.' -ForegroundColor Red
    exit 1
}
if (-not $Yes) {
    $r = Read-Host "Remove Los Santos (exWoS\$ProfileName) from this game? [y/N]"
    if ($r -notmatch '^\s*(y|yes)\s*$') { Write-Host 'Nothing changed.'; exit 0 }
}
if (Restore-Session) { Write-Host 'exWoS.config.ini values from an interrupted Los Santos session were put back.' }
if (Test-Path -LiteralPath $ProfileDir) {
    Remove-Item -LiteralPath $ProfileDir -Recurse -Force
    Write-Host "Removed exWoS\$ProfileName"
}
if (Test-Path -LiteralPath $ExWoSConfig) {
    if ($null -ne (Get-ModValue $ExWoSConfig $ProfileName)) {
        New-Item -ItemType Directory -Force -Path $BackupDir | Out-Null
        Copy-Item -LiteralPath $ExWoSConfig -Destination (Join-Path $BackupDir ('exWoS.config.ini.' + (Get-Stamp)))
        Set-ModEntries $ExWoSConfig @{ $ProfileName = $null }
        Write-Host "Removed $ProfileName from exWoS.config.ini"
    }
}
$marker = Join-Path $BackupDir 'teleport_added.txt'
if ((Test-Path -LiteralPath $marker) -and (Test-Path -LiteralPath $TeleportFile)) {
    Remove-Item -LiteralPath $TeleportFile -Force
    Remove-Item -LiteralPath $marker -Force
    Write-Host "Removed the WOSTweaks preset 'Los Santos'"
}
foreach ($d in @('work', 'out')) {
    $p = Join-Path $ModDir $d
    if (Test-Path -LiteralPath $p) { Remove-Item -LiteralPath $p -Recurse -Force }
}
Write-Host ''
Write-Host 'Done. To remove the package itself, delete the WoS_LosSantos folder and the three "Los Santos - *.cmd" files.'
if (Test-Path -LiteralPath $BackupDir) { Write-Host "Backups made during install (the EXE before the 4 GB flag, exWoS.config.ini) are in $BackupDir." }
