# Shared by Install.ps1, Play.ps1 and Uninstall.ps1 (dot-sourced). Windows PowerShell 5.1.
$ErrorActionPreference = 'Stop'

$ModDir = Split-Path -Parent $PSScriptRoot           # <game>\WoS_LosSantos
$GameDir = Split-Path -Parent $ModDir                 # <game>
$GameExe = Join-Path $GameDir 'Spider-Man Web of Shadows.exe'
$GameProcessName = 'Spider-Man Web of Shadows'
$ProfileName = 'SA_ls_full'
$ExWoSDir = Join-Path $GameDir 'exWoS'
$ExWoSConfig = Join-Path $ExWoSDir 'exWoS.config.ini'
$ProfileDir = Join-Path $ExWoSDir $ProfileName
$BackupDir = Join-Path $ModDir 'backup'
$WosTweaksDir = Join-Path $GameDir 'WOSTweaks'
$TeleportFile = Join-Path $WosTweaksDir 'locationSave\Los Santos.txt'
$SessionFile = Join-Path $ModDir 'bin\session.json'

# SHA-256 of Spider-Man Web of Shadows.exe 1.1 (1.1.77076) with the Large
# Address Aware bit and the PE checksum cleared: a 4 GB patch changes only
# those, so stock and patched copies give the same value. The map DLL patches
# code at fixed addresses of exactly this build.
$ExeIdentity = '947541de6ba35dc1933854df3e53da169b5774d45ba85d042f90887377e0eac6'

function Get-Stamp { Get-Date -Format 'yyyyMMdd_HHmmss' }

function Test-GameRunning {
    return [bool](Get-Process -Name $GameProcessName -ErrorAction SilentlyContinue)
}

function Get-ExeInfo([string]$Path) {
    $b = [IO.File]::ReadAllBytes($Path)
    if ($b.Length -lt 0x400) { return $null }
    $pe = [BitConverter]::ToInt32($b, 60)
    if ($pe -lt 0 -or ($pe + 92) -gt $b.Length) { return $null }
    if ($b[$pe] -ne 0x50 -or $b[$pe + 1] -ne 0x45 -or $b[$pe + 2] -ne 0 -or $b[$pe + 3] -ne 0) { return $null }
    $laa = ($b[$pe + 22] -band 0x20) -ne 0
    $c = [byte[]]$b.Clone()
    $c[$pe + 22] = [byte]($c[$pe + 22] -band 0xDF)
    for ($i = 88; $i -lt 92; $i++) { $c[$pe + $i] = 0 }
    $sha = [Security.Cryptography.SHA256]::Create()
    $hex = ([BitConverter]::ToString($sha.ComputeHash($c))).Replace('-', '').ToLowerInvariant()
    return @{ Laa = $laa; Identity = $hex; PeOffset = $pe; Characteristics = $b[$pe + 22] }
}

# True when a file can be created in $Dir (a game under Program Files is
# read-only without administrator rights).
function Test-Writable([string]$Dir) {
    $probe = Join-Path $Dir ('.ls_write_test_' + [Guid]::NewGuid().ToString('N'))
    try {
        [IO.File]::WriteAllText($probe, 'x')
        [IO.File]::Delete($probe)
        return $true
    } catch {
        return $false
    }
}

function Test-SameBytes([byte[]]$A, [byte[]]$B) {
    return [Convert]::ToBase64String($A) -eq [Convert]::ToBase64String($B)
}

# exWoS reads its config through the ANSI profile API, so mod names in it are
# ANSI bytes. Decode the same way when that round-trips exactly (UTF-8 when the
# file has a BOM); otherwise Latin-1, which keeps every byte. Only ASCII keys
# are ever edited, so lines we do not touch are written back unchanged.
function Read-TextFile([string]$Path) {
    $bytes = [IO.File]::ReadAllBytes($Path)
    $bom = $bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF
    $skip = 0
    if ($bom) { $skip = 3 }
    $body = New-Object byte[] ($bytes.Length - $skip)
    [Array]::Copy($bytes, $skip, $body, 0, $body.Length)
    $enc = [Text.Encoding]::Default
    if ($bom) { $enc = New-Object Text.UTF8Encoding($false) }
    $text = $enc.GetString($body)
    if (-not (Test-SameBytes $enc.GetBytes($text) $body)) {
        $enc = [Text.Encoding]::GetEncoding(28591)
        $text = $enc.GetString($body)
    }
    $nl = "`n"
    if ($text.Contains("`r`n")) { $nl = "`r`n" }
    return @{ Text = $text; Bom = $bom; Encoding = $enc; NewLine = $nl }
}

# Writes beside the file first, then swaps it in, so a crash never leaves a
# half-written config.
function Write-TextFile([string]$Path, [string]$Text, [bool]$Bom, [Text.Encoding]$Encoding) {
    $body = $Encoding.GetBytes($Text)
    $bytes = $body
    if ($Bom) {
        $bytes = New-Object byte[] ($body.Length + 3)
        $bytes[0] = 0xEF; $bytes[1] = 0xBB; $bytes[2] = 0xBF
        [Array]::Copy($body, 0, $bytes, 3, $body.Length)
    }
    $tmp = "$Path.ls_tmp"
    [IO.File]::WriteAllBytes($tmp, $bytes)
    try {
        [IO.File]::Replace($tmp, $Path, [NullString]::Value)
    } catch {
        [IO.File]::WriteAllBytes($Path, $bytes)
        Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
    }
}

function Test-ModsHeader([string]$Line) { return $Line.Trim() -match '^\[\s*mods\s*\]' }

# Set (or with $null remove) keys in the [mods] section of exWoS.config.ini.
# Other lines, their order, line endings and the encoding are kept.
function Set-ModEntries([string]$Path, [hashtable]$Values) {
    $f = Read-TextFile $Path
    $lines = New-Object System.Collections.Generic.List[string]
    foreach ($l in ($f.Text -split "`n")) { $lines.Add($l) }
    $cr = ''
    if ($f.NewLine -eq "`r`n") { $cr = "`r" }
    $start = -1; $end = $lines.Count
    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ($lines[$i].Trim().StartsWith('[')) {
            if ($start -ge 0) { $end = $i; break }
            if (Test-ModsHeader $lines[$i]) { $start = $i }
        }
    }
    if ($start -lt 0) {
        if ($lines.Count -gt 0 -and $lines[$lines.Count - 1].Trim() -ne '') { $lines.Add($cr) }
        $lines.Add('[mods]' + $cr)
        $start = $lines.Count - 1
        $end = $lines.Count
    }
    foreach ($key in $Values.Keys) {
        $pattern = '^\s*' + [regex]::Escape($key) + '\s*='
        $found = -1
        for ($i = $start + 1; $i -lt $end; $i++) {
            if ($lines[$i] -match $pattern) { $found = $i; break }
        }
        $value = $Values[$key]
        if ($null -eq $value) {
            if ($found -ge 0) { $lines.RemoveAt($found); $end-- }
            continue
        }
        $tail = ''
        if ($found -ge 0) {
            if ($lines[$found].EndsWith("`r")) { $tail = "`r" }
            $lines[$found] = "$key=$value" + $tail
        } else {
            $lines.Insert($start + 1, "$key=$value" + $cr)
            $end++
        }
    }
    Write-TextFile $Path ([string]::Join("`n", $lines)) $f.Bom $f.Encoding
}

function Get-ModValue([string]$Path, [string]$Key) {
    $inMods = $false
    foreach ($l in ((Read-TextFile $Path).Text -split "`n")) {
        $t = $l.Trim()
        if ($t.StartsWith('[')) { $inMods = Test-ModsHeader $t; continue }
        if ($inMods -and $t -match ('^' + [regex]::Escape($Key) + '\s*=\s*(\S*)')) { return $Matches[1] }
    }
    return $null
}

# Play.ps1 switches mods for one session and first writes the values it
# replaces to bin\session.json. Whatever ends the session (game crash, power
# loss, a killed script), the next run of Play, Install or Uninstall puts those
# values back. -> 'running' (the session's game is still open), 'restored' or $null.
function Restore-Session {
    if (-not (Test-Path -LiteralPath $SessionFile)) { return $null }
    $s = $null
    try { $s = [IO.File]::ReadAllText($SessionFile) | ConvertFrom-Json } catch {}
    if ($null -ne $s -and $s.ProcessId) {
        $p = Get-Process -Id ([int]$s.ProcessId) -ErrorAction SilentlyContinue
        if ($p -and $p.ProcessName -eq $GameProcessName) {
            $same = $true
            try { $same = $p.StartTime.ToUniversalTime().Ticks -eq [long]$s.StartTicks } catch {}
            if ($same) { return 'running' }
        }
    }
    if ($null -ne $s -and $null -ne $s.Values -and (Test-Path -LiteralPath $ExWoSConfig)) {
        $values = @{}
        foreach ($prop in $s.Values.PSObject.Properties) { $values[[string]$prop.Name] = $prop.Value }
        if ($values.Count) { Set-ModEntries $ExWoSConfig $values }
    }
    Remove-Item -LiteralPath $SessionFile -Force
    return 'restored'
}

function Write-Session([int]$ProcessId, [long]$StartTicks, [hashtable]$Original) {
    $o = [ordered]@{ ProcessId = $ProcessId; StartTicks = [string]$StartTicks; Values = $Original }
    [IO.File]::WriteAllText($SessionFile, (ConvertTo-Json -InputObject $o -Depth 3))
}

# Run a native command without PowerShell 5.1 turning its stderr into errors.
function Invoke-Native([string]$Exe, [string[]]$Arguments) {
    $old = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        $out = & $Exe @Arguments 2>$null
        return @{ Code = $LASTEXITCODE; Output = @($out) }
    } catch {
        return @{ Code = -1; Output = @() }
    } finally {
        $ErrorActionPreference = $old
    }
}

# -> full path of a 64-bit Python 3.10+ (the build needs several GB), or $null;
# $script:PythonNote then says what was found instead. The path comes back
# hex-encoded: a console pipe would mangle a user folder like C:\Users\Иван.
function Find-Python {
    $script:PythonNote = ''
    $probe = "import sys, struct; print('%d %d %d' % (sys.version_info[0], sys.version_info[1], struct.calcsize('P') * 8)); print(sys.executable.encode('utf-8', 'surrogatepass').hex())"
    foreach ($c in @(@('py', '-3'), @('python'), @('python3'))) {
        if (-not (Get-Command $c[0] -ErrorAction SilentlyContinue)) { continue }
        $args_ = @()
        if ($c.Count -gt 1) { $args_ = $c[1..($c.Count - 1)] }
        $r = Invoke-Native $c[0] ($args_ + @('-c', $probe))
        if ($r.Code -ne 0 -or $r.Output.Count -lt 2) { continue }
        $v = ([string]$r.Output[0]).Trim() -split ' '
        $hex = ([string]$r.Output[1]).Trim()
        if ($v.Count -ne 3 -or $hex -notmatch '^([0-9a-f]{2})+$') { continue }
        $raw = New-Object byte[] ($hex.Length / 2)
        for ($i = 0; $i -lt $raw.Length; $i++) { $raw[$i] = [Convert]::ToByte($hex.Substring($i * 2, 2), 16) }
        $exe = [Text.Encoding]::UTF8.GetString($raw)
        if (-not (Test-Path -LiteralPath $exe)) { continue }
        if ([int]$v[0] -ne 3 -or [int]$v[1] -lt 10) {
            $script:PythonNote = "found Python $($v[0]).$($v[1]) at $exe (3.10 or newer is needed)"
            continue
        }
        if ([int]$v[2] -ne 64) {
            $script:PythonNote = "found 32-bit Python $($v[0]).$($v[1]) at $exe (the 64-bit version is needed)"
            continue
        }
        return $exe
    }
    return $null
}

# A message box in front of everything (a fullscreen game included).
function Show-Message([string]$Text, [string]$Title) {
    Add-Type -AssemblyName System.Windows.Forms
    [Windows.Forms.MessageBox]::Show($Text, $Title, [Windows.Forms.MessageBoxButtons]::OK,
        [Windows.Forms.MessageBoxIcon]::Warning, [Windows.Forms.MessageBoxDefaultButton]::Button1,
        [Windows.Forms.MessageBoxOptions]::DefaultDesktopOnly) | Out-Null
}
