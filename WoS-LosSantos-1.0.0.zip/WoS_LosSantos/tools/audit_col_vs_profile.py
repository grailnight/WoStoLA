"""Compare the FoundationBuildings collision profile with real SA COL data.

For a grid of X/Z points across the district, cast a vertical ray down through
the district instances' COL geometry (faces + boxes, instance-transformed into
WoS world space) and through the profile's type-4 boxes, and report how far
the walkable top surfaces disagree. Read-only; writes a JSON report.
"""
import glob
import json
import math
import os
import sys

import build_district_foundation as F
import build_sa_world as W
import sa_col

REPORT = W.OUT / 'collision_research' / 'col_vs_profile.json'
STEP = 5.0


def load_col_index(col_dir):
    index = {}
    for path in glob.glob(os.path.join(glob.escape(col_dir), '*.col')):
        models, _ = sa_col.read_col(path)
        for m in models:
            index.setdefault(m.name.lower(), m)
    return index


def world_triangles(inst, col, shift):
    m = W.sa_bake.quat_matrix(inst['rot'], conjugate=True)

    def to_world(v):
        p = W.sa_bake.sa_to_wos(W.sa_bake.transform(m, inst['pos'], v))
        return tuple(p[k] + shift[k] for k in range(3))

    verts = [to_world(v) for v in col.vertices]
    # sa_to_wos is a reflection since 2026-09-30: reversing every triangle keeps
    # the facing conventions built on the old rotation (col_layers.is_up).
    tris = [(verts[a], verts[c], verts[b]) for a, b, c in col.faces]
    for box in col.boxes:
        lo, hi = box['min'], box['max']
        c = [to_world((x, y, z)) for x in (lo[0], hi[0])
             for y in (lo[1], hi[1]) for z in (lo[2], hi[2])]
        # 12 triangles of the box, corner index = 4*ix + 2*iy + iz
        for q in ((0, 1, 3, 2), (4, 5, 7, 6), (0, 1, 5, 4),
                  (2, 3, 7, 6), (0, 2, 6, 4), (1, 3, 7, 5)):
            tris.append((c[q[0]], c[q[2]], c[q[1]]))
            tris.append((c[q[0]], c[q[3]], c[q[2]]))
    return tris


def ray_down(tris, x, z, top=1e9):
    """Highest triangle Y at (x, z) below `top`, or None."""
    best = None
    for a, b, c in tris:
        if (x < min(a[0], b[0], c[0]) or x > max(a[0], b[0], c[0]) or
                z < min(a[2], b[2], c[2]) or z > max(a[2], b[2], c[2])):
            continue
        d = (b[2] - c[2]) * (a[0] - c[0]) + (c[0] - b[0]) * (a[2] - c[2])
        if abs(d) < 1e-9:
            continue
        l1 = ((b[2] - c[2]) * (x - c[0]) + (c[0] - b[0]) * (z - c[2])) / d
        l2 = ((c[2] - a[2]) * (x - c[0]) + (a[0] - c[0]) * (z - c[2])) / d
        l3 = 1 - l1 - l2
        if min(l1, l2, l3) < -1e-6:
            continue
        y = l1 * a[1] + l2 * b[1] + l3 * c[1]
        if y <= top and (best is None or y > best):
            best = y
    return best


def main():
    source = W.OUT / 'SA_district_TexturesV3'
    manifest = json.loads((source / 'manifest.json').read_text())
    shift = tuple(manifest['world_shift'])
    area = manifest['model_bounds']
    instances, _ = W.sa_ipl.load_world(W.M.SA_DIR, W.M.IDE_ROOT)
    selected = [i for i in instances
                if W.sa_bake.in_region(i, F.DISTRICT_CENTRE, F.DISTRICT_RADIUS)]
    cols = load_col_index(W.M.SA_DIR)
    tris, missing = [], set()
    for inst in selected:
        col = cols.get(inst['model'].lower())
        if col is None:
            missing.add(inst['model'])
            continue
        tris += world_triangles(inst, col, shift)

    building = F.load_building_boxes(shift)
    ground = F.ground_grid_boxes(area, building)
    boxes = building + ground

    def profile_top(x, z):
        tops = [hi[1] for lo, hi in boxes
                if lo[0] <= x <= hi[0] and lo[2] <= z <= hi[2]]
        return max(tops) if tops else None

    rows = []
    x = area[0][0] + STEP / 2
    while x < area[1][0]:
        z = area[0][2] + STEP / 2
        while z < area[1][2]:
            rows.append((x, z, ray_down(tris, x, z), profile_top(x, z)))
            z += STEP
        x += STEP

    both = [(x, z, c, p) for x, z, c, p in rows if c is not None and p is not None]
    diffs = sorted(p - c for _, _, c, p in both)
    no_col = sum(1 for r in rows if r[2] is None)

    def frac(pred):
        return round(sum(1 for d in diffs if pred(d)) / max(len(diffs), 1), 3)

    probe = (621.7128295898438, 1671.733642578125)
    report = {
        'instances': len(selected),
        'col_missing_models': sorted(missing),
        'col_triangles': len(tris),
        'profile_boxes': len(boxes),
        'samples': len(rows),
        'samples_without_col_surface': no_col,
        'top_diff_profile_minus_col': {
            'median': diffs[len(diffs) // 2] if diffs else None,
            'within_0_5m': frac(lambda d: abs(d) <= 0.5),
            'within_2m': frac(lambda d: abs(d) <= 2),
            'profile_above_by_2m_plus': frac(lambda d: d > 2),
            'profile_below_by_2m_plus': frac(lambda d: d < -2),
        },
        'sa_ground_clear': {
            'col_surface_y': ray_down(tris, *probe),
            'profile_top_y': profile_top(*probe),
            'teleport_y': 11.612644501496106,
        },
    }
    REPORT.write_text(json.dumps(report, indent=2))
    json.dump(report, sys.stdout, indent=2)


if __name__ == '__main__':
    main()
