"""Append district collision boxes to L23, rebuild grid and quantized
broadphase.

Preserves native leaves, convex offsets and original grid eligibility. The
default box set (--shape col) is a height field of the district's real SA COL
geometry (col_heightfield_boxes.py); --shape dff keeps the older per-instance
DFF AABBs, whose tops sat a median 11 m above the real surfaces. The tree has
any depth, and collision_loader/foundation_profile.h is rewritten with the
constants the DLL checks this scene against, so rebuild the DLL after this.
"""
import hashlib
import json
import math
from pathlib import Path
import shutil
import struct
import build_sa_world as W
from build_native_box_probe import build_visible_control_mesh
import sa_hulls
import scgpc_box

CONTROL_RECORD_OFFSET=0x1108
CONTROL_TREE_OFFSET=0x1ae0
CONTROL_LEAF_OFFSET=CONTROL_RECORD_OFFSET-0x80
CONTROL_CENTER_Y=2.5  # only with --raise-native-box (old diagnostic)
NATIVE_CENTER_Y=-0.7
FOUNDATION_BOUNDARY_PROBE=(640.57,5.0,1809.44)
DISTRICT_CENTRE=(1500.0,-1700.0)
DISTRICT_RADIUS=150.0
BUILDING_BOX_LIMIT=300
BUILDING_MIN_SIZE=1.0
MAX_BOX_HALF_EXTENT=65.0  # scgpc_box's uint16 encoding caps half extent ~70m
GROUND_GRID_SIZE=10


def ground_grid_boxes(area,reference_boxes,grid=GROUND_GRID_SIZE):
    """Floor tiles across the whole district footprint so the street BETWEEN
    buildings is not a void (building AABBs only cover their own footprint).

    Height is NOT one flat plane: the district's terrain is not flat (a tile
    near buildings whose base sits at Y=10 is not at the same street height
    as a tile near buildings based at Y=0), so a single global constant put
    the ground under the visible street at one spot and above it at another.
    Each tile instead takes the base height (lowest point) of whichever real
    instance's centre is nearest that tile -- a real nearby object actually
    resting on that stretch of street is a far better estimate than a
    district-wide minimum.
    """
    samples=[((lo[0]+hi[0])/2,(lo[2]+hi[2])/2,lo[1]) for lo,hi in reference_boxes]
    boxes=[]
    for ix in range(grid):
        for iz in range(grid):
            x0=area[0][0]+(area[1][0]-area[0][0])*ix/grid
            x1=area[0][0]+(area[1][0]-area[0][0])*(ix+1)/grid
            z0=area[0][2]+(area[1][2]-area[0][2])*iz/grid
            z1=area[0][2]+(area[1][2]-area[0][2])*(iz+1)/grid
            cx=(x0+x1)/2;cz=(z0+z1)/2
            ground_y=min(samples,key=lambda s:(s[0]-cx)**2+(s[1]-cz)**2)[2]
            boxes.append(((x0,ground_y-2.0,z0),(x1,ground_y,z1)))
    return boxes


def clear_ground_teleport(building_boxes,ground_boxes,area):
    """Choose a ground tile centre with no building AABB above it."""
    cx=(area[0][0]+area[1][0])/2
    cz=(area[0][2]+area[1][2])/2
    candidates=[]
    for lo,hi in ground_boxes:
        x=(lo[0]+hi[0])/2
        z=(lo[2]+hi[2])/2
        if any(a[0]<=x<=b[0] and a[2]<=z<=b[2]
               for a,b in building_boxes):
            continue
        candidates.append(((x-cx)**2+(z-cz)**2,(x,hi[1]+2,z)))
    if not candidates:
        raise ValueError('no clear ground tile for collision probe')
    return min(candidates)[1]


HEIGHT_PERCENTILE=99.0  # clip antenna/spire vertices, keep the walkable bulk


def robust_instance_box(inst,model,shift,percentile=HEIGHT_PERCENTILE):
    """Like sa_hulls.instance_box, but the model-local up axis (SA Z, which
    becomes WoS world Y after the axis swap) is clipped to a vertex-count
    percentile instead of the true max.

    A single box per instance already loses shape detail (sa_hulls' own
    docstring: "loses overhangs, arches"); the one that actually broke a walk
    test was a thin spike -- an antenna or flagpole represented by a handful
    of vertices -- stretching the WHOLE footprint's box up to the spike's
    height, so the player stood on invisible air over the real, much lower,
    roof. Trimming to where 99% of the model's own vertices already are
    keeps the real roof height and drops only that spike's collision (which
    nothing needs -- nobody was walking on the antenna either way). X/Z stay
    exact: those axes are the footprint outline, not a candidate for a
    single-vertex outlier the way a vertical mast is.
    """
    verts=[v for g in model['geometries'] for v in g.vertices]
    if len(verts)<50:  # too few points for a percentile to mean anything
        return sa_hulls.instance_box(inst,model,shift)
    lo=[min(v[k] for v in verts) for k in range(3)]
    hi=[max(v[k] for v in verts) for k in range(3)]
    up=sorted(v[2] for v in verts)
    n=len(up)
    cut=int(n*(1-percentile/100))
    hi[2]=up[n-1-cut] if cut>0 else up[-1]
    m=W.sa_bake.quat_matrix(inst['rot'],conjugate=True)
    wlo=[float('inf')]*3;whi=[float('-inf')]*3
    for cx in (lo[0],hi[0]):
        for cy in (lo[1],hi[1]):
            for cz in (lo[2],hi[2]):
                p=W.sa_bake.sa_to_wos(W.sa_bake.transform(m,inst['pos'],(cx,cy,cz)))
                for k in range(3):
                    wlo[k]=min(wlo[k],p[k]);whi[k]=max(whi[k],p[k])
    return ([wlo[k]+shift[k] for k in range(3)],[whi[k]+shift[k] for k in range(3)])


def load_building_boxes(shift,limit=BUILDING_BOX_LIMIT,min_size=BUILDING_MIN_SIZE):
    """Real per-instance AABBs for every SA object baked into this district.

    Same instance selection and world shift as the district's render geometry
    (build_sa_world.py, scope=district), so a box lands under the model it
    belongs to instead of a flat placeholder. Biggest volume first, capped by
    `limit` so the generated leaf count stays inside the tree's 8-way group
    budget (see the `8<len(groups)<=64` assertion in build()).
    """
    instances,_=W.sa_ipl.load_world(W.M.SA_DIR,W.M.IDE_ROOT)
    selected=[i for i in instances if W.sa_bake.in_region(i,DISTRICT_CENTRE,DISTRICT_RADIUS)]
    cache=W.sa_bake.ModelCache(W.M.SA_DIR)
    boxes=[]
    for inst in selected:
        model=cache.get(inst.get('model'))
        if model is None:continue
        box=robust_instance_box(inst,model,shift)
        if box is None:continue
        lo,hi=box
        if max(hi[k]-lo[k] for k in range(3))<min_size:continue
        for k in range(3):
            pad=sa_hulls.MIN_THICKNESS-(hi[k]-lo[k])
            if pad>0:
                lo[k]-=pad/2;hi[k]+=pad/2
            # scgpc_box's uint16 half-extent encoding tops out at ~70m; clamp
            # instead of rejecting so the biggest (most visible) objects still
            # get a box, just not one that covers their full footprint.
            if hi[k]-lo[k]>2*MAX_BOX_HALF_EXTENT:
                centre_k=(hi[k]+lo[k])/2
                lo[k]=centre_k-MAX_BOX_HALF_EXTENT;hi[k]=centre_k+MAX_BOX_HALF_EXTENT
        volume=1.0
        for k in range(3):volume*=max(hi[k]-lo[k],sa_hulls.MIN_THICKNESS)
        boxes.append((volume,tuple(lo),tuple(hi)))
    boxes.sort(key=lambda b:-b[0])
    return [(lo,hi) for _,lo,hi in boxes[:limit]]

def morton(xz):
    x,z=(max(0,min(0xffff,v+32768)) for v in xz)
    r=0
    for i in range(16):r|=((x>>i)&1)<<(2*i)|((z>>i)&1)<<(2*i+1)
    return r


def eight_way_tree(entries):
    """Blocks of an 8-way quantized tree, root first, leaf blocks last.

    `entries` are (q[6], payload_offset) leaves. Internal entries carry the
    union of their children's quantized extents and the child block's byte
    offset from the tree base (block index * 128). FUN_007933B0 walks this
    with a (node, level) queue down to metadata depth, so depth is free; the
    depth is the number of block levels above the leaf blocks.
    """
    def union(group):return [max(q[k] for q,_ in group) for k in range(6)]
    levels=[[entries[i:i+8] for i in range(0,len(entries),8)]]
    while len(levels[0])>1:
        children=levels[0]
        levels.insert(0,[[(union(c),None) for c in children[i:i+8]]
                         for i in range(0,len(children),8)])
    # assign block indices top-down, then patch child pointers
    blocks=[];first=[]
    for level in levels:
        first.append(len(blocks));blocks.extend(level)
    for li in range(len(levels)-1):
        child_index=first[li+1]
        for bi in range(first[li],first[li]+len(levels[li])):
            patched=[]
            for q,_ in blocks[bi]:
                patched.append((q,child_index*128));child_index+=1
            blocks[bi]=patched
    return blocks,len(levels)-1

def u32(b,o):return struct.unpack_from('<I',b,o)[0]
def vec(b,o):return struct.unpack_from('<3f',b,o)
def put(b,o,fmt,*v):struct.pack_into('<'+fmt,b,o,*v)
def align(b,n=128):b.extend(bytes([0xa1])*((-len(b))%n))

def raise_control_box(original,target_y=CONTROL_CENTER_Y):
    """Raise the retained native type-4 control box to the probe height.

    The native box is part of the source leaf/index set, so its payload and
    quantized leaf bounds must move together.  This mirrors the standalone
    NativeBox probe and intentionally changes only the box Y and its two
    serialized Y quantizers.
    """
    assert len(original)==7864 and u32(original,0x24)==91
    result=bytearray(original)
    center,half=scgpc_box.decode(result[CONTROL_RECORD_OFFSET:CONTROL_RECORD_OFFSET+48])
    assert abs(center[0]+300)<.001 and abs(center[2]-1515.0001220703125)<.001
    if abs(center[1]-target_y)<.001:
        return bytes(result)
    assert abs(center[1]+.7)<.001
    scale=struct.unpack_from('<f',original,0x1e14)[0]
    low,high=struct.unpack_from('<2h',original,CONTROL_TREE_OFFSET+4)
    shift=target_y-center[1]
    new_low=math.ceil(low-shift*scale)
    new_high=math.ceil(high+shift*scale)
    assert -32768<=new_low<=32767 and -32768<=new_high<=32767
    put(result,CONTROL_RECORD_OFFSET+0x18,'f',target_y)
    put(result,CONTROL_TREE_OFFSET+4,'2h',new_low,new_high)
    changed=(set(range(CONTROL_RECORD_OFFSET+0x18,CONTROL_RECORD_OFFSET+0x1c)) |
             set(range(CONTROL_TREE_OFFSET+4,CONTROL_TREE_OFFSET+8)))
    assert all(a==b for i,(a,b) in enumerate(zip(original,result)) if i not in changed)
    return bytes(result)

def build(original,building_boxes,control_y=NATIVE_CENTER_Y):
    assert len(original)==7864 and u32(original,0x24)==91
    source=raise_control_box(original,control_y)
    center,scale=vec(source,0x1e00),vec(source,0x1e10)
    leaves=[]
    # 0x1680..0x1800 are two internal levels, NOT leaf records.
    for off in range(0x1800,0x1db0,16):
        q=struct.unpack_from('<6h',source,off)
        lo=tuple(center[k]-q[k*2]/scale[k] for k in range(3))
        hi=tuple(center[k]+q[k*2+1]/scale[k] for k in range(3))
        leaves.append((u32(source,off+12),lo,hi))
    eligible=set()
    for i in range(16):
        rel=struct.unpack_from('<i',source,0x1488+i*4)[0]
        if not rel:continue
        pos=0x1428+rel
        assert source[pos]&127==2
        for v in struct.unpack_from(f'<{source[pos+1]}i',source,pos+4):eligible.add(pos+v-0x80)
    assert CONTROL_LEAF_OFFSET in eligible
    b=bytearray(source[:0x1428])
    boxes=[]
    # Each generated record is one real SA instance's world-space AABB
    # (building or other baked object), not a flat placeholder tile.
    template=source[CONTROL_RECORD_OFFSET:CONTROL_RECORD_OFFSET+48]
    # Records in Morton order too: the DLL's owned tree groups them by record
    # ordinal, so this keeps its blocks compact as well.
    x0=min(lo[0] for lo,_ in building_boxes);z0=min(lo[2] for lo,_ in building_boxes)
    building_boxes=sorted(building_boxes,key=lambda b:morton((
        int(((b[0][0]+b[1][0])/2-x0)*4)-32768,int(((b[0][2]+b[1][2])/2-z0)*4)-32768)))
    for blo,bhi in building_boxes:
        centre=tuple((blo[k]+bhi[k])/2 for k in range(3))
        half=tuple((bhi[k]-blo[k])/2+.02 for k in range(3))
        raw=scgpc_box.create(template,centre,half)
        c,h=scgpc_box.decode(raw)
        # Preserve opaque native metadata; its field semantics are not
        # established, so do not invent material/name identifiers here.
        lo=tuple(c[k]-h[k] for k in range(3));hi=tuple(c[k]+h[k] for k in range(3))
        offset=len(b)-0x80;b.extend(raw)
        leaves.append((offset,tuple(x-.1 for x in lo),tuple(x+.1 for x in hi)))
        eligible.add(offset);boxes.append({'offset':offset,'lo':lo,'hi':hi})
    lo=tuple(min(x[1][k] for x in leaves)-.1 for k in range(3))
    hi=tuple(max(x[2][k] for x in leaves)+.1 for k in range(3))
    extent=tuple(hi[k]-lo[k] for k in range(3))
    grid=len(b);b.extend(source[0x1428:0x1488])
    # A cell's static_leaf_list stores its member count in one byte, so the
    # grid gets finer (power of two, row shift log2) until every cell fits.
    def cell_members(side):
        cells={}
        for off,a,z in leaves:
            if off not in eligible:continue
            x0=max(0,int((a[0]-lo[0])/extent[0]*side));x1=min(side-1,int((z[0]-lo[0])/extent[0]*side))
            z0=max(0,int((a[2]-lo[2])/extent[2]*side));z1=min(side-1,int((z[2]-lo[2])/extent[2]*side))
            for iz in range(z0,z1+1):
                for ix in range(x0,x1+1):cells.setdefault(iz*side+ix,[]).append(off)
        return cells
    for shift in range(4,10):  # 512 x 512 since the fine (1 m) wall boxes, 2026-10-03
        side=1<<shift
        memberships=cell_members(side)
        if max(len(v) for v in memberships.values())<256:break
    else:raise AssertionError('grid cells overflow even at 512x512')
    put(b,grid+8,'I',0x60)
    for o,v in ((12,lo),(24,hi),(36,extent),(48,tuple(v/side for v in extent)),
                (60,tuple(1/v for v in extent)),(72,tuple(v*(1-1/(2*side)) for v in extent))):put(b,grid+o,'3f',*v)
    put(b,grid+84,'3I',side,shift,1)
    table=len(b);b.extend(bytes(side*side*4))
    for iz in range(side):
        for ix in range(side):
            members=memberships.setdefault(iz*side+ix,[])
            if not members:continue
            assert len(members)<256
            start=len(b);put(b,table+(iz*side+ix)*4,'i',start-grid)
            b.extend(struct.pack('<I',2+len(members)*256))
            b.extend(struct.pack(f'<{len(members)}i',*(off+0x80-start for off in members)))
    align(b);quant=len(b)
    qc=tuple((lo[k]+hi[k])/2 for k in range(3))
    qh=tuple(extent[k]/2+20 for k in range(3));qs=tuple(32767/v for v in qh)
    # Quantize against the floats actually serialized, not Python doubles.
    qc=struct.unpack('<3f',struct.pack('<3f',*qc));qs=struct.unpack('<3f',struct.pack('<3f',*qs))
    encoded=[]
    for off,a,z in leaves:
        q=[math.ceil(v) for k in range(3) for v in ((qc[k]-a[k])*qs[k],(z[k]-qc[k])*qs[k])]
        assert all(-32767<=v<=32767 for v in q)
        encoded.append((q,off))
    # Leaves in Morton order of their centres, so each 8-way block (and every
    # parent above it) bounds a compact patch instead of a raster stripe.
    encoded.sort(key=lambda e:morton(tuple((e[0][2*k+1]-e[0][2*k])//2 for k in (0,2))))
    blocks,depth=eight_way_tree(encoded)
    for group in blocks:
        for q,off in group:b.extend(struct.pack('<6hI',*q,off))
        for _ in range(8-len(group)):b.extend(struct.pack('<6hI',*([-32767]*6),0xffffffff))
    meta=len(b);b.extend(source[0x1e00:0x1e40])
    put(b,meta,'3f',*qc);put(b,meta+16,'3f',*qs);put(b,meta+32,'3f',*qh)
    put(b,meta+48,'I',quant-0x80);put(b,meta+60,'I',depth)
    align(b);outer=len(b);b.extend(source[0x1e80:])
    put(b,outer+0x14,'3f',*qc);put(b,outer+0x2c,'3f',*(v/2 for v in extent))
    put(b,8,'I',len(b));put(b,0x14,'I',grid-0x80)
    put(b,0x24,'I',len(leaves));put(b,0x2c,'I',meta-0x80)
    # All native leaf payloads, including the eight external convex references,
    # remain byte-identical and at their original offsets.
    assert b[0x80:0x1428]==source[0x80:0x1428]
    for off,a,z in leaves:
        assert b[off+0x80]&127 in (4,5,6,7,8,9,15)
    for box in boxes:
        for x in (box['lo'][0]+.001,box['hi'][0]-.001):
            for z in (box['lo'][2]+.001,box['hi'][2]-.001):
                cell=int((x-lo[0])/extent[0]*side)+side*int((z-lo[2])/extent[2]*side)
                assert box['offset'] in memberships[cell]
    control_center,control_half=scgpc_box.decode(source[CONTROL_RECORD_OFFSET:CONTROL_RECORD_OFFSET+48])
    control_lo=tuple(control_center[k]-control_half[k] for k in range(3))
    control_hi=tuple(control_center[k]+control_half[k] for k in range(3))
    control_q=next(q for q,off in encoded if off==CONTROL_LEAF_OFFSET)
    control_tree_lo=tuple(qc[k]-control_q[2*k]/qs[k] for k in range(3))
    control_tree_hi=tuple(qc[k]+control_q[2*k+1]/qs[k] for k in range(3))
    control_cells=[cell for cell,members in memberships.items() if CONTROL_LEAF_OFFSET in members]
    assert abs(control_center[1]-control_y)<.001 and control_cells
    for k in range(3):
        assert control_tree_lo[k]<=control_lo[k]+1e-5
        assert control_tree_hi[k]>=control_hi[k]-1e-5
    native_control={'offset':CONTROL_LEAF_OFFSET,'record_offset':CONTROL_RECORD_OFFSET,
                    'center':control_center,'half':control_half,'lo':control_lo,'hi':control_hi,
                    'tree_lo':control_tree_lo,'tree_hi':control_tree_hi,'grid_cells':control_cells}
    return bytes(b),{'boxes':boxes,'native_control':native_control,'grid_offset':grid,
                     'quant_offset':quant,'meta_offset':meta,'outer_offset':outer,
                     'leaf_count':len(leaves),'bytes':len(b),'tree_depth':depth,
                     'tree_blocks':len(blocks)}

PROFILE_HEADER=Path(__file__).resolve().parents[1]/'collision_loader'/'foundation_profile.h'


def write_profile_header(path,scene,info,native_offset,profile):
    """Constants the collision DLL checks the installed SCGPC against."""
    first=min(x['offset'] for x in info['boxes'])
    count=len(info['boxes'])
    assert [x['offset'] for x in info['boxes']]==[first+48*i for i in range(count)]
    text=f"""#pragma once
// Generated by tools/build_district_foundation.py for {profile}. Do not edit.
// scene_sha256={hashlib.sha256(scene).hexdigest()}
#include <cstddef>
#include <cstdint>
constexpr size_t foundation_scene_size={len(scene)};
constexpr uint32_t foundation_leaf_count={info['leaf_count']};
constexpr uint32_t foundation_native_box_offset=0x{native_offset:x};
constexpr uint32_t foundation_first_box_offset=0x{first:x};
constexpr uint32_t foundation_box_stride=0x30;
constexpr uint32_t foundation_box_count={count};
constexpr uint32_t foundation_grid_offset={info['grid_offset']};
constexpr uint32_t foundation_quant_offset={info['quant_offset']};
constexpr uint32_t foundation_meta_offset={info['meta_offset']};
constexpr uint32_t foundation_scene_tree_depth={info['tree_depth']};
constexpr wchar_t foundation_profile_name[]=L"{profile}";
"""
    path.write_text(text,encoding='utf-8')


def main():
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--shape',choices=('col','dff'),default='col')
    parser.add_argument('--profile',default='SA_district_FoundationCOL')
    parser.add_argument('--cell',type=float,default=2.0)
    parser.add_argument('--step',type=float,default=0.25)
    parser.add_argument('--raise-native-box',action='store_true',
                        help='lift the native L23 floor box at sa_native_box to top Y=3 (old diagnostic)')
    args=parser.parse_args()
    source=W.OUT/'SA_district_TexturesV3';root=W.OUT/args.profile
    if root.exists():raise SystemExit('profile exists')
    manifest=json.loads((source/'manifest.json').read_text())
    original=(W.OUT/'collision_research/L23/type_74_0001D211.bin').read_bytes()
    shift=tuple(manifest['world_shift'])
    area=manifest['model_bounds']
    if args.shape=='col':
        import col_heightfield_boxes as C
        boxes,heights=C.build_boxes(area,args.cell,args.step,shift=shift)
        ground_clear_teleport=C.street_teleport(heights,area,args.cell)
        description=(f'{len(boxes)} type-4 boxes from a 2.5D height field of the district SA '
                     f'COL faces and boxes ({args.cell} m cells, {args.step} m height steps); '
                     'overhangs and interiors are solid')
    else:
        building_boxes=load_building_boxes(shift)
        if not building_boxes:raise SystemExit('no building instances found in district region')
        ground_boxes=ground_grid_boxes(area,building_boxes)
        ground_clear_teleport=clear_ground_teleport(building_boxes,ground_boxes,area)
        boxes=building_boxes+ground_boxes
        description=(f'{len(boxes)} type-4 boxes: {len(building_boxes)} DFF-derived per-instance '
                     f'AABBs plus {len(ground_boxes)} ground tiles')
    print(description)
    control_y=CONTROL_CENTER_Y if args.raise_native_box else NATIVE_CENTER_Y
    if args.raise_native_box:description+='; native control box raised to top Y=3'
    scene,info=build(original,boxes,control_y)
    control=info['native_control']
    native_teleport=(control['center'][0],control['hi'][1]+2,control['center'][2])
    shutil.copytree(source,root)
    if args.raise_native_box:
        marker_blob=build_visible_control_mesh(source,control['center'],control['half'])
        W.write(root/W.PACK/W.RESOURCE,marker_blob)
    else:
        marker_blob=(root/W.PACK/W.RESOURCE).read_bytes()
    if 'carrier_translation' not in manifest:
        # source staged before build_sa_world baked the carrier's placement
        import carrier_offset
        marker_blob=carrier_offset.to_carrier(marker_blob)
        W.write(root/W.PACK/W.RESOURCE,marker_blob)
        manifest['carrier_translation']=list(W.CARRIER_TRANSLATION)
    W.write(root/'L23/0x0001D211.L23.scgpc',scene)
    manifest.update(profile=root.name,collision=description,
                    collision_layout={k:v for k,v in info.items() if k!='boxes'},
                    probes=[{'name':'sa_native_box','teleport':native_teleport},
                            {'name':'sa_ground_clear','teleport':ground_clear_teleport}],
                    runtime_validation='pending',
                    mesh_sha256=hashlib.sha256(marker_blob).hexdigest(),
                    scene_sha256=hashlib.sha256(scene).hexdigest())
    W.write(root/'manifest.json',json.dumps(manifest,indent=2).encode())
    W.write(root/'teleports/sa_native_box.txt',(' '.join(map(str,native_teleport))+'\n').encode())
    W.write(root/'teleports/sa_ground_clear.txt',
            (' '.join(map(str,ground_clear_teleport))+'\n').encode())
    write_profile_header(PROFILE_HEADER,scene,info,CONTROL_LEAF_OFFSET,root.name)
    print(json.dumps({k:v for k,v in info.items() if k not in ('boxes','native_control')},indent=2))
    print('teleport sa_ground_clear',ground_clear_teleport)

if __name__=='__main__':main()
