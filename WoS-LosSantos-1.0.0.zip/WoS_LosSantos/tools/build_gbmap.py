"""Los Santos street graph for Web of Shadows: megacity.gbmap from SA paths.

Pedestrians spawn and walk on the gbmap and traffic drives on it
(wos_gbmap.py has the format). This turns the SA vehicle path graph of the
Los Santos box into one, placed with the SA_ls_full world shift.

    py -3 build_gbmap.py [--profile SA_ls_full] [--png out.png]

Writes out/full_map/<profile>/npc/:
    MEGACITY/0xEE185533.megacity.gbmap
    <REGION>/0x<hash>.<REGION>.traf_lt_infpc   one per region, all empty: the
        shipped ones name New York intersections by index
    gbmap_stats.json

How the SA graph maps onto the gbmap:
  * vertices = SA vehicle nodes (boats excluded), merged within MERGE_M and
    with straight degree-2 runs simplified away (SIMPLIFY_M); y is the SA
    road height, so hills keep their slope;
  * segments carry a profile: lanes are 5 m (fixed in the engine, lanes =
    width / 5). Two-way SA links (1+1 lanes) get a two-way profile. One-way
    links are the carriageways of divided avenues (their path lines run
    ~15 m apart, lanes centred on the line), which is exactly the engine's
    one-way profile; the segment points along the traffic;
  * sidewalks come from corners, one per block turn. A block is a face of
    the street graph (s2 = the next segment CLOCKWISE around the vertex,
    the rule the shipped map follows). Faces narrower than THIN_M (the
    medians between two carriageways, slivers inside big junctions) and the
    outer face get no corners; highways and dead-end branches never do;
  * no traffic lights (node phases 0, segment light groups -1).

Engine buffers sized for New York and never bounds-checked (FUN_005a0f70,
FUN_005910e0): 10000 lanes, 10000 lane-in-region entries, 12000 junction
connections. The build refuses to write past LIMITS.
"""
import argparse
import collections
import json
import math
import struct
from pathlib import Path

import sa_paths
import wos_gbmap as W

TOOLS = Path(__file__).resolve().parent
ARENA = TOOLS.parent
NYC_GBMAP = ARENA / 'out' / 'nav' / 'megacity' / 'megacity_t12.bin'
NYC_TRAFFIC_LIGHTS = ARENA / 'out' / 'nav' / '13'
REGIONS = TOOLS / 'wos_regions.json'
GBMAP_HASH = 0xEE185533

SHIFT = (1000.0, -7.5, 2200.0)      # SA_ls_full, see build_sa_tiles.LS_SHIFT
BOX = (0.0, -2800.0, 3000.0, -500.0)  # SA x0, y0, x1, y1
LANE = 5.0
MERGE_M = 2.5
SIMPLIFY_M = 1.5
SIMPLIFY_Y = 0.75
THIN_M = 24.0        # 2 * area / perimeter of a face (~ its width)
SIDEWALK = 4.8       # the corner code adds 0.2: a 5 m sidewalk
LIMITS = {'lanes': 8500, 'region_lanes': 9000, 'connections': 10500}
HIGHWAY = 1 << 13
BOATS = 1 << 7


def to_wos(p):
    return (p[0] + SHIFT[0], p[2] + SHIFT[1], p[1] + SHIFT[2])


# ---------------------------------------------------------------- SA graph

def sa_graph(areas):
    inside = lambda p: BOX[0] <= p[0] <= BOX[2] and BOX[1] <= p[1] <= BOX[3]
    usable = lambda nd: not nd['ped'] and not nd['flags'] & BOATS and inside(nd['pos'])
    pos, edges = {}, {}
    for aid, (nodes, links, navi, navi_links) in areas.items():
        for nd in nodes:
            if not usable(nd):
                continue
            ka = (aid, nd['node'])
            for j in range(nd['links']):
                la, ln = links[nd['link'] + j]
                if la not in areas or ln >= len(areas[la][0]):
                    continue
                other = areas[la][0][ln]
                if not usable(other):
                    continue
                kb = (la, ln)
                key = (ka, kb) if ka < kb else (kb, ka)
                if key in edges:
                    continue
                lanes, median = (1, 1), 0.0
                na, ni = navi_links[nd['link'] + j]
                if na in areas and ni < len(areas[na][2]):
                    nv = areas[na][2][ni]
                    ex, ey = other['pos'][0] - nd['pos'][0], other['pos'][1] - nd['pos'][1]
                    along = nv['dir'][0] * ex + nv['dir'][1] * ey > 0
                    lanes = (nv['along'], nv['against']) if along else (nv['against'], nv['along'])
                    median = nv['median']
                    if lanes == (0, 0):
                        lanes = (1, 1)
                if ka > kb:
                    lanes = lanes[::-1]
                edges[key] = {'lanes': lanes, 'median': median,
                              'highway': bool(nd['flags'] & other['flags'] & HIGHWAY)}
                pos[ka], pos[kb] = to_wos(nd['pos']), to_wos(other['pos'])
    return pos, edges


def merge_close(pos, edges):
    keys = list(pos)
    parent = {k: k for k in keys}

    def find(k):
        while parent[k] != k:
            parent[k] = parent[parent[k]]
            k = parent[k]
        return k
    grid = collections.defaultdict(list)
    for k in keys:
        p = pos[k]
        grid[(int(p[0] // MERGE_M), int(p[2] // MERGE_M))].append(k)
    for (gx, gz), ks in grid.items():
        for k in ks:
            for dx in (-1, 0, 1):
                for dz in (-1, 0, 1):
                    for o in grid.get((gx + dx, gz + dz), ()):
                        if o != k and math.dist(pos[k], pos[o]) < MERGE_M:
                            parent[find(o)] = find(k)
    groups = collections.defaultdict(list)
    for k in keys:
        groups[find(k)].append(k)
    idx, verts = {}, []
    for root, ks in groups.items():
        for k in ks:
            idx[k] = len(verts)
        verts.append(tuple(sum(pos[k][c] for k in ks) / len(ks) for c in range(3)))
    out = {}
    for (ka, kb), e in edges.items():
        a, b = idx[ka], idx[kb]
        if a == b:
            continue
        lanes = e['lanes'] if a < b else e['lanes'][::-1]
        key = (min(a, b), max(a, b))
        if key not in out or sum(lanes) > sum(out[key]['lanes']):
            out[key] = dict(e, lanes=lanes)
    return verts, out


def simplify(verts, edges):
    """Drop degree-2 vertices on straight runs of one road (Douglas-Peucker)."""
    adj = collections.defaultdict(list)
    for (a, b) in edges:
        adj[a].append(b)
        adj[b].append(a)

    def rel(a, b):
        e = edges[(min(a, b), max(a, b))]
        return (e['lanes'] if a < b else e['lanes'][::-1]), e['median'], e['highway']

    def removable(v):
        if len(adj[v]) != 2:
            return False
        u, w = adj[v]
        return rel(u, v) == rel(v, w)

    def far(p, a, b):
        ax, az, bx, bz = a[0], a[2], b[0], b[2]
        dx, dz = bx - ax, bz - az
        L2 = dx * dx + dz * dz
        t = 0.0 if L2 == 0 else max(0.0, min(1.0, ((p[0] - ax) * dx + (p[2] - az) * dz) / L2))
        qx, qz, qy = ax + t * dx, az + t * dz, a[1] + t * (b[1] - a[1])
        return max(math.hypot(p[0] - qx, p[2] - qz) / SIMPLIFY_M, abs(p[1] - qy) / SIMPLIFY_Y)

    def dp(chain):
        if len(chain) <= 2:
            return chain
        a, b = verts[chain[0]], verts[chain[-1]]
        k, worst = max(((i, far(verts[chain[i]], a, b)) for i in range(1, len(chain) - 1)), key=lambda t: t[1])
        if worst <= 1.0 and chain[0] != chain[-1]:
            return [chain[0], chain[-1]]
        if chain[0] == chain[-1] and worst <= 1.0:
            k = len(chain) // 2
        return dp(chain[:k + 1])[:-1] + dp(chain[k:])

    out, seen = {}, set()
    anchors = [v for v in adj if not removable(v)]
    for start in anchors:
        for nxt in adj[start]:
            if (start, nxt) in seen:
                continue
            chain = [start, nxt]
            while removable(chain[-1]) and chain[-1] != start:
                u, w = adj[chain[-1]]
                chain.append(w if u == chain[-2] else u)
            for i in range(len(chain) - 1):
                seen.add((chain[i], chain[i + 1]))
                seen.add((chain[i + 1], chain[i]))
            lanes, median, highway = rel(chain[0], chain[1])
            kept = dp(chain)
            for a, b in zip(kept, kept[1:]):
                if a == b:
                    continue
                key = (min(a, b), max(a, b))
                out[key] = {'lanes': lanes if a < b else lanes[::-1], 'median': median, 'highway': highway}
    # rings made only of removable vertices have no anchor: keep them whole
    for (a, b), e in edges.items():
        if (a, b) not in seen:
            out[(a, b)] = e
    used = sorted({v for k in out for v in k})
    remap = {v: i for i, v in enumerate(used)}
    return [verts[v] for v in used], {(remap[a], remap[b]): e for (a, b), e in out.items()}


# ---------------------------------------------------------------- gbmap

class Seg:
    __slots__ = ('a', 'b', 'fwd', 'bwd', 'median', 'highway', 'slots', 'prof', 'flags')

    def __init__(self, a, b, fwd, bwd, median, highway):
        self.a, self.b, self.fwd, self.bwd = a, b, fwd, bwd
        self.median, self.highway = median, highway
        self.slots = [0xFFFF] * 4
        self.flags = [0, 0]
        self.prof = 0

    @property
    def oneway(self):
        return not (self.fwd and self.bwd)


def make_segments(edges):
    segs = []
    for (a, b), e in sorted(edges.items()):
        fwd, bwd = e['lanes']
        if fwd == 0 and bwd:          # one-way segments point along the traffic
            a, b, fwd, bwd = b, a, bwd, fwd
        segs.append(Seg(a, b, fwd, bwd, e['median'], e['highway']))
    return segs


def profile_of(s):
    """-> (median half-width, lane width per side, sidewalk, one-way, flags)"""
    walk = 0.0 if s.highway else SIDEWALK
    flags = 3 if s.highway else 2          # bit1 drivable, bit0 no pedestrian spawns
    if s.oneway:
        return (0.0, LANE * max(1, (s.fwd + 1) // 2), walk, 1, flags)
    return (s.median / 2.0, LANE * max(s.fwd, s.bwd), walk, 2, flags)


def lanes_of(s, side):
    """FUN_00589390 for the profiles written here."""
    f0, f4, f8, one, fl = profile_of(s)
    if s.flags[side] & 2:
        return 0
    if one == 1:
        return int(f4 / LANE) * 2 if side == 1 else 0
    return int(f4 / LANE)


def build_faces(verts, segs):
    """Corners for block faces; returns (corners, face stats)."""
    walk = [i for i, s in enumerate(segs) if not s.highway]
    deg = collections.Counter()
    for i in walk:
        deg[segs[i].a] += 1
        deg[segs[i].b] += 1
    alive = set(walk)
    changed = True
    while changed:                          # 2-core: dead ends get no sidewalk
        changed = False
        for i in list(alive):
            s = segs[i]
            if deg[s.a] < 2 or deg[s.b] < 2:
                alive.discard(i)
                deg[s.a] -= 1
                deg[s.b] -= 1
                changed = True
    rot = collections.defaultdict(list)
    for i in alive:
        s = segs[i]
        for v, o in ((s.a, s.b), (s.b, s.a)):
            rot[v].append((math.atan2(verts[o][2] - verts[v][2], verts[o][0] - verts[v][0]), i))
    for v in rot:
        rot[v].sort()
        rot[v] = [i for _, i in rot[v]]
    ends = lambda i, fwd: (segs[i].a, segs[i].b) if fwd else (segs[i].b, segs[i].a)
    seen, faces = set(), []
    for i in alive:
        for fwd in (True, False):
            if (i, fwd) in seen:
                continue
            face, cur = [], (i, fwd)
            while cur not in seen:
                seen.add(cur)
                face.append(cur)
                j, f = cur
                v = ends(j, f)[1]
                r = rot[v]
                nxt = r[(r.index(j) - 1) % len(r)]
                cur = (nxt, segs[nxt].a == v)
            faces.append(face)
    corners, stats = [], collections.Counter()
    for face in faces:
        pts = [verts[ends(j, f)[0]] for j, f in face]
        area = 0.5 * sum(pts[k][0] * pts[(k + 1) % len(pts)][2] - pts[(k + 1) % len(pts)][0] * pts[k][2]
                         for k in range(len(pts)))
        perim = sum(math.dist(pts[k], pts[(k + 1) % len(pts)]) for k in range(len(pts)))
        if area <= 0:
            stats['outer'] += 1
            continue
        if 2 * area / perim < THIN_M:
            stats['thin'] += 1
            continue
        stats['blocks'] += 1
        for k in range(len(face)):
            (j1, f1), (j2, f2) = face[k], face[(k + 1) % len(face)]
            v = ends(j1, f1)[1]
            c = len(corners)
            corners.append((j1, j2, v))
            s1, s2 = segs[j1], segs[j2]
            # s1 arrives at v: side 0 if it ran a->b (slot at b), else side 1 (slot at a)
            s1.slots[2 if s1.b == v else 1] = c
            # s2 leaves v: side 0 if it runs a->b (slot at a), else side 1 (slot at b)
            s2.slots[0 if s2.a == v else 3] = c
    return corners, stats


def region_boxes():
    regs = json.loads(REGIONS.read_text())
    return [(r['center'][0] - 150, r['center'][2] - 150, r['center'][0] + 150, r['center'][2] + 150, r['hash'])
            for r in regs]


def budgets(verts, segs, nodes_of_vertex):
    lanes = sum(lanes_of(s, 0) + lanes_of(s, 1) for s in segs)
    boxes = region_boxes()
    inbox = lambda p: {k for k, (x0, z0, x1, z1, _) in enumerate(boxes) if x0 <= p[0] <= x1 and z0 <= p[2] <= z1}
    region_lanes = 0          # a lane is listed once in every region holding its start or its end
    for s in segs:
        n = lanes_of(s, 0) + lanes_of(s, 1)
        if n:
            region_lanes += n * max(1, len(inbox(verts[s.a]) | inbox(verts[s.b])))
    connections = 0
    at = collections.defaultdict(list)
    for i, s in enumerate(segs):
        at[s.a].append(i)
        at[s.b].append(i)
    for i, s in enumerate(segs):
        for side, v in ((0, s.a), (1, s.b)):      # side 0 lanes end at a, side 1 at b
            n = lanes_of(s, side)
            if not n:
                continue
            outs = sum(1 for j in at[v] if j != i and lanes_of(segs[j], 1 if segs[j].a == v else 0))
            connections += n * outs
    return {'lanes': lanes, 'region_lanes': region_lanes, 'connections': connections}


def encode(verts, segs, corners):
    nyc = W.parse(NYC_GBMAP.read_bytes())
    g = W.GbMap()
    g.root[:] = nyc.root
    for off in (0x2C, 0x40, 0x54, 0x68, 0x7C):
        struct.pack_into('<I', g.root, off, 1)
    g.verts = [tuple(v) for v in verts]
    at = collections.defaultdict(list)
    for i, s in enumerate(segs):
        at[s.a].append(i)
        at[s.b].append(i)
    node_of = {}
    for v in sorted(at):
        node_of[v] = len(g.nodes)
        hdr = bytearray(W.NODE_SIZE)
        struct.pack_into('<H', hdr, 0, v)
        g.nodes.append((hdr, sorted(at[v])))
    prof_idx = {}
    for s in segs:
        key = profile_of(s)
        if key not in prof_idx:
            f0, f4, f8, one, fl = key
            p = bytearray(W.PROFILE_SIZE)
            struct.pack_into('<3f', p, 0, f0, f4, f8)
            struct.pack_into('<H', p, 0x0C, 0xFFFF)
            p[0x11] = one
            p[0x12] = 1
            p[0x13:0x17] = b'\x01' * 4
            struct.pack_into('<2f', p, 0x18, 5.0, 5.0)
            p[0x20] = fl
            prof_idx[key] = len(g.profiles)
            g.profiles.append(p)
        s.prof = prof_idx[key]
    for i, s in enumerate(segs):
        if s.oneway and s.slots[0] == 0xFFFF and s.slots[2] == 0xFFFF:
            s.flags[0] |= 2                  # the median side: no lanes, no sidewalk, no "missing" mark
        b = bytearray(W.SEG_SIZE)
        struct.pack_into('<6H', b, 0, s.a, s.b, node_of[s.a], node_of[s.b], *s.slots[:2])
        struct.pack_into('<3H', b, 0x0C, s.slots[2], s.slots[3], s.prof)
        b[0x14], b[0x15] = s.flags
        b[0x16] = b[0x17] = 1
        b[0x18] = b[0x19] = 1
        b[0x1E] = 13
        b[0x1F] = b[0x20] = 0xFF
        struct.pack_into('<I', b, 0x2C, 2)
        struct.pack_into('<H', b, 0x30, i)
        b[0x32] = 3
        g.segs.append(b)
        g.seg_sub.append(([], []))
    for s1, s2, v in corners:
        c = bytearray(W.CORNER_SIZE)
        struct.pack_into('<3H', c, 0, s1, s2, v)
        c[6] = 1 if segs[s1].b == v else 0xFF
        c[7] = 1 if segs[s2].a == v else 0xFF
        c[0x0A] = 1
        p1, p2 = profile_of(segs[s1]), profile_of(segs[s2])
        c[0x0B] = 2 if p1[:3] != p2[:3] else 0
        g.corners.append(c)
    data, _ = W.serialize(g)
    return data, node_of


def empty_traffic_lights():
    """The shipped empty file (region E05): a root with no intersections."""
    return (NYC_TRAFFIC_LIGHTS / 'E05_0001B40A.bin').read_bytes()


def png(path, verts, segs, corners):
    from PIL import Image, ImageDraw
    xs = [v[0] for v in verts]
    zs = [v[2] for v in verts]
    x0, x1, z0, z1 = min(xs) - 20, max(xs) + 20, min(zs) - 20, max(zs) + 20
    S = 0.5
    im = Image.new('RGB', (int((x1 - x0) * S), int((z1 - z0) * S)), (10, 10, 10))
    dr = ImageDraw.Draw(im)
    P = lambda v: ((v[0] - x0) * S, (z1 - v[2]) * S)
    for s in segs:
        col = (200, 60, 60) if s.highway else (230, 200, 60) if s.oneway else (200, 200, 200)
        dr.line([P(verts[s.a]), P(verts[s.b])], fill=col, width=1)
        f0, f4, f8, one, fl = profile_of(s)
        a, b = verts[s.a], verts[s.b]
        dx, dz = b[0] - a[0], b[2] - a[2]
        L = math.hypot(dx, dz) or 1
        nx, nz = -dz / L, dx / L
        off = f0 + f4 + f8 / 2
        for side, sign, sl in ((0, 1, (0, 2)), (1, -1, (1, 3))):
            if s.slots[sl[0]] != 0xFFFF or s.slots[sl[1]] != 0xFFFF:
                dr.line([P((a[0] + sign * nx * off, 0, a[2] + sign * nz * off)),
                         P((b[0] + sign * nx * off, 0, b[2] + sign * nz * off))], fill=(60, 200, 90), width=1)
    im.save(path)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--profile', default='SA_ls_full')
    ap.add_argument('--png')
    args = ap.parse_args()
    areas = sa_paths.load_full()
    pos, edges = sa_graph(areas)
    n0 = (len(pos), len(edges))
    verts, edges = merge_close(pos, edges)
    n1 = (len(verts), len(edges))
    verts, edges = simplify(verts, edges)
    segs = make_segments(edges)
    corners, faces = build_faces(verts, segs)
    data, node_of = encode(verts, segs, corners)
    budget = budgets(verts, segs, node_of)
    stats = {'sa': {'vertices': n0[0], 'edges': n0[1]}, 'merged': {'vertices': n1[0], 'edges': n1[1]},
             'gbmap': {'verts': len(verts), 'segments': len(segs), 'corners': len(corners), 'nodes': len(node_of),
                       'one_way': sum(s.oneway for s in segs), 'highway': sum(s.highway for s in segs),
                       'with_sidewalk': sum(1 for s in segs if any(x != 0xFFFF for x in s.slots)),
                       'bytes': len(data)},
             'faces': dict(faces), 'budget': budget, 'limits': LIMITS,
             'length_km': round(sum(math.dist(verts[s.a], verts[s.b]) for s in segs) / 1000, 1)}
    print(json.dumps(stats, indent=1))
    over = {k: v for k, v in budget.items() if v > LIMITS[k]}
    if over:
        raise SystemExit(f'over the engine budget: {over}')
    check = W.parse(data)
    assert len(check.segs) == len(segs) and len(check.corners) == len(corners)
    out = ARENA / 'out' / 'full_map' / args.profile / 'npc'
    (out / 'MEGACITY').mkdir(parents=True, exist_ok=True)
    (out / 'MEGACITY' / f'0x{GBMAP_HASH:08X}.megacity.gbmap').write_bytes(data)
    empty = empty_traffic_lights()
    for r in sorted(NYC_TRAFFIC_LIGHTS.glob('*.bin')):
        region, h = r.stem.split('_')
        (out / region).mkdir(exist_ok=True)
        (out / region / f'0x{h}.{region}.traf_lt_infpc').write_bytes(empty)
    (out / 'gbmap_stats.json').write_text(json.dumps(stats, indent=1))
    if args.png:
        png(args.png, verts, segs, corners)
    print('written', out)


if __name__ == '__main__':
    main()
