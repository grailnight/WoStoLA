"""Raise a native 25m square floor box, preserving its X/Z grid membership."""
import hashlib
import json
import math
from pathlib import Path
import shutil
import struct
import build_sa_world as W
import make_map_mod as M
import meshpack
import sa_hulls
import scgpc_box
import static_map_mesh
import wrapmesh


def patch_scene(original):
    assert len(original) == 7864
    offset, bounds = 0x1108, 0x1ae0
    assert struct.unpack_from('<I', original, bounds+12)[0]+0x80 == offset
    center, half = scgpc_box.decode(original[offset:offset+48])
    assert abs(center[0]+300)<.001 and abs(center[1]+.7)<.001
    # Preserve all shape and metadata bytes; only translate the native box Y.
    result = bytearray(original)
    struct.pack_into('<f', result, offset+0x18, 2.5)
    shift = 2.5-center[1]
    scale = struct.unpack_from('<f', original, 0x1e14)[0]
    low, high = struct.unpack_from('<2h', original, bounds+4)
    struct.pack_into('<2h', result, bounds+4, math.ceil(low-shift*scale), math.ceil(high+shift*scale))
    changed = set(range(offset+0x18, offset+0x1c)) | set(range(bounds+4,bounds+8))
    assert all(a==b for i,(a,b) in enumerate(zip(original,result)) if i not in changed)
    # Both grid rows intersecting the box already reference it.
    for list_pos in (0x1518,0x1580):
        count=original[list_pos+1]
        targets=[list_pos+v for v in struct.unpack_from(f'<{count}i',original,list_pos+4)]
        assert offset in targets
    quant_center=struct.unpack_from('<f',original,0x1e04)[0]
    qlo,qhi=struct.unpack_from('<2h',result,bounds+4)
    assert quant_center-qlo/scale<=2.5-half[1]
    assert quant_center+qhi/scale>=2.5+half[1]
    return bytes(result),(center[0],2.5,center[2]),half

def build_visible_control_mesh(source,center,half):
    """Add the raised control box as a visible diagnostic marker."""
    native=wrapmesh.parse((source/W.PACK/W.RESOURCE).read_bytes())
    mats=[h for tag,h,_,_ in native.ext_patches if tag==b'MAT\0']
    slots=[(*meshpack.world_geometry(native,i),mats[i]) for i in range(len(native.meshes))]
    lo=tuple(c-h for c,h in zip(center,half));hi=tuple(c+h for c,h in zip(center,half))
    box=sa_hulls.box_hull(lo,hi)
    group={'vertices':box.vertices,'uvs':[(0,0),(0,1),(1,0),(1,1)]*2,
           'triangles':[f['indices'] for f in box.faces]}
    v,t=M.to_records(group,double_sided=True)
    ocean=wrapmesh.parse(Path(M.OCEAN).read_bytes())
    material=next(h for tag,h,_,_ in ocean.ext_patches if tag==b'MAT\0')
    slots.append((v,t,material))
    vertices=[v[(meshpack.POSITION,0)] for vs,_,_ in slots for v in vs]
    bounds=([min(v[k] for v in vertices)-.01 for k in range(3)],
            [max(v[k] for v in vertices)+.01 for k in range(3)])
    blob,stats=static_map_mesh.build(Path(M.OCEAN).read_bytes(),iter(slots),bounds)
    static_map_mesh.validate(blob)
    return blob


def main():
    root=W.OUT/'SA_district_NativeBox'
    if root.exists():raise SystemExit('profile exists')
    source=W.OUT/'SA_district_TexturesV3'
    original=(W.OUT/'collision_research/L23/type_74_0001D211.bin').read_bytes()
    scene,center,half=patch_scene(original)
    blob=build_visible_control_mesh(source,center,half)
    shutil.copytree(source,root)
    W.write(root/W.PACK/W.RESOURCE,blob)
    W.write(root/'L23/0x0001D211.L23.scgpc',scene)
    top_y=center[1]+half[1]
    teleport=(center[0],top_y+2,center[2])
    manifest=json.loads((root/'manifest.json').read_text())
    manifest.update(profile=root.name,collision='native type-4 25m floor box raised to top Y=3; original PCCVX',
                    runtime_validation='pending',probes=[{'name':'sa_native_box','teleport':teleport}],
                    mesh_sha256=hashlib.sha256(blob).hexdigest(),scene_sha256=hashlib.sha256(scene).hexdigest())
    W.write(root/'manifest.json',json.dumps(manifest,indent=2).encode())
    W.write(root/'teleports/sa_native_box.txt',(' '.join(map(str,teleport))+'\n').encode())
    assert not list(root.rglob('*.pccvx'))
    print(json.dumps({'profile':root.name,'top_y':top_y,'teleport':teleport,'scene_bytes_changed':sum(a!=b for a,b in zip(original,scene))},indent=2))


if __name__=='__main__':main()
