"""Tiled SA world, drawn by SA_CollisionLoader itself (sa_runtime/world.bin).

Why: the engine draws EVERY slot of the ocean carrier every frame and culls
none of them (trace 20260929_225128: 840 of 1106 district draws were fully
outside the frustum). One slot per texture capped the district near 1000
slots, and Los Santos needs 10-14 thousand. So the carrier keeps a single
tiny TRIGGER slot. When the game draws it (main pass, LOD facade shader),
the DLL draws the visible batches of this file through the same pipeline
and returns without drawing the trigger.

Layout: 250 m tiles in SA x/y. One batch per (tile, image, draw class), each
<= 65535 vertices, drawn as an indexed triangle list with a base vertex.
Positions are SHORT4N against the tile's own box (sub-millimetre), in the
carrier's stride-24 layout, so the carrier's own vertex declaration draws
them. Draw classes come from the SA IDE draw distance: small props stop at
150 m, medium objects at 300 m, buildings at 1.5 km (the haze hides them).

Placement: WoS = (x, z, y)_SA + shift (sa_bake.sa_to_wos), SA sea level on the WoS water
(y -7.5). The game draws nothing while the camera is outside its 300 m region
grid (x -3300..6300, z -1800..2700), and the only free water inside it is the
band north of NYC (z ~1400..2250-2550) -- so a profile is a strip of Los
Santos placed there (--box, --shift). SA_ls_ring (LS_SHIFT, z 3017..4721)
proved the limit: it was only visible from outside, never from within.

    'SAWD' u32 version=1, tiles, batches, trigger primitives, trigger vertices,
           vertex stride, 0
    tile  (96 B): float lo[3], hi[3] (carrier space), scale[4], bias[4]
                  (SHORT4N decode; bias.w is taken live from the game),
                  u32 vb offset, vertices, ib offset, indices, first batch,
                  batch count, i32 tile x, tile y, u32 0, 0
    batch (56 B): u32 tile, i32 image (-1 = keep the facade texture), u32 flags
                  (bit 0 cutout, bit 1 two-sided, bits 8..15 alpha ref),
                  u32 base vertex, vertices, start index, primitives,
                  float lo[3], hi[3], max distance (0 = no limit)
    then vertex and index data, 16-byte aligned.

textures.bin is the usual SATX file with no slots: its images are indexed by
batch. anchors.bin as in sa_runtime_assets.

    py -3 build_sa_tiles.py --profile SA_ls_strip --box 0,-1950,3000,-950 --shift -2350,-7.5,600
Then: rebuild_collision.py <profile>, install, build the DLL for the profile.
"""
import argparse
import collections
import hashlib
import json
import math
from pathlib import Path
import struct
import time

import build_sa_world as W
import col_heightfield_boxes as C
import make_map_mod as M
import make_texture_mod as T
import meshpack
import sa_bake
import sa_ipl
import sa_runtime_assets as R
import static_map_mesh
import wrapmesh

# Default placement (the first ring). --shift overrides it: a profile must lie
# inside the game's 300 m region grid (x -3300..6300, z -1800..2700), or
# nothing is drawn there -- see wos-region-grid-world-edge.
LS_SHIFT = (1000.0, -7.5, 2200.0)  # SA_ls_full: LS over New York (x 1000..4000, z -600..1700)
TILE = 250.0
# (SA IDE draw distance up to, WoS max distance; 0 = until the fog)
CLASSES = ((60.0, 150.0), (100.0, 300.0), (math.inf, 1500.0))  # 1.5 km: past the haze
TRIGGER_TRIANGLES = 23
MAX_ANCHORS = 20000  # sa_anchor::build in collision_loader/sa_runtime.h rejects larger files
VERSION = 1
HEADER = struct.Struct('<4s7I')
TILE_REC = struct.Struct('<6f4f4f6I2i2I')
BATCH_REC = struct.Struct('<IiI4I6ff')
POSITION = (meshpack.POSITION, 0)
assert (HEADER.size, TILE_REC.size, BATCH_REC.size) == (32, 96, 56)


def class_of(distance):
    return next(i for i, (limit, _) in enumerate(CLASSES) if distance <= limit)


def to_carrier(p):
    return tuple(p[k] + LS_SHIFT[k] - W.CARRIER_TRANSLATION[k] for k in range(3))


def set_shift(shift):
    global LS_SHIFT
    LS_SHIFT = tuple(shift)


def align(buf, n=16):
    buf.extend(b'\0' * (-len(buf) % n))


class Images:
    """SA textures -> deduplicated DXT images (fourcc, w, h, mips, blob, cutout ref)."""

    def __init__(self, sources):
        self.sources, self.items, self.index, self.by_key, self.failed = sources, [], {}, {}, {}

    def of(self, key):
        if key in self.by_key:
            return self.by_key[key]
        tex = self.sources.get(key)
        result = -1
        if tex is None:
            self.failed[key] = 'missing_texture'
        else:
            try:
                fourcc, w, h, levels = R.texture_levels(tex)
                blob = b''.join(levels)
                fp = hashlib.sha256(fourcc + struct.pack('<2I', w, h) + blob).digest()
                if fp not in self.index:
                    self.index[fp] = len(self.items)
                    self.items.append((fourcc, w, h, len(levels), blob, R.cutout_ref(fourcc, w, h, levels[0])))
                result = self.index[fp]
            except ValueError as exc:
                self.failed[key] = str(exc)
        self.by_key[key] = result
        return result

    def textures_bin(self):
        facade = R.facade_texture()
        level0 = facade.levels()[0]
        out = bytearray(b'SATX' + struct.pack('<3I', 3, 0, len(self.items)))
        out += facade.fourcc + struct.pack('<4I', facade.width, facade.height, facade.mips, len(level0)) + level0
        for fourcc, w, h, mips, blob, _ in self.items:
            out += fourcc + struct.pack('<4I', w, h, mips, len(blob)) + blob
        return bytes(out)


def merge(groups):
    out = {'vertices': [], 'uvs': [], 'triangles': []}
    for g in groups:
        base = len(out['vertices'])
        out['vertices'] += g['vertices']
        out['uvs'] += g['uvs']
        out['triangles'] += [(a + base, b + base, c + base) for a, b, c in g['triangles']]
    return out


def bake_tiles(selected, cache, draw, images):
    """-> {tile key: [(class, image, records, triangles)]}, skipped counts."""
    per_tile = collections.defaultdict(lambda: collections.defaultdict(list))
    for inst in selected:
        key = (math.floor(inst['pos'][0] / TILE), math.floor(inst['pos'][1] / TILE))
        per_tile[key][class_of(draw.get(inst['id'], 300.0))].append(inst)
    tiles, skipped = {}, collections.Counter()
    for n, key in enumerate(sorted(per_tile), 1):
        batches = []
        for cls, insts in sorted(per_tile[key].items()):
            groups, skip = sa_bake.bake(insts, cache)
            skipped.update(skip)
            by_image = collections.defaultdict(list)
            for tex, g in groups.items():
                by_image[images.of(tex)].append(g)
            for image, gs in sorted(by_image.items()):
                for piece in sa_bake.chunks(merge(gs)):
                    piece['vertices'] = [to_carrier(p) for p in piece['vertices']]
                    records, tris = M.to_records(piece)
                    batches.append((cls, image, records, tris))
        tiles[key] = batches
        if n % 10 == 0:
            print(f'  {n}/{len(per_tile)} tiles baked', flush=True)
    return tiles, skipped


def encode_world(tiles, images, template_mi, trigger):
    stride = template_mi['vertex_stride']
    tile_rows, batch_rows, blobs = [], [], bytearray()
    world_lo, world_hi = [math.inf] * 3, [-math.inf] * 3
    for (tx, ty), batches in sorted(tiles.items()):
        if not batches:
            continue
        pts = [r[POSITION][:3] for _, _, recs, _ in batches for r in recs]
        lo = [min(p[k] for p in pts) for k in range(3)]
        hi = [max(p[k] for p in pts) for k in range(3)]
        centre = [(lo[k] + hi[k]) / 2 for k in range(3)]
        half = [max((hi[k] - lo[k]) / 2, 0.01) for k in range(3)]
        model = {'offset': centre + [0.0], 'bbox': half + [0.0]}
        vb, ib = bytearray(), bytearray()
        first, vertices = len(batch_rows), 0
        for cls, image, recs, tris in sorted(batches, key=lambda b: (b[0], b[1])):
            packed = []
            for r in recs:
                q = dict(r)
                q[POSITION] = meshpack.normalize_position(r[POSITION][:3], model)
                packed.append(q)
            vb += meshpack.encode_vertices(template_mi, packed)
            start = len(ib) // 2
            ib += struct.pack('<%dH' % (3 * len(tris)), *(i for t in tris for i in t))
            bp = [r[POSITION][:3] for r in recs]
            blo = [min(p[k] for p in bp) for k in range(3)]
            bhi = [max(p[k] for p in bp) for k in range(3)]
            ref = images.items[image][5] if image >= 0 else 0
            flags = (ref << 8 | 3) if ref else 0
            batch_rows.append((len(tile_rows), image, flags, vertices, len(recs), start, len(tris),
                               *blo, *bhi, CLASSES[cls][1]))
            vertices += len(recs)
        align(blobs)
        vb_off = len(blobs); blobs += vb
        align(blobs)
        ib_off = len(blobs); blobs += ib
        tile_rows.append((*lo, *hi, *half, 0.0, *centre, 1.0,
                          vb_off, vertices, ib_off, len(ib) // 2, first, len(batch_rows) - first, tx, ty, 0, 0))
        for k in range(3):
            world_lo[k] = min(world_lo[k], lo[k] + W.CARRIER_TRANSLATION[k])
            world_hi[k] = max(world_hi[k], hi[k] + W.CARRIER_TRANSLATION[k])
    head = HEADER.size + TILE_REC.size * len(tile_rows) + BATCH_REC.size * len(batch_rows)
    head += -head % 16
    out = bytearray(HEADER.pack(b'SAWD', VERSION, len(tile_rows), len(batch_rows),
                                trigger[0], trigger[1], stride, 0))
    for row in tile_rows:
        row = list(row)
        row[14] += head  # vb offset
        row[16] += head  # ib offset
        out += TILE_REC.pack(*row)
    for row in batch_rows:
        out += BATCH_REC.pack(*row)
    align(out)
    assert len(out) == head
    out += blobs
    stats = {'tiles': len(tile_rows), 'batches': len(batch_rows),
             'vertices': sum(r[15] for r in tile_rows), 'triangles': sum(r[6] for r in batch_rows),
             'per_class_batches': dict(collections.Counter(
                 next(i for i, c in enumerate(CLASSES) if c[1] == r[-1]) for r in batch_rows))}
    return bytes(out), (world_lo, world_hi), stats


def trigger_mesh(bounds):
    """One slot drawn by nobody: every vertex on the diagonal of the district box
    (carrier space), so all triangles have zero area yet the mesh and model boxes
    cover the district. A small ribbon 300 m underground was only drawn while the
    camera looked at it (the engine culls the slot by its own box), so the DLL's
    world stayed invisible most of the time (2026-09-30)."""
    lo, hi = bounds
    n = TRIGGER_TRIANGLES + 2
    recs = []
    for i in range(n):
        t = i / (n - 1)
        recs.append({POSITION: tuple(lo[k] + (hi[k] - lo[k]) * t for k in range(3)) + (0.0,),
                     (meshpack.NORMAL, 0): (0.0, 1.0, 0.0, 0.0),
                     (meshpack.TEXCOORD, 0): (0.0, 0.0), (meshpack.COLOR, 0): (255.0, 255.0, 255.0, 255.0)})
    tris = [(i, i + 1, i + 2) if i % 2 == 0 else (i + 1, i, i + 2) for i in range(TRIGGER_TRIANGLES)]
    box = ([lo[k] - 0.01 for k in range(3)], [hi[k] + 0.01 for k in range(3)])
    blob, _ = static_map_mesh.build(Path(M.OCEAN).read_bytes(), iter([(recs, tris, W.FALLBACK)]), box)
    m = static_map_mesh.validate(blob)
    mi = m.meshes[0]
    return blob, (mi['index_count'] - 2, mi['vertex_count'])


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--profile', required=True)
    p.add_argument('--centre', default='1500,-1700', help='SA x,y of the region centre')
    p.add_argument('--radius', type=float, default=800.0, help='SA radius in metres')
    p.add_argument('--box', help='SA x0,y0,x1,y1 rectangle instead of the circle')
    p.add_argument('--shift', help='WoS = (x, z, y)_SA + this x,y,z (default LS_SHIFT)')
    p.add_argument('--anchor-step', type=float, default=R.ANCHOR_STEP,
                   help=f'web anchor lattice step, m (default {R.ANCHOR_STEP}; SA_ls_full needs 16: '
                        f'the DLL rejects more than {MAX_ANCHORS} anchors)')
    a = p.parse_args()
    if not a.profile.startswith('SA_'):
        p.error('profile names start with SA_')
    root = W.OUT / a.profile
    if root.exists():
        raise SystemExit(f'output already exists: {root}')
    start = time.time()
    if a.shift:
        set_shift(float(v) for v in a.shift.split(','))
    if a.box:
        box = tuple(float(v) for v in a.box.split(','))
        region = ('box', box)
        centre = ((box[0] + box[2]) / 2, (box[1] + box[3]) / 2)
    else:
        centre = tuple(float(v) for v in a.centre.split(','))
        region = (centre, a.radius)
    instances, placement = sa_ipl.load_world(M.SA_DIR, M.IDE_ROOT)
    selected = [i for i in instances if sa_bake.in_area(i, region)]
    print(f'{a.profile}: {len(selected)} instances', flush=True)
    draw = sa_ipl.read_ide_draw(M.IDE_ROOT)
    images = Images(T.texture_sources(selected, M.IDE_ROOT, M.SA_DIR))
    cache = sa_bake.ModelCache(M.SA_DIR)
    tiles, skipped = bake_tiles(selected, cache, draw, images)

    template = wrapmesh.parse(Path(M.OCEAN).read_bytes())
    # the counts do not depend on the box: encode with a unit box, then rebuild
    # the trigger over the district box the encoder reports
    _, trigger = trigger_mesh(([0.0, -1.0, 0.0], [1.0, 0.0, 1.0]))
    world_bin, (lo, hi), stats = encode_world(tiles, images, template.meshes[0], trigger)
    trig_blob, again = trigger_mesh((lo, hi))
    assert again == trigger, (again, trigger)
    textures = images.textures_bin()
    area = [[lo[k] - 0.01 for k in range(3)], [hi[k] + 0.01 for k in range(3)]]
    print(json.dumps(stats), flush=True)

    heights, _, _ = C.heightfield(C.district_triangles(LS_SHIFT, region=region), area, 2.0)
    R.ANCHOR_STEP = a.anchor_step
    anchor_points = R.anchors(heights, area, 2.0)
    if len(anchor_points) > MAX_ANCHORS:  # the DLL would drop anchors.bin whole: no webs at all
        raise SystemExit(f'{len(anchor_points)} anchors at {a.anchor_step} m, the DLL takes at most '
                         f'{MAX_ANCHORS}: raise --anchor-step')
    anchor_bin = b'SAAN' + struct.pack('<2I', 1, len(anchor_points)) + b''.join(
        struct.pack('<3f', *q) for q in anchor_points)

    W.write(root / W.PACK / W.RESOURCE, trig_blob)
    W.write(root / R.RUNTIME / 'world.bin', world_bin)
    W.write(root / R.RUNTIME / 'textures.bin', textures)
    W.write(root / R.RUNTIME / 'anchors.bin', anchor_bin)
    manifest = {
        'profile': a.profile, 'scope': 'tiles', 'placement': placement,
        'instances_selected': len(selected), 'world_shift': list(LS_SHIFT),
        'model_bounds': area, 'carrier_translation': list(W.CARRIER_TRANSLATION),
        'region': ({'box': list(region[1])} if region[0] == 'box' else
                   {'centre': list(centre), 'radius': a.radius}), 'normals': 'outward',
        'tile_m': TILE, 'draw_classes': [[c[0] if math.isfinite(c[0]) else None, c[1]] for c in CLASSES],
        'trigger': {'primitives': trigger[0], 'vertices': trigger[1]},
        'world': {**stats, 'bytes': len(world_bin), 'sha256': hashlib.sha256(world_bin).hexdigest()},
        'runtime_textures': {'textures': len(images.items), 'bytes': len(textures),
                             'cutout_textures': sum(1 for im in images.items if im[5]),
                             'untextured_sources': images.failed},
        'anchors': {'count': len(anchor_points), 'rise_m': R.ANCHOR_RISE, 'step_m': R.ANCHOR_STEP},
        'mesh_sha256': hashlib.sha256(trig_blob).hexdigest(), 'bytes': len(trig_blob),
        'skipped': dict(skipped), 'missing_models': sorted(cache.misses),
        'collision': 'not supplied; run rebuild_collision.py',
        'elapsed_seconds': round(time.time() - start, 1)}
    W.write(root / 'manifest.json', json.dumps(manifest, indent=2).encode())
    print(json.dumps({k: manifest[k] for k in ('profile', 'instances_selected', 'trigger', 'world',
                                               'anchors', 'elapsed_seconds')}, indent=2), flush=True)
    print(json.dumps({'textures': len(images.items), 'untextured': len(images.failed),
                      'model_bounds': area}), flush=True)


if __name__ == '__main__':
    main()
