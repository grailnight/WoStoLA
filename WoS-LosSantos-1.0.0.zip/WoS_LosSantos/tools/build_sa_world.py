"""Stage complete geometry, with no area-ranked surface removal.

district: all surfaces at the existing test2 spot; optional source textures.
san-andreas: all registered exterior IPL geometry, shifted east by 7000 m.
Writes only WoS_Arena/out/full_map/<profile>, never enables an override.
"""
import argparse
import collections
import glob
import hashlib
import json
import math
import os
from pathlib import Path
import struct
import time

import make_map_mod as M
import make_texture_mod as T
import make_cell_mod as C
import meshpack
import sa_bake
import sa_ipl
import static_map_mesh
import sa_texture_convert
import wrapmesh

OUT = Path(__file__).resolve().parent.parent / 'out' / 'full_map'
PACK = Path('MEGACITY/0xEE185533.T25.megacity.pcapk')
RESOURCE = '0xD9CB2AAA.s_nat_ocean000.wrap.mesh'
FALLBACK = 0x01115646  # loaded opaque facade material in MEGACITY
# The megacity entity that owns s_nat_ocean000 (and the ocean001 water) sits
# at (0, -7.5, 0): every captured draw of the native carrier has world row
# y = local y - 7.5, and megacity.ens holds that translation. The mesh is in
# carrier-LOCAL space = world - CARRIER_TRANSLATION. Collision, teleports and
# manifest model_bounds are world space. See carrier_offset.py.
CARRIER_TRANSLATION = (0.0, -7.5, 0.0)


def to_carrier(p):
    return tuple(p[k] - CARRIER_TRANSLATION[k] for k in range(3))


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix+'.tmp')
    tmp.write_bytes(data)
    tmp.replace(path)


def material_bindings(groups, instances, root):
    """Use unique existing resource identities; report every fallback group.

    The experimental profile also overrides the listed NYC materials/textures.
    Cloning one proven opaque facade shader keeps mesh input requirements stable.
    Alpha-tested / transparent source surfaces remain a documented limitation.
    """
    sources = T.texture_sources(instances, M.IDE_ROOT, M.SA_DIR)
    conversion_errors = {}
    for key in groups:
        if key in sources:
            try:
                sources[key] = sa_texture_convert.compressed(sources[key])
            except ValueError as exc:
                conversion_errors[key] = str(exc)
    targets = C.exclusive_textures()
    mats = {}
    for p in glob.glob(glob.escape(T.TEX_DIR)+'/*.wrap.mat'):
        data = Path(p).read_bytes()
        try:
            th,_ = C.material_texture(data)
        except ValueError:
            continue
        mats.setdefault(th, []).append(p)
    facade = Path(glob.glob(glob.escape(T.TEX_DIR)+f'/0x{FALLBACK:08X}.*.wrap.mat')[0]).read_bytes()
    template = Path(T.TEMPLATE_TEX).read_bytes()
    bound, report = {}, []
    targets = iter((h,p) for h,p in targets if C.victim_rank(p) < 2
                   and len(mats.get(h,[]))==1)
    # Allocate by visible surface, and share identical images across TXDs.
    areas = {key:T.group_area(g) for key,g in groups.items()}
    fingerprints = {}
    totals = collections.Counter()
    for key,tex in sources.items():
        if key in groups and tex.fourcc in (b'DXT1',b'DXT3',b'DXT5'):
            fingerprint = (tex.width,tex.height,tex.fourcc,
                           hashlib.sha256(b''.join(tex.mips)).hexdigest())
            fingerprints[key] = fingerprint
            totals[fingerprint] += areas[key]
    allocated = {}
    for key in sorted(groups, key=lambda k:(-totals.get(fingerprints.get(k),areas[k]),k)):
        tex = sources.get(key)
        row = {'source':key, 'triangles':len(groups[key]['triangles']), 'area':areas[key]}
        if tex is None or tex.fourcc not in (b'DXT1',b'DXT3',b'DXT5'):
            row['fallback'] = 'missing_texture' if tex is None else 'uncompressed_texture'
            if key in conversion_errors:
                row['conversion_error'] = conversion_errors[key]
            report.append(row)
            continue
        fingerprint = fingerprints[key]
        if fingerprint in allocated:
            first = allocated[fingerprint]
            bound[key] = int(first['material'],16)
            row.update({k:v for k,v in first.items() if k not in ('source','triangles','area')})
            row['shared_with'] = first['source']
            report.append(row)
            continue
        target = next(targets,None)
        if target is None:
            row['fallback'] = 'no_exclusive_resource_remaining'
            report.append(row)
            continue
        th,tp = target
        mp = mats[th][0]
        mh = C.hash_of(mp)
        target_mat = Path(mp).read_bytes()
        source_m,_ = wrapmesh.parse_container(facade)
        target_m,_ = wrapmesh.parse_container(target_mat)
        blob = bytearray(C.repoint_texture(facade,th))
        # Keep the target's filename placeholder and filename hash; all layout
        # and shader references belong to the intact facade template.
        blob[source_m.img.target:source_m.img.target+8] = target_mat[target_m.img.target:target_m.img.target+8]
        write(root/PACK/Path(mp).name, bytes(blob))
        write(root/PACK/Path(tp).name, T.to_wos_texture(tex,template,th))
        bound[key] = mh
        row.update(material=f'0x{mh:08X}', texture=f'0x{th:08X}',
                   texture_size=[tex.width,tex.height], alpha=tex.has_alpha,
                   override_material=Path(mp).name, override_texture=Path(tp).name)
        report.append(row)
        allocated[fingerprint] = row
    return bound,report


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--scope',choices=['district','san-andreas'],default='district')
    parser.add_argument('--textured',action='store_true')
    parser.add_argument('--profile',help='Fresh SA_ profile name for a versioned build')
    parser.add_argument('--centre',default='1500,-1700',help='district: SA x,y of the region centre')
    parser.add_argument('--radius',type=float,default=150.0,help='district: SA radius in metres')
    parser.add_argument('--place',help='district: WoS x,z for the centre of the baked box '
                        '(default: the saved test2 spot)')
    args=parser.parse_args()
    if args.textured and args.scope!='district':
        parser.error('source texture resource allocation is currently district-only')
    profile='SA_'+args.scope.replace('-','_')+('_Textured' if args.textured else '_Geometry')
    if args.profile:
        import re
        if not re.fullmatch(r'SA_[A-Za-z0-9_]+',args.profile):
            parser.error('invalid profile name')
        profile=args.profile
    root=OUT/profile
    if root.exists():
        raise SystemExit(f'output already exists: {root}; use a fresh version instead of overwriting')
    start=time.time()
    instances,placement=sa_ipl.load_world(M.SA_DIR,M.IDE_ROOT)
    cache=sa_bake.ModelCache(M.SA_DIR)
    skipped=collections.Counter()
    texture_report=[]
    expected=[]
    if args.scope=='district':
        centre=tuple(float(v) for v in args.centre.split(','))
        selected=[i for i in instances if sa_bake.in_region(i,centre,args.radius)]
        groups,skip=sa_bake.bake(selected,cache)
        skipped.update(skip)
        lo=[min(v[k] for g in groups.values() for v in g['vertices']) for k in range(3)]
        hi=[max(v[k] for g in groups.values() for v in g['vertices']) for k in range(3)]
        if args.place:
            saved=[float(v) for v in args.place.split(',')];saved=[saved[0],0.0,saved[1]]
        else:
            saved=Path(M.GAME,'WOSTweaks/locationSave/test2.txt').read_text().split()
        shift=(float(saved[0])-(lo[0]+hi[0])/2, -lo[1],float(saved[2])-(lo[2]+hi[2])/2)
        bounds=([lo[k]+shift[k]-0.01 for k in range(3)],
                [hi[k]+shift[k]+0.01 for k in range(3)])
        bindings={}
        if args.textured:
            bindings,texture_report=material_bindings(groups,selected,root)
        def slots():
            for key,g in sorted(groups.items()):
                for piece in sa_bake.chunks(g):
                    piece['vertices']=[to_carrier(tuple(p[k]+shift[k] for k in range(3))) for p in piece['vertices']]
                    v,t=M.to_records(piece)
                    expected.append({'source':key,'vertices':len(v),'triangles':len(t)})
                    yield v,t,bindings.get(key,FALLBACK)
    else:
        selected=instances
        shift=(7000.0,0.0,0.0)
        # Tight enough for ~12 cm 16-bit steps while covering all exterior map
        # assets. build() rejects any vertex outside instead of clipping it.
        bounds=([3000.0,-1000.0,-4000.0],[11000.0,2000.0,4000.0])
        cells=collections.defaultdict(list)
        for i in selected:
            cells[(math.floor(i['pos'][0]/300),math.floor(i['pos'][1]/300))].append(i)
        def slots():
            for number,(cell,items) in enumerate(sorted(cells.items()),1):
                groups,skip=sa_bake.bake(items,cache,per_texture=False)
                skipped.update(skip)
                for g in groups.values():
                    for piece in sa_bake.chunks(g):
                        piece['vertices']=[to_carrier(tuple(p[k]+shift[k] for k in range(3))) for p in piece['vertices']]
                        v,t=M.to_records(piece)
                        expected.append({'cell':list(cell),'vertices':len(v),'triangles':len(t)})
                        yield v,t,FALLBACK
                if number%20==0:
                    print(f'{number}/{len(cells)} cells encoded',flush=True)
    print(f'{profile}: {len(selected)} instances; building all surfaces',flush=True)
    carrier_bounds=[list(to_carrier(b)) for b in bounds]
    blob,stats=static_map_mesh.build(Path(M.OCEAN).read_bytes(),slots(),carrier_bounds)
    m=static_map_mesh.validate(blob)
    # Decode the finished buffers, independently of the encoder's strip check.
    decoded_triangles=0
    for i,row in enumerate(expected):
        v,t=meshpack.world_geometry(m,i)
        if len(v)!=row['vertices'] or len(t)!=row['triangles']:
            raise AssertionError(f'roundtrip count mismatch in slot {i}')
        decoded_triangles+=len(t)
    write(root/PACK/RESOURCE,blob)
    manifest={'profile':profile,'scope':args.scope,'placement':placement,
              'instances_selected':len(selected),'slots':len(stats),
              'vertices':sum(s['vertices'] for s in stats),
              'triangles':decoded_triangles,'bytes':len(blob),
              'mesh_sha256':hashlib.sha256(blob).hexdigest(),
              'world_shift':shift,'model_bounds':bounds,
              'carrier_translation':list(CARRIER_TRANSLATION),'skipped':dict(skipped),
              'region':({'centre':[float(v) for v in args.centre.split(',')],'radius':args.radius}
                        if args.scope=='district' else None),
              'missing_models':sorted(cache.misses),'texture_bindings':texture_report,
              'slot_sources':expected,'structural_validation':'passed',
              'runtime_validation':'pending','collision':'not supplied',
              'limitations':['opaque facade shader; source alpha not implemented',
                 'full map is always resident; streaming and LOD not implemented',
                 'script-switched IPLs excluded; see unassociated_stream_files',
                 'DFF frame/atomic transforms not yet applied'],
              'elapsed_seconds':round(time.time()-start,2)}
    write(root/'manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2).encode())
    print(json.dumps({k:manifest[k] for k in ('profile','instances_selected','slots','vertices','triangles','bytes','skipped','elapsed_seconds')},indent=2),flush=True)
    print(root,flush=True)


if __name__=='__main__':
    main()
