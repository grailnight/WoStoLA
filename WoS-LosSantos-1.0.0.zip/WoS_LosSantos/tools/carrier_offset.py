"""Move an SA profile's s_nat_ocean000 mesh into the carrier's local space.

The game draws s_nat_ocean000 through a megacity entity placed at
(0, -7.5, 0) (build_sa_world.CARRIER_TRANSLATION). Evidence:
  * every captured draw of the native carrier (WoS_Deferred/captures, vs with
    gDecompPosBias = the ocean000 box) has world rows (1,0,0,0) (0,1,0,-7.5)
    (0,0,1,0), plus a far copy at scale 40, y -426.162;
  * megacity.ens: the entity whose component list references ocean001 and
    ocean000 carries the same -7.5 translation; the water (ocean001, local
    y 0) is drawn at -7.5 by it.
Profiles built before the constant existed wrote world coordinates straight
into the mesh, so the district was drawn 7.5 m below its collision (which is
world space) and the player stood at lamp height. This re-bakes such a mesh
7.5 m higher; collision, teleports and the DLL are untouched.

    py -3 carrier_offset.py SA_district_FoundationCOL
"""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import time

import build_sa_world as W
import meshpack
import static_map_mesh
import wrapmesh

POSITION = (meshpack.POSITION, 0)


def slots_of(m):
    """(records, triangles, material hash) per mesh, positions decoded."""
    material_at = {p.target: h for tag, h, _, p in m.ext_patches if tag == b'MAT\0'}
    return [(*meshpack.world_geometry(m, i), material_at[mi['material'].pos])
            for i, mi in enumerate(m.meshes)]


def to_carrier(blob):
    """Re-encode every slot with positions moved from world to carrier space."""
    slots = slots_of(wrapmesh.parse(blob))
    for records, _, _ in slots:
        for r in records:
            p = r[POSITION]
            r[POSITION] = W.to_carrier(p) + tuple(p[3:])
    points = [r[POSITION] for records, _, _ in slots for r in records]
    bounds = ([min(p[k] for p in points) - .01 for k in range(3)],
              [max(p[k] for p in points) + .01 for k in range(3)])
    out, _ = static_map_mesh.build(Path(W.M.OCEAN).read_bytes(), iter(slots), bounds)
    return out


def check(before, after):
    """Same slots, triangles, materials and attributes; positions moved exactly
    by the carrier offset within two 16-bit steps of either model box."""
    old, new = wrapmesh.parse(before), wrapmesh.parse(after)
    a, b = slots_of(old), slots_of(new)
    assert len(a) == len(b), 'slot count changed'
    step = max(max(m.model['bbox'][:3]) for m in (old, new)) / 32767
    delta = [-t for t in W.CARRIER_TRANSLATION]
    worst = 0.0
    for i, ((va, ta, ma), (vb, tb, mb)) in enumerate(zip(a, b)):
        assert ma == mb, f'slot {i}: material changed'
        assert ta == tb, f'slot {i}: triangles changed'
        assert len(va) == len(vb), f'slot {i}: vertex count changed'
        for ra, rb in zip(va, vb):
            assert ra.keys() == rb.keys(), f'slot {i}: vertex layout changed'
            for key in ra:
                if key == POSITION:
                    worst = max(worst, *(abs(rb[key][k] - ra[key][k] - delta[k]) for k in range(3)))
                else:
                    assert ra[key] == rb[key], f'slot {i}: {key} changed'
    assert worst <= 2 * step, f'position error {worst:.4f} m exceeds {2 * step:.4f} m'
    return {'slots': len(a), 'max_position_error_m': round(worst, 5),
            'quantization_step_m': round(step, 5)}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('profile')
    a = p.parse_args()
    staged_root = W.OUT / a.profile
    installed_root = Path(__file__).resolve().parents[2] / 'exWoS' / a.profile
    manifest_path = staged_root / 'manifest.json'
    manifest = json.loads(manifest_path.read_text())
    if 'carrier_translation' in manifest:
        raise SystemExit(f'{a.profile} is already in carrier space: {manifest["carrier_translation"]}')
    staged = staged_root / W.PACK / W.RESOURCE
    installed = installed_root / W.PACK / W.RESOURCE
    before = staged.read_bytes()
    if hashlib.sha256(before).hexdigest() != manifest['mesh_sha256']:
        raise SystemExit('staged mesh does not match its manifest; refusing to guess')
    after = to_carrier(before)
    static_map_mesh.validate(after)
    report = check(before, after)

    stamp = time.strftime('%Y%m%d_%H%M%S')
    backup = W.OUT / 'profile_backups' / f'{a.profile}_before_carrier_offset_{stamp}'
    backup.mkdir(parents=True)
    shutil.copy2(staged, backup / 'staged.wrap.mesh')
    shutil.copy2(manifest_path, backup / 'manifest.json')
    if installed.exists():
        shutil.copy2(installed, backup / 'installed.wrap.mesh')
    # add_height_ruler keeps its pre-ruler mesh here; --remove would now put
    # the uncorrected mesh back, so retire it with the rest of the old state.
    ruler = W.OUT / 'profile_backups' / f'{a.profile}.mesh_before_ruler'
    if ruler.exists():
        shutil.move(str(ruler), str(backup / ruler.name))

    manifest.update(carrier_translation=list(W.CARRIER_TRANSLATION),
                    mesh_sha256=hashlib.sha256(after).hexdigest(), bytes=len(after),
                    carrier_offset_check=report)
    text = json.dumps(manifest, indent=2).encode()
    W.write(staged, after)
    W.write(manifest_path, text)
    if installed_root.exists():
        W.write(installed, after)
        W.write(installed_root / 'manifest.json', text)
    print(json.dumps({'profile': a.profile, 'backup': str(backup),
                      'installed': installed_root.exists(), **report}, indent=2))


if __name__ == '__main__':
    main()
