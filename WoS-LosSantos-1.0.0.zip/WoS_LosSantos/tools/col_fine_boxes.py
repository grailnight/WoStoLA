"""Layered type-4 boxes, adaptive: 2 m cells, split along walls.

col_layer_boxes samples ONE vertical line per 2 m cell (its centre), so a
facade crossing a cell turned the whole 2x2 m column into wall: walls stood
up to 1-1.5 m out into the street and gaps under ~2-3 m closed
(collision_passage_oracle: 99 % of blocked wall area was this "cell bleed").

Here every cell is sampled on a FINE sub-grid (default 1 m: 4 lines per
cell) with exactly the builder's rules (depth count over closed SA COL
volumes, duplicate hits on shared edges dropped, MIN_GAP fill, orphan slab,
open bottom down to the floor, slabs grown to MIN_THICK), vectorised per
64 m tile. A cell whose sub-lines all give the same (bottom, top) bins stays
one 2 m cell as before; any other cell is boxed per sub-line. Both sets are
merged greedily into rectangles, coarse with coarse and fine with fine, so
they never overlap.

    boxes, stats = build_boxes(area, cell=2.0, step=0.25, tris=tris, fine=1.0)
"""
import math
import time

import numpy as np

import col_heightfield_boxes as C
import col_layer_boxes as B

TILE_M = 64.0
SPLIT = 0.6        # sub-lines further apart than a kerb step make the cell split
MAX_RANK = 8


def _raster(tris, up_face, ox, oz, n, fine):
    """(point, y, up) where the n x n lines at ox + (i + .5) * fine + JITTER meet the triangles."""
    j = B.JITTER
    xs, zs = tris[:, :, 0], tris[:, :, 2]
    ix0 = np.clip(np.ceil((xs.min(1) - ox - j) / fine - .5), 0, n).astype(np.int64)
    ix1 = np.clip(np.floor((xs.max(1) - ox - j) / fine - .5), -1, n - 1).astype(np.int64)
    iz0 = np.clip(np.ceil((zs.min(1) - oz - j) / fine - .5), 0, n).astype(np.int64)
    iz1 = np.clip(np.floor((zs.max(1) - oz - j) / fine - .5), -1, n - 1).astype(np.int64)
    w, d = ix1 - ix0 + 1, iz1 - iz0 + 1
    keep = (w > 0) & (d > 0)
    tris, up_face, ix0, iz0, w, d = tris[keep], up_face[keep], ix0[keep], iz0[keep], w[keep], d[keep]
    cnt = w * d
    which = np.repeat(np.arange(len(tris)), cnt)
    k = np.arange(cnt.sum()) - np.repeat(np.cumsum(cnt) - cnt, cnt)
    cx, cz = ix0[which] + k % w[which], iz0[which] + k // w[which]
    px, pz = ox + (cx + .5) * fine + j, oz + (cz + .5) * fine + j
    a, b, c = tris[which, 0], tris[which, 1], tris[which, 2]
    den = (b[:, 2] - c[:, 2]) * (a[:, 0] - c[:, 0]) + (c[:, 0] - b[:, 0]) * (a[:, 2] - c[:, 2])
    ok = np.abs(den) > 1e-9
    den = np.where(ok, den, 1.0)
    l1 = ((b[:, 2] - c[:, 2]) * (px - c[:, 0]) + (c[:, 0] - b[:, 0]) * (pz - c[:, 2])) / den
    l2 = ((c[:, 2] - a[:, 2]) * (px - c[:, 0]) + (a[:, 0] - c[:, 0]) * (pz - c[:, 2])) / den
    l3 = 1 - l1 - l2
    hit = ok & (l1 >= -1e-6) & (l2 >= -1e-6) & (l3 >= -1e-6)
    y = l1 * a[:, 1] + l2 * b[:, 1] + l3 * c[:, 1]
    return (cx * n + cz)[hit], y[hit], up_face[which][hit]


def _intervals(point, y, up, floor):
    """col_layer_boxes.intervals_at, vectorised. -> (point, lo, hi), top first per point."""
    order = np.lexsort((-y, point))
    point, y, up = point[order], y[order], up[order]
    first = np.r_[True, point[1:] != point[:-1]]
    dup = ~first & (np.abs(np.r_[0, np.diff(y)]) < B.SAME_HIT) & (up == np.r_[False, up[:-1]])
    point, y, up = point[~dup], y[~dup], up[~dup]
    if not len(point):
        return point, y, y
    first = np.r_[True, point[1:] != point[:-1]]
    group = np.cumsum(first) - 1
    # depth = max(0, depth + step), restarted per point: d_k = s_k - min(0, min_{j<=k} s_j)
    s = np.cumsum(np.where(up, 1, -1))
    base = np.r_[0, s][np.flatnonzero(first)]
    s = s - base[group]
    big = 1 << 40
    low = np.minimum.accumulate(np.minimum(s, 0) - group * big) + group * big
    depth = s - np.minimum(low, 0)
    before = np.r_[0, depth[:-1]]
    before[first] = 0
    start = up & (before == 0)
    end = ~up & (before > 0) & (depth == 0)
    si, ei = np.flatnonzero(start), np.flatnonzero(end)
    k = np.searchsorted(ei, si)
    has_end = (k < len(ei))
    has_end[has_end] = group[ei[k[has_end]]] == group[si[has_end]]
    lo = np.where(has_end, y[ei[np.minimum(k, max(len(ei) - 1, 0))]] if len(ei) else floor, floor)
    pts, hi = point[si], y[si]
    # a line with hits but no solid: a lone downward face becomes a slab
    with_solid = np.zeros(group[-1] + 1, bool)
    with_solid[group[si]] = True
    orphan = np.flatnonzero(first & ~with_solid[group])
    pts = np.r_[pts, point[orphan]]
    hi = np.r_[hi, y[orphan]]
    lo = np.r_[lo, y[orphan] - B.ORPHAN_SLAB]
    order = np.lexsort((-hi, pts))
    pts, lo, hi = pts[order], lo[order], hi[order]
    # merge gaps under MIN_GAP (top-down: the previous interval's bottom vs this top)
    newp = np.r_[True, pts[1:] != pts[:-1]]
    gap = np.r_[np.inf, lo[:-1]] - hi
    head = newp | (gap >= B.MIN_GAP)
    idx = np.flatnonzero(head)
    hi = hi[idx]
    lo = np.minimum.reduceat(lo, idx)
    pts = pts[idx]
    lo = np.minimum(lo, hi - B.MIN_THICK)
    return pts, lo, hi


def _merge(slots, max_cells):
    """Greedy rectangles over {(ix, iz): {key: (lo, hi)}} (sparse col_layer_boxes.merge)."""
    rects = []
    for ix, iz in sorted(slots, key=lambda p: (p[1], p[0])):
        here = slots.get((ix, iz))
        if not here:
            continue
        for k in list(here):
            if k not in here:
                continue
            w = 1
            while w < max_cells and k in slots.get((ix + w, iz), ()):
                w += 1
            d = 1
            while d < max_cells and all(k in slots.get((ix + a, iz + d), ()) for a in range(w)):
                d += 1
            members = [slots[(ix + a, iz + b)].pop(k) for a in range(w) for b in range(d)]
            rects.append((ix, iz, w, d, min(m[0] for m in members), max(m[1] for m in members)))
    return rects


def build_boxes(area, cell=2.0, step=0.25, tris=None, shift=None, fine=1.0, log=print):
    t0 = time.time()
    if tris is None:
        tris = C.district_triangles(shift, prop_test=C.is_walk_through)
    tris = np.asarray(tris, np.float64)
    u, w = tris[:, 1] - tris[:, 0], tris[:, 2] - tris[:, 0]
    nrm = np.cross(u, w)
    ny = nrm[:, 1] / np.maximum(np.linalg.norm(nrm, axis=1), 1e-12)
    keep = np.abs(ny) >= 0.05
    tris, up_face = tris[keep], ny[keep] < 0.0      # col_layers.is_up
    floor = float(tris[:, :, 1].min()) - C.BELOW
    sub = int(round(cell / fine))
    assert abs(sub * fine - cell) < 1e-9 and sub >= 1
    x0, z0 = area[0][0], area[0][2]
    nx = math.ceil((area[1][0] - x0) / cell)
    nz = math.ceil((area[1][2] - z0) / cell)
    tcells = int(TILE_M / cell)                      # cells per tile side
    n = tcells * sub                                 # fine lines per tile side
    ntx, ntz = math.ceil(nx / tcells), math.ceil(nz / tcells)

    def key_of(lo, hi):
        return (None if lo <= floor else math.floor(lo / step), math.floor(hi / step))

    # triangles per tile
    side = tcells * cell
    mn, mx = tris[:, :, [0, 2]].min(1), tris[:, :, [0, 2]].max(1)
    a0 = np.clip(((mn[:, 0] - x0) // side).astype(np.int64), 0, ntx - 1)
    a1 = np.clip(((mx[:, 0] - x0) // side).astype(np.int64), 0, ntx - 1)
    b0 = np.clip(((mn[:, 1] - z0) // side).astype(np.int64), 0, ntz - 1)
    b1 = np.clip(((mx[:, 1] - z0) // side).astype(np.int64), 0, ntz - 1)
    ww, dd = a1 - a0 + 1, b1 - b0 + 1
    cnt = ww * dd
    which = np.repeat(np.arange(len(tris)), cnt)
    k = np.arange(cnt.sum()) - np.repeat(np.cumsum(cnt) - cnt, cnt)
    tkey = (a0[which] + k % ww[which]) * ntz + b0[which] + k // ww[which]
    order = np.argsort(tkey, kind='stable')
    tkey, which = tkey[order], which[order]
    bounds = np.searchsorted(tkey, np.arange(ntx * ntz + 1))

    coarse, finer = {}, {}
    split_cells = uniform_cells = 0
    for tx in range(ntx):
        for tz in range(ntz):
            t = tx * ntz + tz
            ti = which[bounds[t]:bounds[t + 1]]
            if not len(ti):
                continue
            ox, oz = x0 + tx * side, z0 + tz * side
            p, y, up = _raster(tris[ti], up_face[ti], ox, oz, n, fine)
            if not len(p):
                continue
            pts, lo, hi = _intervals(p, y, up, floor)
            if not len(pts):
                continue
            fx, fz = pts // n, pts % n
            cxl, czl = fx // sub, fz // sub
            cid = cxl * tcells + czl                  # tile-local cell index
            ncell = tcells * tcells
            # A cell stays whole when its sub-lines agree: the same number of
            # solid intervals, and the k-th top/bottom within SPLIT of each
            # other on every line (a slope differs by centimetres, a wall by
            # metres). Empty lines count as 0 intervals.
            rank = np.minimum(np.arange(len(pts)) - np.searchsorted(pts, pts), MAX_RANK - 1)
            count = np.zeros(n * n, np.int64)
            np.add.at(count, pts, 1)
            lines = np.arange(n * n)
            lx, lz = lines // n, lines % n
            lcell = (lx // sub) * tcells + lz // sub
            low_v = np.where(lo <= floor, floor, lo)

            def agree(group, ngroup):
                """Per group of lines: same interval count and every k-th
                top/bottom within SPLIT on all of them."""
                cmin = np.full(ngroup, 1 << 30, np.int64)
                cmax = np.full(ngroup, -1, np.int64)
                np.minimum.at(cmin, group, count)
                np.maximum.at(cmax, group, count)
                ok = cmin == cmax
                slot = group[pts] * MAX_RANK + rank
                for v in (hi, low_v):
                    vmin = np.full(ngroup * MAX_RANK, np.inf)
                    vmax = np.full(ngroup * MAX_RANK, -np.inf)
                    np.minimum.at(vmin, slot, v)
                    np.maximum.at(vmax, slot, v)
                    ok &= np.where(np.isfinite(vmin), vmax - vmin, 0).reshape(ngroup, MAX_RANK).max(1) < SPLIT
                return ok

            uniform = agree(lcell, ncell)
            # A split cell along a wall usually agrees within its columns (or
            # rows): those lines take one representative, so the merge joins
            # them into 1 x 2 m strips running along the wall.
            cols = agree(lcell * sub + lx % sub, ncell * sub).reshape(ncell, sub).all(1)
            rows = agree(lcell * sub + lz % sub, ncell * sub).reshape(ncell, sub).all(1)
            cx0, cz0 = (lx // sub) * sub, (lz // sub) * sub
            rep = np.where(cols[lcell], lx * n + cz0 + sub // 2,
                           np.where(rows[lcell], (cx0 + sub // 2) * n + lz, lines))
            first_i = np.searchsorted(pts, lines)
            last_i = np.searchsorted(pts, lines, 'right')
            # whole cells: the sub-line nearest the centre stands for the cell
            whole = uniform[cid]
            mid = (fx % sub == sub // 2) & (fz % sub == sub // 2)
            for i in np.flatnonzero(whole & mid):
                gx, gz = tx * tcells + int(cxl[i]), tz * tcells + int(czl[i])
                if gx < nx and gz < nz:
                    coarse.setdefault((gx, gz), {})[key_of(lo[i], hi[i])] = (float(lo[i]), float(hi[i]))
            for q in np.flatnonzero(~uniform[lcell] & (count[rep] > 0)):
                if tx * tcells + lx[q] // sub >= nx or tz * tcells + lz[q] // sub >= nz:
                    continue
                r = rep[q]
                slot_ = finer.setdefault((tx * n + int(lx[q]), tz * n + int(lz[q])), {})
                for i in range(first_i[r], last_i[r]):
                    slot_[key_of(lo[i], hi[i])] = (float(lo[i]), float(hi[i]))
            occupied = np.unique(lcell[count != 0])
            split_cells += int((~uniform[occupied]).sum())
            uniform_cells += int(uniform[occupied].sum())
        log(f'  fine column {tx + 1}/{ntx}: {uniform_cells} whole cells, {split_cells} split, {time.time() - t0:.0f} s')
    boxes = []
    for ix, iz, w_, d_, lo, hi in _merge(coarse, int(2 * C.MAX_HALF / cell)):
        lo = max(lo, hi - 2 * C.MAX_HALF + .1)
        boxes.append(((x0 + ix * cell, lo, z0 + iz * cell), (x0 + (ix + w_) * cell, hi, z0 + (iz + d_) * cell)))
    n_coarse = len(boxes)
    for ix, iz, w_, d_, lo, hi in _merge(finer, int(2 * C.MAX_HALF / fine)):
        lo = max(lo, hi - 2 * C.MAX_HALF + .1)
        boxes.append(((x0 + ix * fine, lo, z0 + iz * fine), (x0 + (ix + w_) * fine, hi, z0 + (iz + d_) * fine)))
    stats = {'cells': nx * nz, 'whole_cells': uniform_cells, 'split_cells': split_cells, 'fine_m': fine,
             'boxes': len(boxes), 'coarse_boxes': n_coarse, 'fine_boxes': len(boxes) - n_coarse,
             'layered_cells': split_cells, 'seconds': round(time.time() - t0, 1)}
    return boxes, stats
