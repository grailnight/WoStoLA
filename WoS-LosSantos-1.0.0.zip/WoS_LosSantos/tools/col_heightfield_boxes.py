"""Type-4 box set for the district built from real SA COL data.

WoS type-4 boxes are axis-aligned, so the district collision is authored as a
2.5D height field: vertical rays through the instances' COL faces/boxes give
the topmost walkable surface per cell, cells whose heights round to the same
step are merged greedily into rectangles, and each rectangle becomes a solid
column from below the lowest surface up to its top. Overhangs, arches and
interiors are lost; roofs, streets, slopes (as steps) and walls are kept.

Replaces the DFF per-instance AABBs of build_district_foundation, whose tops
sat a median 11 m above the real surfaces (see audit_col_vs_profile.py).
"""
import json
import math
import sys

import audit_col_vs_profile as A
import build_district_foundation as F
import build_sa_world as W

MAX_HALF = F.MAX_BOX_HALF_EXTENT
BELOW = 2.0


# Street furniture and vegetation. In a 2.5D height field a lamppost's 0.3 m
# COL bar becomes a solid 2x2 m column up to the lamp head, a traffic signal's
# arm a wall across the road, a billboard on a pole a block down to the
# pavement -- the player ends up standing at lamp height. They are dropped;
# walking through a pole is the lesser error.
PROP_NAME_HINTS = ('lamp', 'veg_', 'palm', 'tree', 'bush', 'sig', 'billb',
                   'sign', 'bench', 'newstand', 'postbox', 'tag_', 'cj_',
                   'gen_door', 'cardboard', 'alpha', 'nitewin')
PROP_MAX_FOOTPRINT = 50.0  # m^2 of COL bounds in the model's ground plane


def is_prop(name, col):
    lowered = name.lower()
    if any(h in lowered for h in PROP_NAME_HINTS):
        return True
    lo, hi = col.bounds[:3], col.bounds[3:]
    return (hi[0] - lo[0]) * (hi[1] - lo[1]) < PROP_MAX_FOOTPRINT


def manifest_region(manifest):
    """The SA area a profile was baked from: (centre, radius), or ('box', box)
    for rectangular profiles; old profiles: the district."""
    region = manifest.get('region')
    if region and 'box' in region:
        return 'box', tuple(float(v) for v in region['box'])
    if region:
        return tuple(region['centre']), float(region['radius'])
    return F.DISTRICT_CENTRE, F.DISTRICT_RADIUS


# Layered boxes (col_layer_boxes) keep every solid interval, so a pole no
# longer grows into a 2x2 m column up to its top: only things meant to be
# walked through are dropped there. The 50 m2 rule above had also dropped
# billboards, dock huts, trailers, guard houses, tanks, ramps and stairs.
# Thin poles still become 2x2 m columns wherever a cell centre hits them.
LAYERED_NAME_HINTS = tuple(h for h in PROP_NAME_HINTS if h != 'billb') + ('pole', 'tlgraph', 'telgrph')
LAYERED_MAX_FOOTPRINT = 6.0  # m^2: lamp/signal poles, bins, hydrants, bollards


def is_walk_through(name, col):
    lowered = name.lower()
    if any(h in lowered for h in LAYERED_NAME_HINTS):
        return True
    lo, hi = col.bounds[:3], col.bounds[3:]
    return (hi[0] - lo[0]) * (hi[1] - lo[1]) < LAYERED_MAX_FOOTPRINT


def district_triangles(shift, skip_props=True, region=None, prop_test=None):
    area = region or (F.DISTRICT_CENTRE, F.DISTRICT_RADIUS)
    prop_test = prop_test or is_prop
    instances, _ = W.sa_ipl.load_world(W.M.SA_DIR, W.M.IDE_ROOT)
    selected = [i for i in instances if W.sa_bake.in_area(i, area)]
    cols = A.load_col_index(W.M.SA_DIR)
    tris = []
    for inst in selected:
        col = cols.get(inst['model'].lower())
        if col is None or (skip_props and prop_test(inst['model'], col)):
            continue
        tris += A.world_triangles(inst, col, shift)
    return tris


class TriGrid:
    """Bucket triangles by X/Z so each ray tests only nearby ones."""

    def __init__(self, tris, lo, cell):
        self.lo, self.cell, self.buckets = lo, cell, {}
        for t in tris:
            x0 = int((min(p[0] for p in t) - lo[0]) // cell)
            x1 = int((max(p[0] for p in t) - lo[0]) // cell)
            z0 = int((min(p[2] for p in t) - lo[2]) // cell)
            z1 = int((max(p[2] for p in t) - lo[2]) // cell)
            for ix in range(x0, x1 + 1):
                for iz in range(z0, z1 + 1):
                    self.buckets.setdefault((ix, iz), []).append(t)

    def top(self, x, z):
        key = (int((x - self.lo[0]) // self.cell), int((z - self.lo[2]) // self.cell))
        return A.ray_down(self.buckets.get(key, ()), x, z)


def heightfield(tris, area, cell):
    grid = TriGrid(tris, area[0], 8.0)
    nx = math.ceil((area[1][0] - area[0][0]) / cell)
    nz = math.ceil((area[1][2] - area[0][2]) / cell)
    h = [[None] * nz for _ in range(nx)]
    for ix in range(nx):
        for iz in range(nz):
            # median of the centre and four inner corners: a cell takes a
            # roof only when most of it is under that roof, so walls stay
            # within ~0.7 m instead of growing a cell-wide invisible ledge
            xs = area[0][0] + (ix + .5) * cell
            zs = area[0][2] + (iz + .5) * cell
            d = cell * .35
            ys = [grid.top(xs + a, zs + b)
                  for a, b in ((0, 0), (-d, -d), (d, -d), (-d, d), (d, d))]
            ys = sorted(y for y in ys if y is not None)
            h[ix][iz] = ys[len(ys) // 2] if ys else None
    return h, nx, nz


def merge(h, nx, nz, step, max_cells):
    """Greedy rectangles over cells whose heights share a `step` bin."""
    key = [[None if v is None else math.floor(v / step) for v in col] for col in h]
    used = [[False] * nz for _ in range(nx)]
    rects = []
    for iz in range(nz):
        for ix in range(nx):
            k = key[ix][iz]
            if k is None or used[ix][iz]:
                continue
            w = 1
            while (ix + w < nx and w < max_cells and not used[ix + w][iz]
                   and key[ix + w][iz] == k):
                w += 1
            d = 1
            while iz + d < nz and d < max_cells and all(
                    not used[ix + a][iz + d] and key[ix + a][iz + d] == k
                    for a in range(w)):
                d += 1
            for a in range(w):
                for b in range(d):
                    used[ix + a][iz + b] = True
            top = max(h[ix + a][iz + b] for a in range(w) for b in range(d))
            rects.append((ix, iz, w, d, top))
    return rects


def build_boxes(area, cell=2.0, step=0.5, tris=None, shift=None):
    if tris is None:
        tris = district_triangles(shift)
    h, nx, nz = heightfield(tris, area, cell)
    floor = min(v for col in h for v in col if v is not None) - BELOW
    rects = merge(h, nx, nz, step, int(2 * MAX_HALF / cell))
    boxes = []
    for ix, iz, w, d, top in rects:
        bottom = max(floor, top - 2 * MAX_HALF + .1)
        lo = (area[0][0] + ix * cell, bottom, area[0][2] + iz * cell)
        hi = (area[0][0] + (ix + w) * cell, top, area[0][2] + (iz + d) * cell)
        boxes.append((lo, hi))
    return boxes, h


def street_teleport(h, area, cell, radius=3, flat=0.3, low_fraction=0.4):
    """A point 2 m above a flat, low (street-level) patch near the centre.

    Flat: every cell within `radius` has a surface within `flat` metres.
    Low: the height is in the lowest `low_fraction` of the district, which
    keeps the probe on a street rather than a roof.
    """
    nx, nz = len(h), len(h[0])
    values = sorted(v for col in h for v in col if v is not None)
    ceiling = values[int(len(values) * low_fraction)]
    cx = (area[0][0] + area[1][0]) / 2
    cz = (area[0][2] + area[1][2]) / 2
    best = None
    for ix in range(radius, nx - radius):
        for iz in range(radius, nz - radius):
            y = h[ix][iz]
            if y is None or y > ceiling:
                continue
            around = [h[ix + a][iz + b] for a in range(-radius, radius + 1)
                      for b in range(-radius, radius + 1)]
            if any(v is None or abs(v - y) > flat for v in around):
                continue
            x = area[0][0] + (ix + .5) * cell
            z = area[0][2] + (iz + .5) * cell
            d = (x - cx) ** 2 + (z - cz) ** 2
            if best is None or d < best[0]:
                best = (d, (x, y + 2.0, z))
    if best is None:
        raise ValueError('no flat street patch for the collision probe')
    return best[1]


def main():
    source = W.OUT / 'SA_district_TexturesV3'
    manifest = json.loads((source / 'manifest.json').read_text())
    shift = tuple(manifest['world_shift'])
    area = manifest['model_bounds']
    tris = district_triangles(shift)
    for cell in (1.5, 2.0):
        for step in (0.25, 0.5):
            boxes, h = build_boxes(area, cell, step, tris)
            print(json.dumps({'cell': cell, 'step': step, 'boxes': len(boxes)}))
            sys.stdout.flush()


if __name__ == '__main__':
    main()
