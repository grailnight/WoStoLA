"""Layered type-4 boxes from the district's SA COL: overpasses stay hollow.

The 2.5D height field (col_heightfield_boxes) made every cell solid from the
floor up to its highest surface, so the space under a freeway deck became an
invisible wall. Here each 2 m cell keeps every solid interval along its
vertical line. SA decks, pillars and buildings are closed COL volumes (526 of
the 567 cells with a surface 4 m+ over another have the deck's bottom face),
so a depth count works: an upward face enters a solid (+1), a downward face
leaves one (-1), and the line is solid while the depth is positive. Nested
volumes (a pillar under a deck) keep the depth up. SA ground has no bottom
face, so it stays a column down to the floor, and an open deck with no bottom
face is still filled to the ground as before.

Cells whose intervals share (bottom, top) height bins merge greedily into
rectangles, one box per rectangle.
"""
import json
import math

import col_heightfield_boxes as C
import col_layers as L

MAX_HALF = C.MAX_HALF
JITTER = 0.013      # keep sample lines off the shared edges of quads
MIN_GAP = 2.0       # gaps nobody fits through are filled
MIN_THICK = 0.3     # slivers are dropped
SAME_HIT = 0.01
ORPHAN_SLAB = 1.0   # a lone downward face (supports06_LAn) becomes a slab


def intervals_at(grid, x, z, floor):
    """Solid (bottom, top) intervals on the vertical line at (x, z), top first."""
    events = []
    for y, normal_y in grid.hits(x + JITTER, z + JITTER):
        if abs(normal_y) < 0.05:
            continue
        up = L.is_up(normal_y)
        if events and abs(events[-1][0] - y) < SAME_HIT and events[-1][1] == up:
            continue  # the same surface met twice along a shared edge
        events.append((y, up))
    depth, top, solid = 0, None, []
    for y, up in events:  # descending
        if up:
            if depth == 0:
                top = y
            depth += 1
        elif depth > 0:
            depth -= 1
            if depth == 0:
                solid.append([y, top])
    if depth > 0:
        solid.append([floor, top])
    if not solid and events:
        solid.append([events[0][0] - ORPHAN_SLAB, events[0][0]])
    merged = []
    for lo, hi in solid:
        if merged and merged[-1][0] - hi < MIN_GAP:
            merged[-1][0] = min(merged[-1][0], lo)
        else:
            merged.append([lo, hi])
    # thin solids are real floors (car park decks and footbridges are 0.22 m
    # slabs with both faces): keep the top, grow the slab down to MIN_THICK.
    # Dropping them (before 2026-10-03) left every deck of a car park open.
    return [(min(lo, hi - MIN_THICK), hi) for lo, hi in merged]


def layered_cells(tris, area, cell):
    grid = L.Grid(tris, area[0], 8.0)
    tops = [p[1] for t in tris for p in t]
    floor = min(tops) - C.BELOW
    nx = math.ceil((area[1][0] - area[0][0]) / cell)
    nz = math.ceil((area[1][2] - area[0][2]) / cell)
    # the centre decides; the height field's four inner corner probes only
    # stand in where the centre misses, so edge cells of the district stay
    d = cell * .35
    probes = ((0, 0), (-d, -d), (d, -d), (-d, d), (d, d))

    def cell_intervals(ix, iz):
        x, z = area[0][0] + (ix + .5) * cell, area[0][2] + (iz + .5) * cell
        for a, b in probes:
            found = intervals_at(grid, x + a, z + b, floor)
            if found:
                return found
        return []
    cells = [[cell_intervals(ix, iz) for iz in range(nz)] for ix in range(nx)]
    return cells, nx, nz, floor


def merge(cells, nx, nz, step, floor, max_cells):
    """Greedy rectangles over cells holding an interval with the same bins."""
    def key(lo, hi):
        return (None if lo <= floor else math.floor(lo / step), math.floor(hi / step))
    slots = [[{key(lo, hi): (lo, hi) for lo, hi in cells[ix][iz]} for iz in range(nz)] for ix in range(nx)]
    rects = []
    for iz in range(nz):
        for ix in range(nx):
            for k in list(slots[ix][iz]):
                if k not in slots[ix][iz]:
                    continue
                w = 1
                while ix + w < nx and w < max_cells and k in slots[ix + w][iz]:
                    w += 1
                d = 1
                while iz + d < nz and d < max_cells and all(k in slots[ix + a][iz + d] for a in range(w)):
                    d += 1
                members = [slots[ix + a][iz + b].pop(k) for a in range(w) for b in range(d)]
                rects.append((ix, iz, w, d, min(m[0] for m in members), max(m[1] for m in members)))
    return rects


def build_boxes(area, cell=2.0, step=0.25, tris=None, shift=None):
    if tris is None:
        tris = C.district_triangles(shift)
    cells, nx, nz, floor = layered_cells(tris, area, cell)
    boxes = []
    for ix, iz, w, d, lo, hi in merge(cells, nx, nz, step, floor, int(2 * MAX_HALF / cell)):
        lo = max(lo, hi - 2 * MAX_HALF + .1)
        boxes.append(((area[0][0] + ix * cell, lo, area[0][2] + iz * cell),
                      (area[0][0] + (ix + w) * cell, hi, area[0][2] + (iz + d) * cell)))
    stats = {'cells': nx * nz, 'layered_cells': sum(1 for col in cells for c in col if len(c) > 1),
             'boxes': len(boxes)}
    return boxes, stats


if __name__ == '__main__':
    import build_sa_world as W
    man = json.loads((W.OUT / 'SA_district_FoundationCOL' / 'manifest.json').read_text())
    boxes, stats = build_boxes(man['model_bounds'], shift=tuple(man['world_shift']))
    print(json.dumps(stats))
