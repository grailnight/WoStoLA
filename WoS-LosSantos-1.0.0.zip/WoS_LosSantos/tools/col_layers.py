"""Vertical ray hits through the district's SA COL, per 2 m cell, with the
facing of every hit: the raw material for layered (overpass-aware) collision.

A hit is (y, normal_y) as computed from the stored vertex order. sa_col's
triangles come out wound the other way round, so an UPWARD face has a
NEGATIVE normal_y here (a roof reads -1.0); is_up() hides that.
"""
import math

import audit_col_vs_profile as A
import col_heightfield_boxes as C


def triangle_normal_y(a, b, c):
    u = [b[k] - a[k] for k in range(3)]
    w = [c[k] - a[k] for k in range(3)]
    ny = u[2] * w[0] - u[0] * w[2]
    nx = u[1] * w[2] - u[2] * w[1]
    nz = u[0] * w[1] - u[1] * w[0]
    length = math.sqrt(nx * nx + ny * ny + nz * nz) or 1.0
    return ny / length


def is_up(normal_y):
    return normal_y < 0.0


def hits_at(tris, x, z):
    """All (y, normal_y) where the vertical line through (x, z) meets a triangle."""
    out = []
    for a, b, c in tris:
        if (x < min(a[0], b[0], c[0]) or x > max(a[0], b[0], c[0]) or
                z < min(a[2], b[2], c[2]) or z > max(a[2], b[2], c[2])):
            continue
        d = (b[2] - c[2]) * (a[0] - c[0]) + (c[0] - b[0]) * (a[2] - c[2])
        if abs(d) < 1e-9:
            continue
        l1 = ((b[2] - c[2]) * (x - c[0]) + (c[0] - b[0]) * (z - c[2])) / d
        l2 = ((c[2] - a[2]) * (x - c[0]) + (a[0] - c[0]) * (z - c[2])) / d
        l3 = 1 - l1 - l2
        if min(l1, l2, l3) < -1e-6:
            continue
        out.append((l1 * a[1] + l2 * b[1] + l3 * c[1], triangle_normal_y(a, b, c)))
    out.sort(reverse=True)
    return out


class Grid(C.TriGrid):
    def hits(self, x, z):
        key = (int((x - self.lo[0]) // self.cell), int((z - self.lo[2]) // self.cell))
        return hits_at(self.buckets.get(key, ()), x, z)


if __name__ == '__main__':
    import json
    import build_sa_world as W
    man = json.loads((W.OUT / 'SA_district_FoundationCOL' / 'manifest.json').read_text())
    area = man['model_bounds']
    tris = C.district_triangles(tuple(man['world_shift']))
    g = Grid(tris, area[0], 8.0)
    cell = 2.0
    nx = math.ceil((area[1][0] - area[0][0]) / cell)
    nz = math.ceil((area[1][2] - area[0][2]) / cell)
    layered = closed = open_ = 0
    examples = []
    for ix in range(nx):
        for iz in range(nz):
            x = area[0][0] + (ix + .5) * cell
            z = area[0][2] + (iz + .5) * cell
            h = g.hits(x, z)
            ups = [y for y, n in h if n > 0.2]
            if len(ups) < 2 or ups[0] - ups[-1] < 4.0:
                continue
            layered += 1
            # a downward face between the top surface and the next one down?
            below_top = [y for y, n in h if n < -0.2 and ups[1] < y < ups[0]]
            if below_top:
                closed += 1
            else:
                open_ += 1
            if len(examples) < 12 and ix % 7 == 0:
                examples.append((round(x, 1), round(z, 1), [(round(y, 2), round(n, 2)) for y, n in h][:8]))
    print('cells', nx * nz, 'layered (gap>=4m)', layered, 'with bottom face', closed, 'without', open_)
    for e in examples:
        print(e)
