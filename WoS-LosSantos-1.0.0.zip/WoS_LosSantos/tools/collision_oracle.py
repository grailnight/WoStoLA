"""Offline oracle: does a tiled SA profile's collision match what is drawn?

Truth is the rendered geometry: every SA instance of the profile's region,
baked from its .dff exactly as build_sa_tiles does (WoS = (x, z, y)_SA +
world_shift). It is sampled on the same 2 m cells as col_layer_boxes, at the
cell centre, and every cell remembers which instance owns its top surface.
The collision is read back from the installed L23 SCGPC (the 48-byte type-4
records the DLL registers), not from the builder, so the test sees what the
game sees.

Per cell, with the top drawn surface R and the boxes covering the cell:
  ok       some box top is within MATCH of R
  missing  no box reaches up to R - GAP: the player walks into / falls through
           something visible
  phantom  a box top sits above R + GAP and none matches: an invisible ledge
  empty    nothing is drawn but a box stands there (only counted when the box
           rises over the drawn ground around it)
Vegetation and thin street furniture are drawn but are meant to be walked
through; they never own a cell.

Per instance, the cells it owns are summed, and an instance with a sizeable
footprint and a large missing fraction is reported with the reason:
  no_col        its model has no COL entry at all
  prop_filter   col_heightfield_boxes.is_walk_through dropped it on purpose
                (name hint or a COL footprint under LAYERED_MAX_FOOTPRINT)
  col_lost      its own SA COL reaches the drawn surface there, yet the
                boxes do not: the pipeline lost it (a bug on our side)
  sa_col_gap    its own SA COL does not cover that part (SA ships it so:
                "trans" overlays, half-collided hills); not a pipeline bug

    py -3 collision_oracle.py SA_ls_full [--png oracle.png] [--json report.json]
"""
import argparse
import collections
import json
import math
import struct
import time
from pathlib import Path

import numpy as np

import audit_col_vs_profile as A
import build_sa_world as W
import col_heightfield_boxes as C
import sa_bake
import sa_ipl

CELL = 2.0
JITTER = 0.013          # same as col_layer_boxes: sample off the shared quad edges
MATCH = 0.5             # a box top this close to the drawn surface supports it
GAP = 1.5               # beyond this the player visibly floats / sinks / is blocked
RECORD = 48
RECORDS_AT = 0x1428     # first generated type-4 record (build_district_foundation.build)
GRID_EDGE = ((-3300.0, 6300.0), (-1800.0, 2700.0))   # region grid x, z (wos-region-grid-world-edge)
MAX_ANCHORS = 20000
MIN_FOOTPRINT_CELLS = 5     # 20 m2: a kiosk, not a pole
REPORT_MISSING = 0.3

WALK_THROUGH = ('veg', 'copse', 'vbg_', 'palm', 'tree', 'bush', 'plant', 'grass', 'hedge', 'flower',
                'fence', 'railing',
                'lamp', 'trafficl', 'mtraffic', 'traflite', 'sig', 'pole', 'wire', 'tag_',
                'alpha', 'nitewin', 'shadow', 'cables', 'telgrph', 'telewire', 'washline')


def walk_through(name):
    lowered = name.lower()
    return any(h in lowered for h in WALK_THROUGH)


def instance_triangles(inst, model, shift):
    """(N, 3, 3) world triangles of one instance, winding as baked."""
    m = np.array(sa_bake.quat_matrix(inst['rot'], conjugate=True))
    out = []
    for g in model['geometries']:
        if not g.vertices or not g.triangles:
            continue
        v = np.asarray(g.vertices, np.float64) @ m.T + np.asarray(inst['pos'])
        v = v[:, [0, 2, 1]] + np.asarray(shift)          # sa_to_wos + shift
        t = np.asarray([tri[:3] for tri in g.triangles], np.int64)
        t = t[(t[:, 0] != t[:, 1]) & (t[:, 1] != t[:, 2]) & (t[:, 0] != t[:, 2])]
        if len(t):
            out.append(v[t])
    return np.concatenate(out) if out else np.zeros((0, 3, 3))


def raster_tops(tris, x0, z0, nx, nz):
    """-> (flat cell index, top y) of the triangles at the 2 m cell centres."""
    xs, zs = tris[:, :, 0], tris[:, :, 2]
    ix0 = np.clip(np.ceil((xs.min(1) - x0 - JITTER) / CELL - .5), 0, nx).astype(np.int64)
    ix1 = np.clip(np.floor((xs.max(1) - x0 - JITTER) / CELL - .5), -1, nx - 1).astype(np.int64)
    iz0 = np.clip(np.ceil((zs.min(1) - z0 - JITTER) / CELL - .5), 0, nz).astype(np.int64)
    iz1 = np.clip(np.floor((zs.max(1) - z0 - JITTER) / CELL - .5), -1, nz - 1).astype(np.int64)
    w, d = ix1 - ix0 + 1, iz1 - iz0 + 1
    keep = (w > 0) & (d > 0)
    if not keep.any():
        return np.zeros(0, np.int64), np.zeros(0)
    tris, ix0, iz0, w, d = tris[keep], ix0[keep], iz0[keep], w[keep], d[keep]
    n = w * d
    which = np.repeat(np.arange(len(tris)), n)
    k = np.arange(n.sum()) - np.repeat(np.cumsum(n) - n, n)
    cx = ix0[which] + k % w[which]
    cz = iz0[which] + k // w[which]
    px = x0 + (cx + .5) * CELL + JITTER
    pz = z0 + (cz + .5) * CELL + JITTER
    a, b, c = tris[which, 0], tris[which, 1], tris[which, 2]
    den = (b[:, 2] - c[:, 2]) * (a[:, 0] - c[:, 0]) + (c[:, 0] - b[:, 0]) * (a[:, 2] - c[:, 2])
    ok = np.abs(den) > 1e-9
    den = np.where(ok, den, 1.0)
    l1 = ((b[:, 2] - c[:, 2]) * (px - c[:, 0]) + (c[:, 0] - b[:, 0]) * (pz - c[:, 2])) / den
    l2 = ((c[:, 2] - a[:, 2]) * (px - c[:, 0]) + (a[:, 0] - c[:, 0]) * (pz - c[:, 2])) / den
    l3 = 1 - l1 - l2
    hit = ok & (l1 >= -1e-6) & (l2 >= -1e-6) & (l3 >= -1e-6)
    y = l1 * a[:, 1] + l2 * b[:, 1] + l3 * c[:, 1]
    return (cx * nz + cz)[hit], y[hit]


def read_boxes(scgpc):
    """(lo, hi) arrays of the generated type-4 records of an installed SCGPC."""
    data = Path(scgpc).read_bytes()
    grid = struct.unpack_from('<I', data, 0x14)[0] + 0x80
    count = (grid - RECORDS_AT) // RECORD
    raw = np.frombuffer(data, np.uint8, count * RECORD, RECORDS_AT).reshape(count, RECORD)
    assert ((raw[:, 0] & 0x7f) == 4).all(), 'non-box record among the generated ones'
    centre = raw[:, 0x14:0x20].copy().view('<f4').astype(np.float64)
    import scgpc_box
    half = raw[:, 0x2a:0x30].copy().view('<u2').astype(np.float64) * scgpc_box.SCALE
    return centre - half, centre + half


def box_cells(lo, hi, x0, z0, nx, nz):
    """-> (box index, flat cell index) for every cell centre inside a box footprint."""
    ix0 = np.clip(np.ceil((lo[:, 0] - x0 - JITTER) / CELL - .5), 0, nx).astype(np.int64)
    ix1 = np.clip(np.floor((hi[:, 0] - x0 - JITTER) / CELL - .5), -1, nx - 1).astype(np.int64)
    iz0 = np.clip(np.ceil((lo[:, 2] - z0 - JITTER) / CELL - .5), 0, nz).astype(np.int64)
    iz1 = np.clip(np.floor((hi[:, 2] - z0 - JITTER) / CELL - .5), -1, nz - 1).astype(np.int64)
    w, d = np.maximum(ix1 - ix0 + 1, 0), np.maximum(iz1 - iz0 + 1, 0)
    n = w * d
    which = np.repeat(np.arange(len(lo)), n)
    k = np.arange(n.sum()) - np.repeat(np.cumsum(n) - n, n)
    return which, (ix0[which] + k % w[which]) * nz + iz0[which] + k // w[which]


def load_profile(profile, installed=True):
    staged = W.OUT / profile
    root = Path(__file__).resolve().parents[2] / 'exWoS' / profile if installed else staged
    manifest = json.loads((root / 'manifest.json').read_text())
    return root, manifest


def run(profile, installed=True, log=print):
    t0 = time.time()
    root, manifest = load_profile(profile, installed)
    shift = tuple(manifest['world_shift'])
    region = C.manifest_region(manifest)
    area = manifest['model_bounds']
    x0, z0 = area[0][0], area[0][2]
    nx = math.ceil((area[1][0] - x0) / CELL)
    nz = math.ceil((area[1][2] - z0) / CELL)

    instances, _ = sa_ipl.load_world(W.M.SA_DIR, W.M.IDE_ROOT)
    selected = [i for i in instances if sa_bake.in_area(i, region)]
    cols = A.load_col_index(W.M.SA_DIR)
    cache = sa_bake.ModelCache(W.M.SA_DIR)
    log(f'{profile}: {len(selected)} instances, grid {nx}x{nz}, {time.time() - t0:.0f} s')

    top = np.full(nx * nz, -np.inf)
    owner = np.full(nx * nz, -1, np.int64)
    footprint = np.zeros(len(selected), np.int64)
    drawn_any = np.zeros(nx * nz, bool)
    for n, inst in enumerate(selected):
        model = cache.get(inst['model'])
        if model is None:
            continue
        cells, ys = raster_tops(instance_triangles(inst, model, shift), x0, z0, nx, nz)
        if not len(cells):
            continue
        drawn_any[cells] = True
        if walk_through(inst['model']):
            continue
        order = np.lexsort((ys, cells))           # per cell keep this instance's highest hit
        cells, ys = cells[order], ys[order]
        last = np.r_[cells[1:] != cells[:-1], True]
        cells, ys = cells[last], ys[last]
        footprint[n] = len(cells)
        better = ys > top[cells]
        top[cells[better]] = ys[better]
        owner[cells[better]] = n
        if n % 2000 == 0:
            log(f'  {n}/{len(selected)} rasterised, {time.time() - t0:.0f} s')

    lo, hi = read_boxes(root / 'L23/0x0001D211.L23.scgpc')
    which, cells = box_cells(lo, hi, x0, z0, nx, nz)
    col_top = np.full(nx * nz, -np.inf)
    np.maximum.at(col_top, cells, hi[which, 1])
    # best match: the box top closest to the drawn surface (a box whose span
    # contains the surface also supports it from above-ground layers)
    drawn = np.isfinite(top)
    r = top[cells]
    dist = np.where((lo[which, 1] <= r) & (r <= hi[which, 1]), np.maximum(hi[which, 1] - r, 0), np.abs(hi[which, 1] - r))
    match = np.full(nx * nz, np.inf)
    np.minimum.at(match, cells[np.isfinite(r)], dist[np.isfinite(r)])
    log(f'  {len(lo)} boxes read, {time.time() - t0:.0f} s')

    ok = drawn & (match <= MATCH)
    missing = drawn & ~ok & (col_top < top - GAP)
    phantom = drawn & ~ok & ~missing & (col_top > top + GAP) & (match > GAP)
    shifted = drawn & ~ok & ~missing & ~phantom
    # boxes where nothing at all is drawn: only a problem when they stand up
    # (a box flush with the street next to it is just filler under a prop)
    empty = ~drawn_any & np.isfinite(col_top)

    per = collections.defaultdict(lambda: [0, 0, 0])   # owned, missing, phantom
    for mask, k in ((drawn, 0), (missing, 1), (phantom, 2)):
        idx, cnt = np.unique(owner[mask], return_counts=True)
        for i, c in zip(idx, cnt):
            per[int(i)][k] += int(c)
    bad = []
    for i, (owned, miss, ph) in per.items():
        if i < 0 or owned < MIN_FOOTPRINT_CELLS or miss / owned < REPORT_MISSING:
            continue
        inst = selected[i]
        col = cols.get(inst['model'].lower())
        own = 0.0
        if col is None:
            reason = 'no_col'
        elif C.is_walk_through(inst['model'], col):
            reason = 'prop_filter'
        else:
            # does the instance's own SA COL reach its drawn surface there?
            gone = np.nonzero((owner == i) & missing)[0]
            ct = np.asarray(A.world_triangles(inst, col, shift), np.float64).reshape(-1, 3, 3)
            ccells, cys = raster_tops(ct, x0, z0, nx, nz) if len(ct) else (np.zeros(0, np.int64), np.zeros(0))
            best = np.full(nx * nz, np.inf)
            np.minimum.at(best, ccells, np.abs(cys - top[ccells]))
            own = float((best[gone] <= GAP).mean()) if len(gone) else 0.0
            reason = 'col_lost' if own >= .5 else 'sa_col_gap'
        pos = inst['pos']
        bad.append({'model': inst['model'], 'id': inst['id'], 'reason': reason, 'own_col_covers': round(own, 2),
                    'cells': owned, 'missing': miss, 'missing_fraction': round(miss / owned, 3),
                    'sa': [round(pos[0], 1), round(pos[1], 1), round(pos[2], 1)],
                    'wos': [round(pos[0] + shift[0], 1), round(pos[2] + shift[1], 1), round(pos[1] + shift[2], 1)]})
    bad.sort(key=lambda b: -b['missing'])

    both = drawn & np.isfinite(col_top) & ok
    err = np.abs(np.where(both, match, np.nan))
    anchors = struct.unpack_from('<I', (root / 'sa_runtime/anchors.bin').read_bytes(), 8)[0]
    in_grid = bool((lo[:, 0].min() >= GRID_EDGE[0][0]) & (hi[:, 0].max() <= GRID_EDGE[0][1]) &
                   (lo[:, 2].min() >= GRID_EDGE[1][0]) & (hi[:, 2].max() <= GRID_EDGE[1][1]))
    drawn_n = int(drawn.sum())
    report = {
        'profile': profile, 'source': str(root), 'cell_m': CELL, 'grid': [nx, nz],
        'instances': len(selected), 'boxes': int(len(lo)), 'anchors': anchors,
        'boxes_inside_region_grid': in_grid,
        'drawn_cells': drawn_n,
        'ok': int(ok.sum()), 'missing': int(missing.sum()), 'phantom': int(phantom.sum()),
        'shifted': int(shifted.sum()), 'empty_box_cells': int(empty.sum()),
        'missing_fraction': round(int(missing.sum()) / max(drawn_n, 1), 4),
        'phantom_fraction': round(int(phantom.sum()) / max(drawn_n, 1), 4),
        'height_error_ok_cells_m': {q: round(float(np.nanpercentile(err, p)), 3)
                                    for q, p in (('p50', 50), ('p95', 95), ('p99', 99))},
        'instances_missing_collision': len(bad),
        'by_reason': dict(collections.Counter(b['reason'] for b in bad)),
        'worst': bad[:300],
        'seconds': round(time.time() - t0, 1)}
    maps = {'top': top, 'col_top': col_top, 'ok': ok, 'missing': missing, 'phantom': phantom,
            'shifted': shifted, 'empty': empty, 'nx': nx, 'nz': nz, 'origin': (x0, z0)}
    return report, maps


def save_png(maps, path):
    from PIL import Image
    nx, nz = maps['nx'], maps['nz']
    img = np.zeros((nx * nz, 3), np.uint8)
    img[maps['ok']] = (60, 60, 60)
    img[maps['shifted']] = (200, 200, 0)
    img[maps['phantom']] = (0, 120, 255)
    img[maps['empty']] = (0, 60, 160)
    img[maps['missing']] = (255, 30, 30)
    # rows = z, columns = x; north (larger z) up
    Image.fromarray(img.reshape(nx, nz, 3).transpose(1, 0, 2)[::-1]).save(path)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('profile')
    p.add_argument('--staged', action='store_true', help='read out/full_map/<profile> instead of exWoS')
    p.add_argument('--png')
    p.add_argument('--json')
    a = p.parse_args()
    report, maps = run(a.profile, installed=not a.staged)
    if a.png:
        save_png(maps, a.png)
    text = json.dumps(report, indent=1)
    if a.json:
        Path(a.json).write_text(text)
    summary = {k: v for k, v in report.items() if k != 'worst'}
    print(json.dumps(summary, indent=1))
    for b in report['worst'][:40]:
        print(f"{b['missing']:6d} cells  {b['missing_fraction']:.0%}  {b['reason']:12s} {b['model']:24s} SA {b['sa']}  WoS {b['wos']}")


if __name__ == '__main__':
    main()
