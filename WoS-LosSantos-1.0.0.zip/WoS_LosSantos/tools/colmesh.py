"""
Convex hull collision (.pccvx, resource type 27 "convex_hull_mesh").

A .pccvx is an APKF mini-archive -- the same container as a .pcapk. A prop's
hull archive holds one CVX file; a per-cell archive (E06.pccvx and friends)
holds several, named col_genblock<n>_patch<nnnn>, which is how the city's
static collision is stored. The CVX payload has no pointers, so these archives
carry no patch table and can be rebuilt by size alone.

CVX payload, one convex hull (validated against every shipped hull):

    u32  x4     [vertices_offset, vertex_count, faces_offset, face_count].
                The offsets are in 4-byte words and are measured from the
                start of the IMG COMPONENT, not from the hull -- for a
                single-hull archive that makes the first one 14 (4 header
                words + 4 sphere + 6 AABB), which is why it looks hull-local
                until a multi-hull cell archive proves otherwise. Resizing a
                hull therefore has to rewrite the offsets of every hull after
                it.
    f32  x4     bounding sphere: centre.xyz, radius
    f32  x6     AABB: min.xyz, max.xyz
    f32  x3 * V vertices
    per face (24 bytes):
        u16 x3  vertex indices
        u16     padding (uninitialised in the shipped data)
        f32 x4  face plane: normal.xyz, distance, as n.x == d

The stored AABB is the vertex AABB grown by 0.1 on every axis -- a collision
margin rather than tight bounds.

Collision binds to geometry by NAME HASH: the dumpster's hull is
0x91486138.s_garbg_dumpster000.pccvx, the same hash as its
0x91486138.s_garbg_dumpster000.wrap.mesh, differing only in resource type.
That is also what makes it overridable through exWoS. Props additionally ship
separate proxies named <name>_phys000.
"""

import struct

APKF_MAGIC = b"APKF"
# the PCPACK resource type, confirmed against K07 in MEGACITY.PCPACK
TYPE_PCCVX = 27
AABB_MARGIN = 0.1


class Apkf:
    """APKF reader/rebuilder, following the toolkit's own reader.

    Field positions are recorded so a payload of a different size can be
    written back.
    """

    HEADER = "<4s6I"
    TABLE_HEADER = "<5I"
    COMPONENT = "<4s5I"

    def __init__(self, data):
        self.data = data
        (magic, self.version, self.flag_field, self.bool_field,
         self.component_type_count, component_table_ptr,
         self.file_table_ptr) = struct.unpack_from(self.HEADER, data)
        if magic != APKF_MAGIC:
            raise ValueError(f"not an APKF archive ({magic!r})")
        # the stored pointer skips the five u32s that follow the magic
        self.component_table_offset = component_table_ptr + 20

        # ---- component headers
        self.components = []
        co = self.component_table_offset
        for _ in range(self.component_type_count):
            type_id = data[co:co + 4].rstrip(b"\x00").decode()
            (external_flag, field2, field3, data_size,
             data_offset) = struct.unpack_from("<5I", data, co + 4)
            self.components.append({
                "header_offset": co,
                "type_id": type_id,
                "size_pos": co + 4 + 12,
                "data_size": data_size,
                "data_offset": data_offset,
                "data_start": co + struct.calcsize("<4s4I") + data_offset,
            })
            co += struct.calcsize(self.COMPONENT)

        # ---- file table: group headers run back to back, terminated by a
        # zero word. Each group's file entries live at its own pointer, and
        # the component data cursor advances across the whole archive in file
        # order, not per group.
        self.groups = []
        self.files = []
        cursors = [0] * self.component_type_count
        off = struct.calcsize(self.HEADER)
        while struct.unpack_from("<I", data, off)[0] != 0:
            (type_word, unk0, active_components, p_file_headers,
             file_count) = struct.unpack_from(self.TABLE_HEADER, data, off)
            group_start = off
            alignments = list(struct.unpack_from(
                f"<{self.component_type_count}I", data,
                off + struct.calcsize(self.TABLE_HEADER)))
            off += struct.calcsize(self.TABLE_HEADER)                 + 4 * self.component_type_count
            group = {
                "offset": group_start,
                "file_type": type_word.to_bytes(4, "little")
                             .rstrip(b"\x00").decode(),
                "active_components": active_components,
                "file_count": file_count,
                "alignments": [a & 0xFFFFFF for a in alignments],
                "entry_base": group_start + 12 + p_file_headers,
                "files": [],
            }
            entry = group["entry_base"]
            for _ in range(file_count):
                p_filename, name_hash = struct.unpack_from("<2I", data, entry)
                sizes_pos = entry + 8
                sizes = list(struct.unpack_from(
                    f"<{active_components}I", data, sizes_pos))
                name_start = entry + p_filename
                name_end = data.index(b"\x00", name_start)
                slices = []
                for i, size in enumerate(sizes):
                    align = group["alignments"][i] or 1
                    read_pos = ((cursors[i] - 1) + align) & ~(align - 1)
                    start = self.components[i]["data_start"] + read_pos
                    slices.append((start, start + size))
                    cursors[i] = read_pos + size
                f = {
                    "entry_offset": entry,
                    "name_hash": name_hash,
                    "name": data[name_start:name_end].decode(),
                    "file_type": group["file_type"],
                    "sizes_pos": sizes_pos,
                    "sizes": sizes,
                    "slices": slices,
                }
                group["files"].append(f)
                self.files.append(f)
                entry = sizes_pos + 4 * active_components
            group["entry_end"] = entry
            self.groups.append(group)
        self.file_table_end = off

    # ---- reading
    def file_data(self, f, component=0):
        start, end = f["slices"][component]
        return self.data[start:end]

    def component_data(self, index=0):
        c = self.components[index]
        return self.data[c["data_start"]:c["data_start"] + c["data_size"]]

    # ---- writing
    def rebuild(self, payloads, component=0):
        """Rebuild with new payloads: {file index within the archive: bytes}.

        Only the chosen component is re-laid out, which is all .pccvx needs
        (they have a single IMG component and no patch table).
        """
        if self.component_type_count != 1:
            raise NotImplementedError(
                f"rebuild handles single-component archives; this one has "
                f"{self.component_type_count}")
        c = self.components[component]
        blob = bytearray()
        new_sizes = {}
        for group in self.groups:
            align = group["alignments"][component] or 1
            for f in group["files"]:
                idx = self.files.index(f)
                data = payloads.get(idx)
                if data is None:
                    data = self.file_data(f, component)
                read_pos = ((len(blob) - 1) + align) & ~(align - 1)
                blob += b"\x00" * (read_pos - len(blob))
                blob += data
                new_sizes[f["sizes_pos"]] = len(data)

        start = c["data_start"]
        end = start + c["data_size"]
        out = bytearray(self.data[:start]) + blob + bytearray(self.data[end:])
        struct.pack_into("<I", out, c["size_pos"], len(blob))
        for pos, size in new_sizes.items():
            struct.pack_into("<I", out, pos, size)
        return bytes(out)


class Hull:
    """One convex hull: vertices, triangles with planes, sphere and AABB."""

    HEADER = "<4I"
    SPHERE = "<4f"
    AABB = "<6f"
    FACE = "<4H4f"
    WORD = 4
    FIXED = 16 + 16 + 24   # header + sphere + aabb

    def __init__(self, payload, start=0):
        """`payload` is the whole IMG component; `start` is this hull's byte
        offset inside it, since the stored offsets are component-relative."""
        self.payload = payload
        self.start = start
        (vertices_words, self.vertex_count, faces_words,
         self.face_count) = struct.unpack_from(self.HEADER, payload, start)
        self.vertices_offset = vertices_words * self.WORD
        self.faces_offset = faces_words * self.WORD
        off = start + struct.calcsize(self.HEADER)
        self.sphere = struct.unpack_from(self.SPHERE, payload, off)
        self.aabb = struct.unpack_from(self.AABB, payload,
                                       off + struct.calcsize(self.SPHERE))
        self.vertices = [
            struct.unpack_from("<3f", payload, self.vertices_offset + 12 * i)
            for i in range(self.vertex_count)]
        self.faces = []
        for i in range(self.face_count):
            a, b, c, pad, nx, ny, nz, d = struct.unpack_from(
                self.FACE, payload, self.faces_offset + 24 * i)
            self.faces.append({"indices": (a, b, c), "pad": pad,
                               "plane": (nx, ny, nz, d)})
        self.end = self.faces_offset + 24 * self.face_count

    def serialize(self, base):
        """Bytes for this hull when it will sit at byte offset `base` inside
        the component, with the offset words recomputed for that position."""
        verts_at = base + self.FIXED
        faces_at = verts_at + 12 * len(self.vertices)
        if verts_at % self.WORD or faces_at % self.WORD:
            raise ValueError("hull must start on a 4-byte boundary")
        out = bytearray()
        out += struct.pack(self.HEADER, verts_at // self.WORD,
                           len(self.vertices), faces_at // self.WORD,
                           len(self.faces))
        out += struct.pack(self.SPHERE, *self.sphere)
        out += struct.pack(self.AABB, *self.aabb)
        for v in self.vertices:
            out += struct.pack("<3f", *v)
        for f in self.faces:
            out += struct.pack(self.FACE, *f["indices"], f["pad"],
                               *f["plane"])
        return bytes(out)

    @property
    def size(self):
        return self.FIXED + 12 * len(self.vertices) + 24 * len(self.faces)

    def bounds(self):
        lo = [min(v[i] for v in self.vertices) for i in range(3)]
        hi = [max(v[i] for v in self.vertices) for i in range(3)]
        return lo, hi

    def plane_error(self, face):
        """How far the face's own vertices sit off its stored plane."""
        nx, ny, nz, d = face["plane"]
        worst = 0.0
        for i in face["indices"]:
            if i >= len(self.vertices):
                return float("inf")
            x, y, z = self.vertices[i]
            worst = max(worst, abs(nx * x + ny * y + nz * z - d))
        return worst


def hulls_in(payload, start=0, end=None):
    """Walk the hulls packed back to back in [start, end) of a component."""
    if end is None:
        end = len(payload)
    hulls = []
    pos = start
    while pos + Hull.FIXED <= end:
        h = Hull(payload, pos)
        if h.end <= pos:
            raise ValueError(f"hull at 0x{pos:X} does not advance")
        hulls.append(h)
        pos = h.end
    return hulls, pos - start


def read_pccvx(path):
    """-> (archive, [(file entry, [hulls])])"""
    apkf = Apkf(open(path, "rb").read())
    blob = apkf.component_data(0)
    base = apkf.components[0]["data_start"]
    out = []
    for f in apkf.files:
        start = f["slices"][0][0] - base
        size = f["sizes"][0]
        hulls, consumed = hulls_in(blob, start, start + size)
        out.append((f, hulls, consumed))
    return apkf, out


def layout_bases(apkf, sizes_by_file, component=0):
    """Byte offset inside the component where each file's data will start,
    using the same alignment rule the archive reader applies."""
    bases = []
    pos = 0
    for group in apkf.groups:
        align = group["alignments"][component] or 1
        for f in group["files"]:
            idx = apkf.files.index(f)
            read_pos = ((pos - 1) + align) & ~(align - 1)
            bases.append(read_pos)
            pos = read_pos + sizes_by_file[idx]
    return bases


def build_pccvx(apkf, hulls_by_file, component=0):
    """Rebuild an archive from hulls.

    `hulls_by_file` maps file index -> list of Hull objects. Because hull
    offsets are component-global, every hull is re-serialized at its new
    position, not just the ones that changed.
    """
    blob = apkf.component_data(component)
    base = apkf.components[component]["data_start"]

    current = {}
    for idx, f in enumerate(apkf.files):
        if idx in hulls_by_file:
            current[idx] = list(hulls_by_file[idx])
        else:
            start = f["slices"][component][0] - base
            hulls, _ = hulls_in(blob, start, start + f["sizes"][component])
            current[idx] = hulls

    sizes = {idx: sum(h.size for h in hulls) for idx, hulls in current.items()}
    bases = layout_bases(apkf, sizes, component)

    payloads = {}
    for idx in range(len(apkf.files)):
        pos = bases[idx]
        parts = []
        for h in current[idx]:
            parts.append(h.serialize(pos))
            pos += h.size
        payloads[idx] = b"".join(parts)
    return apkf.rebuild(payloads, component)
