"""
Build Los Santos for Spider-Man: Web of Shadows from the player's own files.

This is the build half of the public installer (Install.ps1 runs it, then copies
the result into exWoS). It ships no GTA San Andreas or Web of Shadows data: the
map, textures, collision, street graph and the two patched WoS meshes are all
made here from the San Andreas and WoS installs on this PC. The symbiote goo
webs (sa_goo.py) are not part of this build.

    py -3 ls_builder.py --sa "<GTA San Andreas folder>" [--game "<WoS folder>"] [--keep-work]

Steps, each tool in its own process:
  1. gta3.img: every dff/txd/col/ipl/dat entry -> work/sa_img (sector-padded,
     as the tools were developed against)
  2. WoS packs (wos_extract.py): 4 megacity.pcapk members -> work/megacity_apk;
     the L23 collision template, the street graph and the empty traffic-light
     file -> out/
  3. build_sa_tiles, rebuild_collision --staged-only, make_support_grid,
     make_ocean_fill, build_gbmap, test_sa_tiles
  4. the collision layout must equal the one SA_CollisionLoader.dll was built
     for (collision_loader/foundation_profile.h); every output is compared
     with reference.json (a difference there means a modded San Andreas)
  5. the exWoS folder is staged in work/stage/SA_ls_full; result.json beside it

Writes only below its own folder. Exit codes: 0 ok, 2 bad input, 3 missing
Python module, 4 collision layout does not match the DLL, 5 a tool failed.
"""
import argparse
import hashlib
import json
import os
import shutil
import struct
import subprocess
import sys
import time
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
ROOT = TOOLS.parent
WORK = ROOT / 'work'
OUT = ROOT / 'out'
PROFILE = 'SA_ls_full'
STAGED = OUT / 'full_map' / PROFILE
DLL_HEADER = ROOT / 'collision_loader' / 'foundation_profile.h'

# The profile the shipped DLL was built and tested for (HANDOFF_SA_RU.md).
TILES_ARGS = ['--profile', PROFILE, '--box', '0,-2800,3000,-500',
              '--shift', '1000,-7.5,2200', '--anchor-step', '16']
SA_EXTENSIONS = {'.dff', '.txd', '.col', '.ipl', '.dat'}
APK_HASH = 0xEE185533
# megacity.pcapk members the tools read: the ocean carrier (trigger template),
# the ocean ring (filled under Los Santos), the facade material every runtime
# batch is drawn with and its texture.
APK_MEMBERS = [('MESH', 0xD9CB2AAA), ('MESH', 0xD9CB2AAB),
               ('MAT', 0x01115646), ('TEX', 0xB3A64279)]
OCEAN_TRIGGER = '0xD9CB2AAA.s_nat_ocean000.wrap.mesh'
OCEAN_FILL = '0xD9CB2AAB.s_nat_ocean001.wrap.mesh'
PACK_DIR = 'MEGACITY/0xEE185533.T25.megacity.pcapk'

EXIT_INPUT, EXIT_MODULE, EXIT_LAYOUT, EXIT_TOOL = 2, 3, 4, 5


class Stop(Exception):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def say(msg):
    print(msg, flush=True)


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


# --- checks -------------------------------------------------------------------

def check_python():
    if sys.version_info < (3, 10):
        raise Stop(EXIT_MODULE, f'Python 3.10 or newer is needed (this is {sys.version.split()[0]}).')
    missing = []
    for module, package in (('PIL', 'pillow'), ('numpy', 'numpy'), ('shapely', 'shapely')):
        try:
            __import__(module)
        except ImportError:
            missing.append(package)
    if missing:
        raise Stop(EXIT_MODULE, 'missing Python packages: ' + ' '.join(missing) +
                   f'\n  install them with: "{sys.executable}" -m pip install --user ' + ' '.join(missing))


def check_sa(sa):
    img = sa / 'models' / 'gta3.img'
    if not img.is_file():
        hint = (' This looks like the Definitive Edition, which is not supported.'
                if (sa / 'Gameface').exists() else '')
        raise Stop(EXIT_INPUT, f'no models/gta3.img in "{sa}".{hint} Point --sa at the classic PC San Andreas folder.')
    with open(img, 'rb') as f:
        if f.read(4) != b'VER2':
            raise Stop(EXIT_INPUT, f'{img} is not a San Andreas (VER2) archive.')
    for rel in ('data/gta.dat', 'data/maps'):
        if not (sa / rel).exists():
            raise Stop(EXIT_INPUT, f'"{sa}" has no {rel}.')
    return img


def check_wos(game):
    packs = game / 'packs'
    for name in ('MEGACITY.PCPACK', 'L23.PCPACK', 'E05.PCPACK'):
        if not (packs / name).is_file():
            raise Stop(EXIT_INPUT, f'no packs/{name} in "{game}" (is --game the Web of Shadows folder?)')
    return packs


# --- step 1: San Andreas archive ------------------------------------------------

def extract_img(img, out):
    """Write every entry the tools read, padded to whole sectors like gta3img dumps."""
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)
    count = 0
    with open(img, 'rb') as f:
        _, n = struct.unpack('<4sI', f.read(8))
        table = [struct.unpack('<IHH24s', f.read(32)) for _ in range(n)]
        for offset, stream, archive, raw in table:
            name = raw.split(b'\0')[0].decode('latin1')
            if Path(name).suffix.lower() not in SA_EXTENSIONS:
                continue
            f.seek(offset * 2048)
            data = f.read((stream or archive) * 2048)
            (out / name).write_bytes(data)
            count += 1
    return count


# --- step 2: Web of Shadows packs -----------------------------------------------

def extract_wos(packs):
    import wos_extract as X
    apk_dir = WORK / 'megacity_apk'
    apk_dir.mkdir(parents=True, exist_ok=True)
    pack = X.Pack(packs / 'MEGACITY.PCPACK')
    apk = X.Apk(pack, pack.find(APK_HASH, 25))
    for type_, name_hash in APK_MEMBERS:
        f = apk.find(type_, name_hash)
        (apk_dir / f.out_name).write_bytes(apk.wrap_file(f))
    # build_gbmap: the New York street graph it replaces, and the empty
    # traffic-light file written for every region (only the names of the
    # others matter; they come from traffic_lights.json)
    nav = OUT / 'nav'
    (nav / 'megacity').mkdir(parents=True, exist_ok=True)
    (nav / 'megacity' / 'megacity_t12.bin').write_bytes(pack.data(pack.find(APK_HASH, 12)))
    empty = X.extract_entry(packs / 'E05.PCPACK', 0x0001B40A, 13)
    lights = nav / '13'
    if lights.exists():
        shutil.rmtree(lights)
    lights.mkdir(parents=True)
    for name in json.loads((TOOLS / 'traffic_lights.json').read_text()):
        (lights / f'{name}.bin').write_bytes(empty)
    # rebuild_collision: L23's own collision, which the Los Santos boxes extend
    research = OUT / 'full_map' / 'collision_research' / 'L23'
    research.mkdir(parents=True, exist_ok=True)
    (research / 'type_74_0001D211.bin').write_bytes(
        X.extract_entry(packs / 'L23.PCPACK', 0x0001D211, 74))
    return apk_dir


# --- step 3: the tools ------------------------------------------------------------

def run_tool(env, script, *args):
    t = time.time()
    say(f'\n>>> {script} {" ".join(args)}')
    rc = subprocess.call([sys.executable, '-B', str(TOOLS / script), *args], cwd=TOOLS, env=env)
    if rc:
        raise Stop(EXIT_TOOL, f'{script} failed (exit {rc}); see the output above.')
    say(f'<<< {script}: {time.time() - t:.0f} s')


# --- step 4: checks -----------------------------------------------------------------

def header_constants(path):
    out = {}
    for line in path.read_text().splitlines():
        line = line.strip()
        if line.startswith('constexpr'):
            name, value = line.split('=', 1)
            out[name.split()[-1].split('[')[0]] = value.rstrip(';').strip()
    return out


def stage_files():
    """exWoS-relative path -> built file, everything the profile folder holds."""
    files = {
        'L23/0x0001D211.L23.scgpc': STAGED / 'L23/0x0001D211.L23.scgpc',
        f'{PACK_DIR}/{OCEAN_TRIGGER}': STAGED / PACK_DIR / OCEAN_TRIGGER,
        f'{PACK_DIR}/{OCEAN_FILL}': STAGED / PACK_DIR / OCEAN_FILL,
        'sa_runtime/world.bin': STAGED / 'sa_runtime/world.bin',
        'sa_runtime/textures.bin': STAGED / 'sa_runtime/textures.bin',
        'sa_runtime/anchors.bin': STAGED / 'sa_runtime/anchors.bin',
        'sa_runtime/support.bin': STAGED / 'sa_runtime/support.bin',
        'sa_runtime/city.ini': ROOT / 'data' / 'city.ini',
        'manifest.json': STAGED / 'manifest.json',
    }
    for p in sorted((STAGED / 'teleports').glob('*.txt')):
        files[f'teleports/{p.name}'] = p
    for p in sorted((STAGED / 'npc').rglob('*')):
        if p.is_file():
            files['npc/' + p.relative_to(STAGED / 'npc').as_posix()] = p
    return files


def compare_reference(files):
    reference = json.loads((TOOLS / 'reference.json').read_text())['sha256']
    same, different, unchecked = [], [], []
    for rel, path in files.items():
        want = reference.get(rel)
        if want is None:
            unchecked.append(rel)
        elif sha256(path) == want:
            same.append(rel)
        else:
            different.append(rel)
    missing = sorted(set(reference) - set(files))
    return same, different, unchecked, missing


# --- main -----------------------------------------------------------------------

def build(a):
    t0 = time.time()
    game = Path(a.game).resolve()
    sa = Path(a.sa).resolve()
    if (ROOT / 'HANDOFF_SA_RU.md').exists():
        raise Stop(EXIT_INPUT, 'this is the development tree (WoS_Arena); run the installer copy instead.')
    check_python()
    img = check_sa(sa)
    packs = check_wos(game)
    if not DLL_HEADER.is_file():
        raise Stop(EXIT_INPUT, f'missing {DLL_HEADER} (part of the package).')

    say(f'[1/5] reading {img}')
    try:
        count = extract_img(img, WORK / 'sa_img')
    except (OSError, ValueError, struct.error) as ex:
        raise Stop(EXIT_INPUT, f'cannot read {img}: {ex}')
    say(f'      {count} files')

    say(f'[2/5] reading the Web of Shadows packs in {packs}')
    try:
        apk_dir = extract_wos(packs)
    except (OSError, ValueError, KeyError, struct.error) as ex:
        raise Stop(EXIT_INPUT, f'cannot read the Web of Shadows packs ({ex}); they may be damaged or modded.')

    say('[3/5] building Los Santos (several minutes, several GB of memory)')
    if STAGED.exists():
        shutil.rmtree(STAGED)
    env = dict(os.environ, WOS_GAME=str(game), WOS_SA_DATA=str(sa / 'data'),
               WOS_SA_DIR=str(WORK / 'sa_img'), WOS_MEGACITY_APK=str(apk_dir),
               PYTHONIOENCODING='utf-8')
    run_tool(env, 'build_sa_tiles.py', *TILES_ARGS)
    run_tool(env, 'rebuild_collision.py', PROFILE, '--staged-only')
    run_tool(env, 'make_support_grid.py', PROFILE)
    run_tool(env, 'make_ocean_fill.py', '--profile', PROFILE)
    run_tool(env, 'build_gbmap.py', '--profile', PROFILE)
    run_tool(env, 'test_sa_tiles.py', PROFILE)

    say('[4/5] checking the result')
    built, shipped = header_constants(STAGED / 'foundation_profile.h'), header_constants(DLL_HEADER)
    if built != shipped:
        diff = {k: (built.get(k), shipped.get(k)) for k in sorted(set(built) | set(shipped))
                if built.get(k) != shipped.get(k)}
        raise Stop(EXIT_LAYOUT,
                   'the collision built from this San Andreas does not match the one the DLL '
                   'was made for, so Los Santos would have no ground. Usually a mod changed '
                   'San Andreas collision (.col) files; build from an unmodded gta3.img.\n  '
                   + json.dumps(diff))
    files = stage_files()
    for rel, path in files.items():
        if not path.is_file():
            raise Stop(EXIT_TOOL, f'expected output missing: {path}')
    same, different, unchecked, missing = compare_reference(files)
    say(f'      collision layout matches the DLL; {len(same)} files identical to the '
        f'reference build, {len(different)} different')
    for rel in different:
        say(f'      differs: {rel}')
    if missing:
        raise Stop(EXIT_TOOL, 'outputs missing against reference.json: ' + ', '.join(missing))

    say('[5/5] staging')
    stage = WORK / 'stage' / PROFILE
    if stage.parent.exists():
        shutil.rmtree(stage.parent)
    for rel, path in files.items():
        dst = stage / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        if path.is_relative_to(STAGED) and not a.keep_work:
            shutil.move(path, dst)
        else:
            shutil.copy2(path, dst)
    result = {
        'profile': PROFILE,
        'stage': str(stage),
        'files': len(files),
        'identical_to_reference': len(same),
        'different_from_reference': different,
        'sa': str(sa),
        'gta3img_bytes': img.stat().st_size,
        'seconds': round(time.time() - t0),
    }
    (stage.parent / 'result.json').write_text(json.dumps(result, indent=2))
    if not a.keep_work:
        for p in (WORK / 'sa_img', WORK / 'megacity_apk', OUT):
            shutil.rmtree(p, ignore_errors=True)
    say(f'done in {result["seconds"]} s: {stage}')


def main():
    p = argparse.ArgumentParser(description=__doc__.split('\n\n')[0])
    p.add_argument('--sa', required=True, help='GTA San Andreas folder (with models/gta3.img)')
    p.add_argument('--game', default=str(ROOT.parent), help='Web of Shadows folder (default: the one above WoS_LosSantos)')
    p.add_argument('--keep-work', action='store_true', help='keep the extracted files and out/ for inspection')
    a = p.parse_args()
    try:
        build(a)
    except Stop as ex:
        say(f'\nERROR: {ex}')
        sys.exit(ex.code)


if __name__ == '__main__':
    main()
