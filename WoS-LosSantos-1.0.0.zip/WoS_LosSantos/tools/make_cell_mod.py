"""
A textured district on a CELL carrier, which is where the slots are.

`s_nat_ocean000` proved the chain but has two slots, so two textures, so two
thirds of the district had to be left out. A cell's `<cell>_final_lod000` has
up to 14, and every city cell ships one -- that is the whole texture budget,
since a mesh has exactly as many materials as slots and the city tiles its
textures too heavily for an atlas to stand in.

Three things make a cell usable that were not true before:

  * its world offset. The mesh is authored in the cell's local space; the grid
    in `cell_offsets.py` pins it. M10 sits at (-450, 1500) and its local ground
    is within a metre of world y = 0, so no vertical shift is needed.
  * its materials are its own. `m10_final_lod*` is used by nothing else, so
    repointing them disturbs only this cell.
  * somewhere to put the pixels. Overriding a texture hits every material that
    samples it, and a cell's own textures are shared by hundreds -- `road_lod`
    alone has 187 users. So the pixels go into EXCLUSIVE textures instead:
    203 of the pack's 407 are sampled by exactly one material, which makes
    them nearly free to overwrite. Each slot's material is then pointed at one.

What this build is meant to answer: `final_lod` is far-view geometry, so it may
well be hidden as the player gets close. If the district vanishes on approach,
cells are the wrong carrier for anything but the skyline.

    python make_cell_mod.py [CELL]
"""

import glob
import json
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import make_map_mod as M
import make_texture_mod as T
import meshpack
import sa_bake
import wos_tex
import wrapmesh

PACK = "MEGACITY/0xEE185533.T25.megacity.pcapk"
TEX_DIR = M.GAME + "/WoS_VolumetricClouds/extracted/MEGACITY/MEGACITY/" \
                   "_0xEE185533.megacity.pcapk"
OFFSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..",
                       "out", "cells", "offsets.json")

DEFAULT_CELL = "M10"
CENTRE = (1500.0, -1700.0)      # downtown Los Santos
CELL_HALF = 150.0               # cells are 300 m square


def resource_name(path):
    return os.path.basename(path)


def hash_of(path):
    return int(os.path.basename(path)[2:10], 16)


def material_texture(mat_bytes):
    """-> the texture hash a .mat samples, and where that field sits."""
    m, _ = wrapmesh.parse_container(mat_bytes)
    for i, (tag, h, _, _) in enumerate(m.ext_patches):
        if tag == b"TEX\x00":
            return h, m.ext.target + i * 16 + 4
    raise ValueError("material has no TEX patch")


def repoint_texture(mat_bytes, new_hash):
    """Point a .mat at a different texture, in place.

    The hash is a plain u32 in the ext-patch table, so nothing moves and the
    relocation table is untouched -- the same trick as repointing a mesh's
    materials.
    """
    _, off = material_texture(mat_bytes)
    out = bytearray(mat_bytes)
    struct.pack_into("<I", out, off, new_hash)
    got, _ = material_texture(bytes(out))
    if got != new_hash:
        raise AssertionError("texture repoint did not take")
    return bytes(out)


# A victim is overwritten wherever it appears, so prefer ones whose single
# user is scenery nobody studies, and keep away from faces, UI tokens and
# effects -- those are the ones a player would notice going wrong.
VICTIM_AVOID = ("ch_", "tkn_", "fx_", "hud", "ui_", "msm_", "font")
VICTIM_PREFER = ("s_blg", "s_nat", "lod", "s_rf", "s_prop")


def victim_rank(path):
    n = os.path.basename(path).split(".", 1)[-1].lower()
    if any(k in n for k in VICTIM_AVOID):
        return 2
    if any(k in n for k in VICTIM_PREFER):
        return 0
    return 1


def exclusive_textures():
    """Textures sampled by exactly one material, as override targets.

    Overwriting one of these disturbs a single material rather than the
    hundreds that share a cell's own road or sidewalk texture.
    """
    users = {}
    mats = {}
    for p in glob.glob(os.path.join(glob.escape(TEX_DIR), "*.wrap.mat")):
        try:
            h, _ = material_texture(open(p, "rb").read())
        except Exception:
            continue
        users[h] = users.get(h, 0) + 1
        mats.setdefault(h, p)
    out = []
    for h, n in users.items():
        if n != 1:
            continue
        found = glob.glob(os.path.join(glob.escape(TEX_DIR), f"0x{h:08X}.*.wrap.tex"))
        if not found:
            continue
        try:
            t = wos_tex.Tex(open(found[0], "rb").read())
        except Exception:
            continue
        if t.compressed and t.depth == 1:
            out.append((h, found[0]))
    return sorted(out, key=lambda hp: (victim_rank(hp[1]), hp[1]))


def main():
    cell = (sys.argv[1] if len(sys.argv) > 1 else DEFAULT_CELL).upper()
    with open(OFFSETS, encoding="utf-8") as fh:
        offsets = json.load(fh)
    if cell not in offsets or not offsets[cell]["ok"]:
        raise SystemExit(f"{cell} has no confident world offset")
    ox, oz = offsets[cell]["offset"]

    carrier = glob.glob(os.path.join(glob.escape(TEX_DIR),
                                     f"*.{cell.lower()}_final_lod000.wrap.mesh"))
    if not carrier:
        raise SystemExit(f"no final_lod000 carrier for {cell}")
    carrier = carrier[0]
    data = open(carrier, "rb").read()
    cm = wrapmesh.parse(data)
    slots = len(cm.meshes)
    mat_hashes = [h for t, h, _, _ in cm.ext_patches if t == b"MAT\x00"]
    # a slot whose material samples no texture cannot carry one, so it is left
    # holding the city's own LOD geometry rather than being filled
    usable = []
    for i, mh in enumerate(mat_hashes[:slots]):
        found = glob.glob(os.path.join(glob.escape(TEX_DIR), f"0x{mh:08X}.*.wrap.mat"))
        if not found:
            continue
        try:
            material_texture(open(found[0], "rb").read())
        except Exception:
            continue
        usable.append(i)

    print(f"{cell}: carrier {resource_name(carrier)}")
    print(f"  {slots} slots, {len(set(mat_hashes))} distinct materials, "
          f"{len(usable)} slots whose material samples a texture, "
          f"world offset ({ox:.0f}, {oz:.0f})")

    print("loading San Andreas placement...")
    instances = sa_bake.load_placement(M.SA_DIR, ["*.ipl"], M.IDE_ROOT)
    cache = sa_bake.ModelCache(M.SA_DIR)
    sel = [i for i in instances if sa_bake.in_region(i, CENTRE, CELL_HALF)]
    groups, skipped = sa_bake.bake(sel, cache)
    sources = T.texture_sources(sel, M.IDE_ROOT, M.SA_DIR)
    print(f"  {len(sel)} instances, {len(groups)} texture groups, "
          f"{len(sources)} textures available")

    ranked = sorted(((T.group_area(g), k) for k, g in groups.items()),
                    reverse=True)
    total_area = sum(a for a, _ in ranked)
    chosen = []
    for area, name in ranked:
        tex = sources.get(name.lower())
        if tex is None or tex.fourcc not in (b"DXT1", b"DXT3", b"DXT5"):
            continue
        if len(groups[name]["vertices"]) > 0xFFFF:
            continue
        chosen.append((name, tex, area))
        if len(chosen) == len(usable):
            break
    covered = sum(a for _, _, a in chosen) / total_area
    print(f"  taking the {len(chosen)} biggest by area: "
          f"{covered:.1%} of the district's surface")

    victims = exclusive_textures()
    if len(victims) < len(chosen):
        raise SystemExit(f"only {len(victims)} exclusive textures available")
    print(f"  {len(victims)} exclusive textures to overwrite; using "
          f"{len(chosen)}")

    # geometry: local space, district centred on the cell's own origin
    lo = [min(min(groups[n]["vertices"], key=lambda v: v[k])[k]
              for n, _, _ in chosen) for k in range(3)]
    hi = [max(max(groups[n]["vertices"], key=lambda v: v[k])[k]
              for n, _, _ in chosen) for k in range(3)]
    mid = [(lo[k] + hi[k]) / 2 for k in range(3)]
    shift = (-mid[0], -lo[1], -mid[2])

    replacements = {}
    for n, (name, tex, area) in enumerate(chosen):
        g = dict(groups[name])
        g["vertices"] = [(v[0] + shift[0], v[1] + shift[1], v[2] + shift[2])
                         for v in g["vertices"]]
        replacements[usable[n]] = M.to_records(g)

    column = M.marker_column((0.0, 0.0, 0.0))
    mverts, mtris = M.to_records(column, double_sided=True)
    thin = min(replacements, key=lambda k: len(replacements[k][0]))
    verts, tris = replacements[thin]
    base = len(verts)
    replacements[thin] = (verts + mverts,
                          tris + [(a + base, b + base, c + base)
                                  for a, b, c in mtris])

    bounds = meshpack.required_model_bounds(data, replacements)
    mesh = meshpack.build_mesh_file(data, replacements, model_bounds=bounds)
    # checked per SLOT, not per list position: unusable slots are skipped, so
    # the filled ones are not contiguous
    check = wrapmesh.parse(mesh)
    worst = 0.0
    for slot, (verts, tris) in replacements.items():
        got, _ = meshpack.world_geometry(check, slot)
        if len(got) != len(verts):
            raise SystemExit(f"{cell}: slot {slot} has {len(got)} vertices, "
                             f"expected {len(verts)}")
        for want, have in zip(verts, got):
            a = want[(M.POSITION, 0)]
            b = have[(M.POSITION, 0)]
            worst = max(worst, max(abs(x - y) for x, y in zip(a[:3], b[:3])))
    step = max(check.model["bbox"][:3]) / 32767
    print(f"  {len(mesh):,} bytes (template {len(data):,}), worst position "
          f"error {worst:.4g} (quantization step {step:.4g})")
    if worst > step * 1.5:
        raise SystemExit(f"{cell}: position error beyond quantization")

    mod = f"LosSantos_Cell_{cell}"
    # wipe first: a previous run with a different set of victims leaves its
    # overrides behind, and a stale one repaints a texture nothing in this
    # build ever chose
    stale = os.path.join(M.GAME, "exWoS", mod)
    if os.path.isdir(stale):
        removed = 0
        for dirpath, _, files in os.walk(stale):
            for f in files:
                os.remove(os.path.join(dirpath, f))
                removed += 1
        print(f"  cleared {removed} file(s) from a previous build")
    out = M.install(mod, PACK, resource_name(carrier), mesh)
    print(f"  wrote {resource_name(out)}")

    # one exclusive texture per slot, with that slot's material pointed at it
    template = open(victims[0][1], "rb").read()
    for n, (name, tex, area) in enumerate(chosen):
        i = usable[n]
        victim_hash, victim_path = victims[n]
        blob = T.to_wos_texture(tex, template, victim_hash)
        M.install(mod, PACK, resource_name(victim_path), blob)

        mat_path = glob.glob(os.path.join(glob.escape(TEX_DIR),
                                          f"0x{mat_hashes[i]:08X}.*.wrap.mat"))
        if not mat_path:
            raise SystemExit(f"slot {i}: material "
                             f"0x{mat_hashes[i]:08X} not in the pack")
        repointed = repoint_texture(open(mat_path[0], "rb").read(),
                                    victim_hash)
        M.install(mod, PACK, resource_name(mat_path[0]), repointed)
        print(f"  slot{i}: {name!r} {tex.width}x{tex.height} "
              f"{tex.fourcc.decode()} -> {os.path.basename(victim_path)[:28]} "
              f"({area / total_area:5.1%})")

    print(f"\nenable {mod}=1 and every other LosSantos mod off.")
    print(f"The district stands at the centre of cell {cell}, world "
          f"({ox:.0f}, {oz:.0f}), with the 400 m marker column.")


if __name__ == "__main__":
    main()
