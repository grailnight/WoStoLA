"""
Build exWoS mods that put San Andreas map geometry into Web of Shadows.

Two carriers, because they answer different questions:

  * the dumpster (0x91486138) is proven to render and its material is opaque,
    so a block of Los Santos placed in its local space shows whether SA
    geometry, UVs, normals and scale survive the trip. It appears wherever a
    dumpster stands.
  * the ocean (0xD9CB2AAA) spans +-12.7 km symmetrically about the origin, so
    its object transform is almost certainly identity. Baking a district at
    its true SA coordinates therefore tests WORLD PLACEMENT without touching
    the entity data we cannot write.

Unknowns this is meant to expose, not hide:
  - triangle winding. SA and WoS may disagree on which side is front, which
    would cull every face. The block mod emits both windings so something is
    always visible; the world mod does not.

Two things the first build got wrong, both of which closed the game on startup
and are now fixed here: a mesh slot left over was written EMPTY (vertex_count
0), and the ocean's materials were repointed at the dumpster's. See the
comments at each site.
"""

import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import colmesh
import meshpack
import sa_bake
import sa_hulls
import wrapmesh

# The environment overrides are for the public installer (ls_builder.py),
# which builds from the player's own San Andreas and WoS installs.
GAME = os.environ.get("WOS_GAME", "B:/Games/Spider Man - Web of Shadows")
IDE_ROOT = os.environ.get(
    "WOS_SA_DATA", "E:/SteamLibrary/steamapps/common/Grand Theft Auto San Andreas/data")
SA_DIR = os.environ.get("WOS_SA_DIR", "B:/gta files/gta3img")
# extracted megacity.pcapk members (WebOfShadowsTools layout or wos_extract.py)
APK_DIR = os.environ.get(
    "WOS_MEGACITY_APK",
    GAME + "/WoS_VolumetricClouds/extracted/MEGACITY/MEGACITY/_0xEE185533.megacity.pcapk")

DUMPSTER = (GAME + "/WoS_Deferred/offline_gi/extracted/"
            "E18_0x91486138.s_garbg_dumpster000.wrap.mesh")
OCEAN = APK_DIR + "/0xD9CB2AAA.s_nat_ocean000.wrap.mesh"

POSITION, NORMAL, TEXCOORD, COLOR = (meshpack.POSITION, meshpack.NORMAL,
                                     meshpack.TEXCOORD, meshpack.COLOR)


def merge_groups(groups):
    """Flatten the per-texture groups into one vertex/triangle soup."""
    verts, uvs, tris = [], [], []
    for g in groups.values():
        base = len(verts)
        verts += g["vertices"]
        uvs += g["uvs"]
        tris += [(a + base, b + base, c + base) for a, b, c in g["triangles"]]
    return {"vertices": verts, "uvs": uvs, "triangles": tris}


def vertex_normals(group):
    # WoS stores a vertex normal OPPOSITE to cross(b - a, c - a) of its
    # front-facing triangles (every shipped mesh checked does), so the
    # accumulated cross product is negated at the end. Returning +cross put
    # every SA normal inside its building (see flip_normals.py).
    n = [[0.0, 0.0, 0.0] for _ in group["vertices"]]
    for a, b, c in group["triangles"]:
        pa, pb, pc = (group["vertices"][i] for i in (a, b, c))
        ux, uy, uz = (pb[0] - pa[0], pb[1] - pa[1], pb[2] - pa[2])
        vx, vy, vz = (pc[0] - pa[0], pc[1] - pa[1], pc[2] - pa[2])
        nx, ny, nz = (uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx)
        for i in (a, b, c):
            n[i][0] += nx
            n[i][1] += ny
            n[i][2] += nz
    out = []
    for v in n:
        length = math.sqrt(v[0] ** 2 + v[1] ** 2 + v[2] ** 2)
        out.append((0.0, 1.0, 0.0) if length < 1e-12
                   else (-v[0] / length, -v[1] / length, -v[2] / length))
    return out


def to_records(group, double_sided=False):
    normals = vertex_normals(group)
    verts = []
    for i, p in enumerate(group["vertices"]):
        u, v = group["uvs"][i] if i < len(group["uvs"]) else (0.0, 0.0)
        verts.append({
            (POSITION, 0): (p[0], p[1], p[2], 0.0),
            (NORMAL, 0): normals[i] + (0.0,),
            (TEXCOORD, 0): (u, v),
            (COLOR, 0): (255.0, 255.0, 255.0, 255.0),
        })
    tris = list(group["triangles"])
    if double_sided:
        tris += [(c, b, a) for a, b, c in group["triangles"]]
    return verts, tris


def fit_region(centre, radius, cache, instances, budget, shrink=0.8):
    """Shrink the radius until the baked geometry fits the vertex budget."""
    while radius > 10:
        sel = [i for i in instances if sa_bake.in_region(i, centre, radius)]
        groups, skipped = sa_bake.bake(sel, cache)
        merged = sa_bake.compact(merge_groups(groups))
        if len(merged["vertices"]) <= budget:
            return radius, sel, merged, skipped
        radius *= shrink
    raise SystemExit("region will not fit the vertex budget")


def split_for_slots(group, slots, limit=0xFFFF):
    """Cut the district into exactly `slots` pieces.

    Filling every slot is not tidiness: one model box quantizes the whole file,
    so a slot left holding the ocean's original +-12 km geometry stretches the
    box to 24 km and drops the district's precision from half a centimetre to
    nearly forty. Splitting the district across both slots keeps the box tight.
    """
    if slots < 1:
        raise ValueError("at least one mesh slot is required")
    pieces = sa_bake.chunks(group, limit)
    if len(pieces) > slots:
        raise SystemExit(f"geometry needs {len(pieces)} slots, carrier has "
                         f"{slots}")
    # Split an existing piece by triangles, never by a guessed vertex budget:
    # shared vertices can make the latter produce too many pieces.
    while len(pieces) < slots:
        index = max(range(len(pieces)),
                    key=lambda i: len(pieces[i]["triangles"]), default=None)
        if index is None or len(pieces[index]["triangles"]) < 2:
            raise ValueError("not enough triangles to fill nonempty mesh slots")
        piece = pieces[index]
        mid = len(piece["triangles"]) // 2
        halves = [sa_bake.compact(dict(piece, triangles=tris))
                  for tris in (piece["triangles"][:mid], piece["triangles"][mid:])]
        pieces[index:index + 1] = halves
    if sum(len(p["triangles"]) for p in pieces) != len(group["triangles"]):
        raise AssertionError("slot splitting lost triangles")
    return pieces


# The carrier's own two materials both sit on FX 0x18531B51, which only 92 of
# the pack's 2390 materials use -- and the district wearing them reads as a pale
# translucent wall in game. City facades use 0xB124A376 instead. These two are
# opaque, live in the SAME pack (asking the pack for a material it need not hold
# is what killed an earlier build), and are distinct from each other (two MAT
# patches with one hash killed it too).
OPAQUE_MATERIALS = (0x01115646,   # k09_final_lodbrick
                    0x01FB4174)   # k02_final_lodchurchwalls


def repoint_materials(data, hashes=OPAQUE_MATERIALS):
    """Point the mesh's MAT ext-patches at different materials.

    The hash is a plain u32 in the ext-patch table, so this is an in-place
    overwrite: no pointer moves and the relocation table is untouched. A `None`
    leaves that slot's material alone -- the MAT patches are per slot, since
    mesh0's `material` pointer is the first patch and mesh1's is the second, so
    two districts in one file can wear different materials.
    """
    m = wrapmesh.parse(data)
    out = bytearray(data)
    mats = [(i, h) for i, (tag, h, _, _) in enumerate(m.ext_patches)
            if tag == b"MAT\x00"]
    if len(mats) != len(hashes):
        raise SystemExit(f"carrier has {len(mats)} materials, "
                         f"{len(hashes)} given")
    final = [old if want is None else want
             for (_, old), want in zip(mats, hashes)]
    # Repeated MAT hashes are valid: shipped k02_final_lod000 has 15 MAT
    # records but only 13 unique materials. Each record patches its own field.
    for (slot, _), want in zip(mats, hashes):
        if want is None:
            continue
        off = m.ext.target + slot * 16 + 4
        out[off:off + 4] = want.to_bytes(4, "little")
    check = wrapmesh.parse(bytes(out))
    got = [h for tag, h, _, _ in check.ext_patches if tag == b"MAT\x00"]
    if got != final:
        raise SystemExit(f"material repoint did not take: {got}")
    return bytes(out)


def install(mod_name, pack_dir, resource, data):
    path = os.path.join(GAME, "exWoS", mod_name, pack_dir)
    os.makedirs(path, exist_ok=True)
    target = os.path.join(path, resource)
    with open(target, "wb") as fh:
        fh.write(data)
    return target


def verify(data, pieces, template_len, label):
    m = wrapmesh.parse(data)
    worst = 0.0
    total_tris = 0
    for i, piece in enumerate(pieces):
        got, gt = meshpack.world_geometry(m, i)
        total_tris += len(gt)
        if len(got) != len(piece["vertices"]):
            raise SystemExit(f"{label}: mesh{i} vertex count "
                             f"{len(got)} != {len(piece['vertices'])}")
        for want, have in zip(piece["vertices"], got):
            p = have[(POSITION, 0)]
            worst = max(worst, max(abs(a - b) for a, b in zip(want, p[:3])))
    step = max(m.model["bbox"][:3]) / 32767
    print(f"  {label}: {len(data):,} bytes (template {template_len:,}), "
          f"{total_tris:,} triangles, worst position error {worst:.4g} "
          f"(quantization step {step:.4g})")
    if worst > step * 1.5:
        raise SystemExit(f"{label}: position error beyond quantization")


def build_block(instances, cache, centre, radius):
    """A block of Los Santos in the dumpster slot, in the prop's local space."""
    data = open(DUMPSTER, "rb").read()
    m = wrapmesh.parse(data)
    slots = len(m.meshes)
    radius, sel, merged, skipped = fit_region(centre, radius, cache,
                                              instances, 0xFFFF // 2)
    # centre it on the prop's own origin so it stands where dumpsters stand
    lo, hi = sa_bake.bounds(merged)
    mid = [(lo[i] + hi[i]) / 2 for i in range(3)]
    merged["vertices"] = [(v[0] - mid[0], v[1] - lo[1], v[2] - mid[2])
                          for v in merged["vertices"]]
    verts, tris = to_records(merged, double_sided=True)
    print(f"  block: radius {radius:.0f} m, {len(sel)} instances, "
          f"{len(verts)} verts, {len(tris)} triangles (both windings)")

    # slots we do not fill are LEFT ALONE. Emptying one writes a mesh with
    # vertex_count 0 and index_count 0, which the engine will not draw -- the
    # first build did that to the dumpster's second mesh and the game closed
    # on startup. build_mesh_file requantizes untouched meshes against the new
    # model box, so they keep their world positions.
    replacements = {0: (verts, tris)}
    bounds = meshpack.required_model_bounds(data, replacements)
    out = meshpack.build_mesh_file(data, replacements, model_bounds=bounds)
    verify(out, [{"vertices": [v[(POSITION, 0)][:3] for v in verts]}],
           len(data), "block")
    return out


def build_world(instances, cache, centre, radius):
    """A district in the ocean slot, at its true San Andreas coordinates."""
    data = open(OCEAN, "rb").read()
    m = wrapmesh.parse(data)
    slots = len(m.meshes)
    radius, sel, merged, skipped = fit_region(centre, radius, cache,
                                              instances, 0xFFFF * slots)
    pieces = split_for_slots(merged, slots)
    print(f"  world: radius {radius:.0f} m, {len(sel)} instances, "
          f"{len(merged['vertices'])} verts in {len(pieces)} slot(s)")

    replacements = {i: to_records(pieces[i]) for i in range(len(pieces))}
    bounds = meshpack.required_model_bounds(data, replacements)
    out = meshpack.build_mesh_file(data, replacements, model_bounds=bounds)
    # the materials are LEFT ALONE. The premise that this object wears a water
    # shader was wrong: ocean000's two MAT patches are s_nat_oceanlandy
    # (0x7D9A2F12) and s_nat_oceanbreakwater (0x20DF64C2), both opaque terrain;
    # the water material 0x76598602 belongs to ocean001. Repointing them at the
    # dumpster's 0xF2E9D8AD asked the world pack for a material it need not
    # hold, and put the same hash in the patch table twice.
    verify(out, [{"vertices": [v[(POSITION, 0)][:3]
                               for v in replacements[i][0]]}
                 for i in range(len(pieces))], len(data), "world")
    lo, hi = sa_bake.bounds(merged)
    print(f"  world: geometry sits at x {lo[0]:.0f}..{hi[0]:.0f}, "
          f"y {lo[1]:.0f}..{hi[1]:.0f}, z {lo[2]:.0f}..{hi[2]:.0f} "
          f"in WoS world units")
    return out


# the island, as measured from the twelve extracted cell collision archives
# (.pccvx are the only shipped data in world coordinates; ground sits at y ~ 0)
ISLAND_LO = (-3000.0, -1100.0)
ISLAND_HI = (3700.0, 1600.0)
CEILING_Y = 250.0


def build_probe(instances, cache, centre, radius):
    """A district you cannot fail to find, for when nothing showed up.

    Putting geometry at San Andreas' own coordinates assumes both that the
    override applied and that we guessed the right part of the island to look
    at. This separates those: mesh 1 becomes one quad spanning the WHOLE island
    at 250 m, a ceiling visible from anywhere in the city, and mesh 0 carries
    the district standing on it. Nothing visible means the override is not
    reaching this object; a ceiling but no district means the district is the
    problem, not the carrier.
    """
    data = open(OCEAN, "rb").read()
    radius, sel, merged, skipped = fit_region(centre, radius, cache,
                                              instances, 0xFFFF)
    lo, hi = sa_bake.bounds(merged)
    mid = [(lo[i] + hi[i]) / 2 for i in range(3)]
    city = ((ISLAND_LO[0] + ISLAND_HI[0]) / 2, (ISLAND_LO[1] + ISLAND_HI[1]) / 2)
    merged["vertices"] = [(v[0] - mid[0] + city[0],
                           v[1] - lo[1] + CEILING_Y,
                           v[2] - mid[2] + city[1])
                          for v in merged["vertices"]]
    district = to_records(merged, double_sided=True)
    print(f"  probe: radius {radius:.0f} m, {len(sel)} instances, "
          f"{len(district[0])} verts standing on the ceiling at "
          f"y {CEILING_Y:.0f}")

    quad = {
        "vertices": [(ISLAND_LO[0], CEILING_Y, ISLAND_LO[1]),
                     (ISLAND_HI[0], CEILING_Y, ISLAND_LO[1]),
                     (ISLAND_HI[0], CEILING_Y, ISLAND_HI[1]),
                     (ISLAND_LO[0], CEILING_Y, ISLAND_HI[1])],
        "uvs": [(0.0, 0.0), (64.0, 0.0), (64.0, 64.0), (0.0, 64.0)],
        "triangles": [(0, 1, 2), (0, 2, 3)],
    }
    ceiling = to_records(quad, double_sided=True)

    replacements = {0: district, 1: ceiling}
    bounds = meshpack.required_model_bounds(data, replacements)
    out = meshpack.build_mesh_file(data, replacements, model_bounds=bounds)
    verify(out, [{"vertices": [v[(POSITION, 0)][:3] for v in district[0]]},
                 {"vertices": [v[(POSITION, 0)][:3] for v in ceiling[0]]}],
           len(data), "probe")
    return out


# where the district goes: the middle of the island in x, and far enough past
# the sampled z edge (1502) to stand clear of it in open water
GROUND_AT = (350.0, 0.0, 1900.0)
MARKER_HEIGHT = 400.0
MARKER_WIDTH = 8.0


def marker_column(centre):
    """A tall thin box at the district's centre, so it can be found.

    The probe's model box happened to span the whole island, which is also what
    the engine culls against. A district-sized box may not be visible from far
    away, and there is no coordinate readout in game to navigate by -- so the
    district carries its own landmark.
    """
    x, _, z = centre
    h, w = MARKER_HEIGHT, MARKER_WIDTH / 2
    corners = [(x - w, z - w), (x + w, z - w), (x + w, z + w), (x - w, z + w)]
    verts = [(cx, 0.0, cz) for cx, cz in corners] + \
            [(cx, h, cz) for cx, cz in corners]
    tris = []
    for i in range(4):
        j = (i + 1) % 4
        tris += [(i, j, j + 4), (i, j + 4, i + 4)]
    tris += [(4, 5, 6), (4, 6, 7)]
    return {"vertices": verts, "triangles": tris,
            "uvs": [(0.0, 0.0)] * len(verts)}


def build_ground(instances, cache, centre, radius):
    """The district at ground level, on the full budget, SINGLE SIDED.

    Single sided on purpose: every build so far emitted both windings, so
    whether SA and WoS agree on which side is front has never been tested. If
    the district looks inside out, that is the answer.
    """
    data = open(OCEAN, "rb").read()
    m = wrapmesh.parse(data)
    slots = len(m.meshes)
    column = marker_column(GROUND_AT)
    budget = 0xFFFF * slots - len(column["vertices"])
    radius, sel, merged, skipped = fit_region(centre, radius, cache,
                                              instances, budget)
    lo, hi = sa_bake.bounds(merged)
    mid = [(lo[i] + hi[i]) / 2 for i in range(3)]
    merged["vertices"] = [(v[0] - mid[0] + GROUND_AT[0],
                           v[1] - lo[1] + GROUND_AT[1],
                           v[2] - mid[2] + GROUND_AT[2])
                          for v in merged["vertices"]]
    pieces = split_for_slots(merged, slots)
    print(f"  ground: radius {radius:.0f} m, {len(sel)} instances, "
          f"{len(merged['vertices'])} verts in {len(pieces)} slot(s), "
          f"centred on {GROUND_AT}")

    replacements = {i: to_records(pieces[i]) for i in range(len(pieces))}
    # the marker rides in whichever slot has room, double sided so it reads
    # from every angle
    mverts, mtris = to_records(column, double_sided=True)
    for i in sorted(replacements, key=lambda k: len(replacements[k][0])):
        verts, tris = replacements[i]
        if len(verts) + len(mverts) <= 0xFFFF:
            base = len(verts)
            replacements[i] = (verts + mverts,
                               tris + [(a + base, b + base, c + base)
                                       for a, b, c in mtris])
            print(f"  ground: marker column {MARKER_HEIGHT:.0f} m tall in "
                  f"mesh{i}")
            break
    else:
        raise SystemExit("no slot has room for the marker column")

    bounds = meshpack.required_model_bounds(data, replacements)
    out = meshpack.build_mesh_file(data, replacements, model_bounds=bounds)
    verify(out, [{"vertices": [v[(POSITION, 0)][:3] for v in replacements[i][0]]}
                 for i in sorted(replacements)], len(data), "ground")
    lo, hi = sa_bake.bounds(merged)
    print(f"  ground: district spans x {lo[0]:.0f}..{hi[0]:.0f}, "
          f"y {lo[1]:.0f}..{hi[1]:.0f}, z {lo[2]:.0f}..{hi[2]:.0f}")
    return out


# K07 carries the collision because all 72 of its entries are `col_genblock`:
# replacing them swaps that block's collision wholesale with no grass, road or
# terrain patches caught in the crossfire. M04 was the first try and was a park
# cell -- 109 grass and 58 road entries went under, and the game died.
CELL_PCCVX = (GAME + "/WoS_VolumetricClouds/extracted/MEGACITY/MEGACITY/"
              "0x0001CD92.K07.pccvx")
CELL_RESOURCE = "0x0001CD92.K07.pccvx"
CELL_ENTRY_PREFIX = "col_genblock"


def cell_box(path):
    """A cell's world box, taken from its own collision hulls."""
    apkf, files = colmesh.read_pccvx(path)
    lo = [float("inf")] * 3
    hi = [float("-inf")] * 3
    for entry, hulls, consumed in files:
        for h in hulls:
            for k in range(3):
                lo[k] = min(lo[k], h.aabb[k])
                hi[k] = max(hi[k], h.aabb[k + 3])
    return apkf, files, lo, hi


# How many of our hulls each rung of the ladder ships. ColNone (no archive at
# all) and ColNull (a byte-identical archive) already bracket the question of
# whether overriding the archive is safe in itself; these bracket the hulls.
# Going straight from nothing to 72 leaves no way to tell "our hulls are wrong
# in principle" from "one hull out of 72 is bad". The marker column is always
# hull 0, so every rung is a superset of the one below it.
COLLIDE_LADDER = [("LosSantos_Col01", 1), ("LosSantos_Col08", 8),
                  ("LosSantos_Collide", None)]


def place(group, at, lo=None, hi=None):
    """Move a baked group so its footprint centre sits on `at`, base at at.y."""
    if lo is None:
        lo, hi = sa_bake.bounds(group)
    mid = [(lo[i] + hi[i]) / 2 for i in range(3)]
    return {**group,
            "vertices": [(v[0] - mid[0] + at[0],
                          v[1] - lo[1] + at[1],
                          v[2] - mid[2] + at[2]) for v in group["vertices"]]}


# The two districts of the winding test, and the marker heights that tell them
# apart from the air: the taller column stands on the untouched winding.
WINDING_AT = [(150.0, 0.0, 1900.0), (650.0, 0.0, 1900.0)]
WINDING_MARKERS = [400.0, 200.0]


def build_winding(instances, cache, centre, radius):
    """The same district twice, side by side, with opposite winding.

    "The facades are there" was read off a single one-sided build, and it was
    wrong: with the winding inverted a building still looks like a building --
    you are just seeing its FAR wall from the inside while the near one is
    culled away. One district cannot tell those apart, two adjacent ones can.
    The taller marker column marks the district built exactly as every previous
    build was; if that is the see-through one, the reader's winding is flipped.
    """
    data = open(OCEAN, "rb").read()
    m = wrapmesh.parse(data)
    if len(m.meshes) < 2:
        raise SystemExit("the winding test needs two mesh slots")
    radius, sel, merged, skipped = fit_region(centre, radius, cache,
                                              instances, 0xFFFF - 8)
    lo, hi = sa_bake.bounds(merged)
    print(f"  winding: radius {radius:.0f} m, {len(sel)} instances, "
          f"{len(merged['vertices'])} verts per district")

    replacements = {}
    for slot, (at, height) in enumerate(zip(WINDING_AT, WINDING_MARKERS)):
        moved = place(merged, at, lo, hi)
        verts, tris = to_records(moved)
        if slot:
            # slot 1 is the SAME geometry with every triangle reversed, so the
            # only difference between the two districts is which side is front
            tris = [(c, b, a) for a, b, c in tris]
        column = marker_column((at[0], 0.0, at[2]))
        column["vertices"] = [(v[0], v[1] / MARKER_HEIGHT * height, v[2])
                              for v in column["vertices"]]
        cverts, ctris = to_records(column, double_sided=True)
        base = len(verts)
        replacements[slot] = (verts + cverts,
                              tris + [(a + base, b + base, c + base)
                                      for a, b, c in ctris])
        print(f"  winding: mesh{slot} at {at}, "
              f"{'reversed' if slot else 'as built'} winding, "
              f"{height:.0f} m marker")

    bounds = meshpack.required_model_bounds(data, replacements)
    out = meshpack.build_mesh_file(data, replacements, model_bounds=bounds)
    verify(out, [{"vertices": [v[(POSITION, 0)][:3]
                               for v in replacements[i][0]]}
                 for i in sorted(replacements)], len(data), "winding")
    return out


def build_material(instances, cache, centre, radius):
    """The same district twice, differing ONLY in which material it wears.

    With the winding right the district reads as buildings but takes no light
    at all. Vertex colour is not the cause -- the city's own objects light fine
    with a single flat colour, Spider-Man included -- which leaves the carrier's
    material. Both of `s_nat_ocean000`'s sit on FX 0x18531B51, which only 92 of
    the pack's 2390 materials use, against 0xB124A376 for city facades.

    Materials are per slot, so one file can answer this: same geometry, same
    winding, same lighting, one district on the carrier's material and one on a
    facade's. The taller marker stands on the carrier's own material.
    """
    data = open(OCEAN, "rb").read()
    m = wrapmesh.parse(data)
    if len(m.meshes) < 2:
        raise SystemExit("the material test needs two mesh slots")
    radius, sel, merged, skipped = fit_region(centre, radius, cache,
                                              instances, 0xFFFF - 8)
    lo, hi = sa_bake.bounds(merged)
    print(f"  material: radius {radius:.0f} m, {len(sel)} instances, "
          f"{len(merged['vertices'])} verts per district")

    replacements = {}
    for slot, (at, height) in enumerate(zip(WINDING_AT, WINDING_MARKERS)):
        moved = place(merged, at, lo, hi)
        verts, tris = to_records(moved)
        column = marker_column((at[0], 0.0, at[2]))
        column["vertices"] = [(v[0], v[1] / MARKER_HEIGHT * height, v[2])
                              for v in column["vertices"]]
        cverts, ctris = to_records(column, double_sided=True)
        base = len(verts)
        replacements[slot] = (verts + cverts,
                              tris + [(a + base, b + base, c + base)
                                      for a, b, c in ctris])

    bounds = meshpack.required_model_bounds(data, replacements)
    out = meshpack.build_mesh_file(data, replacements, model_bounds=bounds)
    verify(out, [{"vertices": [v[(POSITION, 0)][:3]
                               for v in replacements[i][0]]}
                 for i in sorted(replacements)], len(data), "material")
    # slot 0 keeps the carrier's own material, slot 1 gets a facade's
    out = repoint_materials(out, (None, OPAQUE_MATERIALS[0]))
    print(f"  material: mesh0 keeps the carrier's (400 m marker), "
          f"mesh1 -> {hex(OPAQUE_MATERIALS[0])} (200 m marker)")
    return out


def build_collide(instances, cache, centre, radius):
    """Geometry AND collision for one district, landing inside the cell.

    Collision has to come from a different carrier than geometry: `ocean000`
    ships only a MESH, there is no `.pccvx` with its hash anywhere. Cell
    archives are the ones that hold hulls, and they are in world coordinates
    already -- but the engine only streams a cell's collision near that cell,
    so the district has to stand inside that cell's own footprint. It will
    therefore overlap the shipped city; that is the price of the test.
    """
    apkf, files, clo, chi = cell_box(CELL_PCCVX)
    hull_slots = [i for i, (e, h, c) in enumerate(files)
                  if e["name"].startswith(CELL_ENTRY_PREFIX)]
    ccentre = ((clo[0] + chi[0]) / 2, 0.0, (clo[2] + chi[2]) / 2)
    print(f"  collide: cell covers x {clo[0]:.0f}..{chi[0]:.0f}, "
          f"z {clo[2]:.0f}..{chi[2]:.0f}, {len(hull_slots)} usable hull "
          f"slots of {len(files)}")

    data = open(OCEAN, "rb").read()
    m = wrapmesh.parse(data)
    slots = len(m.meshes)
    radius, sel, merged, skipped = fit_region(centre, radius, cache,
                                              instances, 0xFFFF * slots)
    lo, hi = sa_bake.bounds(merged)
    mid = [(lo[i] + hi[i]) / 2 for i in range(3)]
    shift = (ccentre[0] - mid[0], ccentre[1] - lo[1], ccentre[2] - mid[2])
    merged["vertices"] = [(v[0] + shift[0], v[1] + shift[1], v[2] + shift[2])
                          for v in merged["vertices"]]
    pieces = split_for_slots(merged, slots)
    replacements = {i: to_records(pieces[i]) for i in range(len(pieces))}
    # the same landmark the ground build carries, for the same reason: there
    # is no coordinate readout in game, and cell M04 is otherwise one city
    # block among many. Here it also gets a hull, so the collision test is
    # "can I stand on the column" before hunting for a rooftop.
    column = marker_column(ccentre)
    mverts, mtris = to_records(column, double_sided=True)
    for i in sorted(replacements, key=lambda k: len(replacements[k][0])):
        verts, tris = replacements[i]
        if len(verts) + len(mverts) <= 0xFFFF:
            base = len(verts)
            replacements[i] = (verts + mverts,
                               tris + [(a + base, b + base, c + base)
                                       for a, b, c in mtris])
            break
    else:
        raise SystemExit("no slot has room for the marker column")
    bounds = meshpack.required_model_bounds(data, replacements)
    mesh = meshpack.build_mesh_file(data, replacements, model_bounds=bounds)
    verify(mesh, [{"vertices": [v[(POSITION, 0)][:3]
                                for v in replacements[i][0]]}
                  for i in sorted(replacements)], len(data), "collide")

    clo_col = [ccentre[0] - MARKER_WIDTH / 2, 0.0, ccentre[2] - MARKER_WIDTH / 2]
    chi_col = [ccentre[0] + MARKER_WIDTH / 2, MARKER_HEIGHT,
               ccentre[2] + MARKER_WIDTH / 2]
    # one hull per file entry, the shape every shipped entry has; entries we
    # have no hull for keep the city's own collision rather than going empty,
    # which is the mistake that closed the game the first time round
    hulls = [sa_hulls.box_hull(clo_col, chi_col)] + \
        sa_hulls.hulls_for(sel, cache, shift, limit=len(hull_slots) - 1)
    bad = sa_hulls.degenerate(hulls)
    if bad:
        raise SystemExit(f"{len(bad)} hulls have no volume; the game dies on "
                         f"approach when one ships -- see "
                         f"sa_hulls.MIN_THICKNESS")
    print(f"  collide: {len(sel)} instances -> {len(hulls)} box hulls "
          f"(biggest first), worst plane error "
          f"{sa_hulls.worst_plane_error(hulls):.3g}, none degenerate")

    archives = {}
    for label, count in COLLIDE_LADDER:
        rung = hulls if count is None else hulls[:count]
        archives[label] = colmesh.build_pccvx(
            apkf, {slot: [h] for slot, h in zip(hull_slots, rung)})
        print(f"  {label}: {len(rung)} of our hulls, "
              f"{len(files) - len(rung)} cell entries untouched, "
              f"{len(archives[label]):,} bytes "
              f"(original {os.path.getsize(CELL_PCCVX):,})")
    return mesh, archives, shift, (lo, hi)


def main():
    centre = (1500.0, -1700.0)     # downtown Los Santos
    print("loading San Andreas placement...")
    instances = sa_bake.load_placement(SA_DIR, ["*.ipl"], IDE_ROOT)
    cache = sa_bake.ModelCache(SA_DIR)
    print(f"  {len(instances)} real instances")

    block = build_block(instances, cache, centre, 45.0)
    t = install("LosSantos_Block", "MEGACITY/0xEE185533.T25.megacity.pcapk",
                "0x91486138.s_garbg_dumpster000.wrap.mesh", block)
    print(f"  wrote {t}")

    world = build_world(instances, cache, centre, 220.0)
    t = install("LosSantos_World", "MEGACITY/0xEE185533.T25.megacity.pcapk",
                "0xD9CB2AAA.s_nat_ocean000.wrap.mesh", world)
    print(f"  wrote {t}")

    ground = build_ground(instances, cache, centre, 260.0)
    t = install("LosSantos_Ground", "MEGACITY/0xEE185533.T25.megacity.pcapk",
                "0xD9CB2AAA.s_nat_ocean000.wrap.mesh", ground)
    print(f"  wrote {t}")

    material = build_material(instances, cache, centre, 120.0)
    t = install("LosSantos_Material", "MEGACITY/0xEE185533.T25.megacity.pcapk",
                "0xD9CB2AAA.s_nat_ocean000.wrap.mesh", material)
    print(f"  wrote {t}")

    winding = build_winding(instances, cache, centre, 120.0)
    t = install("LosSantos_Winding", "MEGACITY/0xEE185533.T25.megacity.pcapk",
                "0xD9CB2AAA.s_nat_ocean000.wrap.mesh", winding)
    print(f"  wrote {t}")
    t = install("LosSantos_WindingMat",
                "MEGACITY/0xEE185533.T25.megacity.pcapk",
                "0xD9CB2AAA.s_nat_ocean000.wrap.mesh",
                repoint_materials(winding))
    print(f"  wrote {t}")

    # the same district, byte for byte, with ONLY the material hashes changed,
    # so what the game shows is attributable to the material and nothing else.
    # Ground stays as the known-good reference rather than being edited.
    t = install("LosSantos_Mat", "MEGACITY/0xEE185533.T25.megacity.pcapk",
                "0xD9CB2AAA.s_nat_ocean000.wrap.mesh",
                repoint_materials(ground))
    print(f"  wrote {t} (opaque materials "
          f"{', '.join(hex(h) for h in OPAQUE_MATERIALS)})")

    mesh, archives, r, n = build_collide(instances, cache, centre, 145.0)
    for label in archives:
        install(label, "MEGACITY/0xEE185533.T25.megacity.pcapk",
                "0xD9CB2AAA.s_nat_ocean000.wrap.mesh", mesh)
        t = install(label, "MEGACITY", CELL_RESOURCE, archives[label])
        print(f"  wrote {t}")

    # the same mod split in two, to find which override kills the game on
    # approach. ColNone changes only the mesh, so a crash there clears the
    # collision archive entirely; ColNull adds a BYTE-IDENTICAL rebuild of the
    # archive, so a crash only there means rebuilding the container is fine as
    # a file but wrong as an override, not that our hulls are bad.
    install("LosSantos_ColNone", "MEGACITY/0xEE185533.T25.megacity.pcapk",
            "0xD9CB2AAA.s_nat_ocean000.wrap.mesh", mesh)
    install("LosSantos_ColNull", "MEGACITY/0xEE185533.T25.megacity.pcapk",
            "0xD9CB2AAA.s_nat_ocean000.wrap.mesh", mesh)
    apkf, _ = colmesh.read_pccvx(CELL_PCCVX)
    untouched = colmesh.build_pccvx(apkf, {})
    assert untouched == open(CELL_PCCVX, "rb").read(),         "the null rebuild must be byte identical or it proves nothing"
    install("LosSantos_ColNull", "MEGACITY", CELL_RESOURCE, untouched)
    print("  wrote LosSantos_ColNone (mesh only) and LosSantos_ColNull "
          "(mesh + untouched collision)")

    probe = build_probe(instances, cache, centre, 220.0)
    t = install("LosSantos_Probe", "MEGACITY/0xEE185533.T25.megacity.pcapk",
                "0xD9CB2AAA.s_nat_ocean000.wrap.mesh", probe)
    print(f"  wrote {t}")

    print("\nenable one at a time under [mods] in exWoS/exWoS.config.ini "
          "(Probe and World claim the same resource):")
    print("  LosSantos_Block=1     (Los Santos block wherever a dumpster is)")
    print("  LosSantos_World=1     (a district at its real SA coordinates, "
          "replaces the ocean)")
    print("  LosSantos_Ground=1    (district at ground level, single sided, "
          "with a 400 m marker column)")
    print("  LosSantos_Material=1  (the same district twice, tall marker on "
          "the carrier's material, short on a facade's)")
    print("  LosSantos_Winding=1   (the same district twice side by side, "
          "opposite winding; tall marker = as built)")
    print("  LosSantos_WindingMat=1 (the winding test with opaque materials "
          "as well)")
    print("  LosSantos_Mat=1       (the Ground district with opaque building "
          "materials instead of the carrier's)")
    print("  LosSantos_Col01=1     (the same district, ONE hull: the marker "
          "column only)")
    print("  LosSantos_Col08=1     (eight hulls: the biggest buildings)")
    print("  LosSantos_Collide=1   (district inside cell K07, all 72 hulls)")
    print("  LosSantos_Probe=1     (ceiling over the whole island at 250 m, "
          "district standing on it)")


if __name__ == "__main__":
    main()
