"""Close the island holes of the native ocean (s_nat_ocean001) for a profile.

The shipped water plane is a ring around New York: Manhattan and the other
islands are holes in it. With Los Santos drawn over New York those holes are
where LS meets the sea (Santa Maria beach, the docks), so the sea was simply
missing there. Every hole is filled from its own shoreline vertices
(constrained Delaunay inside the hole polygon, no new vertices), so all the
water attributes (planar UVs, tangents, the second UV set) are interpolated
from the shore exactly as the shipped triangles do. Land above WoS y -7.5
(SA sea level) covers the water; the native water shader is untouched.

    py -3 make_ocean_fill.py [--profile SA_ls_full] [--install] [--png fill.png]

Writes out/full_map/<profile>/MEGACITY/0xEE185533.T25.megacity.pcapk/
0xD9CB2AAB.s_nat_ocean001.wrap.mesh; --install copies it into exWoS (only
with the game closed). Remove that file from exWoS to undo.
"""
import argparse
import shutil
from pathlib import Path

import numpy as np
import shapely
from shapely.geometry import Polygon

import build_sa_world as W
import meshpack
import wrapmesh

SOURCE = Path(W.M.APK_DIR) / '0xD9CB2AAB.s_nat_ocean001.wrap.mesh'
NAME = '0xD9CB2AAB.s_nat_ocean001.wrap.mesh'


def holes(P, tris):
    """Interior rings of the union of the shipped triangles, seen from above.
    The mesh repeats vertices along UV seams (587 indices, 544 positions), so
    index topology does not close the shoreline loops; geometry does."""
    pieces = [Polygon([(P[k][0], P[k][2]) for k in t]) for t in tris]
    union = shapely.union_all([q for q in pieces if q.area > 0]).buffer(0)
    parts = list(union.geoms) if hasattr(union, 'geoms') else [union]
    return [Polygon(ring) for part in parts for ring in part.interiors]


def fill(verts, tris):
    """-> (new triangles, report): every hole triangulated from its own ring."""
    P = np.array([v[(meshpack.POSITION, 0)][:3] for v in verts])
    lookup = {}
    for k in range(len(P)):
        lookup.setdefault((round(P[k][0], 2), round(P[k][2], 2)), k)
    # winding of the shipped triangles, seen from above (x, z)
    a, b, c = (P[np.array(tris)[:, i]] for i in range(3))
    shipped_sign = np.sign(np.median((b[:, 0] - a[:, 0]) * (c[:, 2] - a[:, 2]) - (b[:, 2] - a[:, 2]) * (c[:, 0] - a[:, 0])))
    new, report = [], []
    for poly in holes(P, tris):
        if not poly.is_valid or poly.area < 1.0:
            continue
        cdt = shapely.constrained_delaunay_triangles(poly)
        added = missed = 0
        for t in cdt.geoms:
            xy = list(t.exterior.coords)[:3]
            try:
                idx = [lookup[(round(x, 2), round(z, 2))] for x, z in xy]
            except KeyError:
                missed += 1  # a ring point that is not a shipped vertex
                continue
            pa, pb, pc = (P[k] for k in idx)
            s = (pb[0] - pa[0]) * (pc[2] - pa[2]) - (pb[2] - pa[2]) * (pc[0] - pa[0])
            if np.sign(s) != shipped_sign:
                idx = [idx[0], idx[2], idx[1]]
            new.append(tuple(idx))
            added += 1
        b0 = poly.bounds
        report.append({'area_km2': round(poly.area / 1e6, 3), 'vertices': len(poly.exterior.coords) - 1,
                       'triangles': added, 'missed': missed,
                       'x': [round(b0[0]), round(b0[2])], 'z': [round(b0[1]), round(b0[3])]})
    return new, report


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--profile', default='SA_ls_full')
    p.add_argument('--install', action='store_true')
    p.add_argument('--png')
    a = p.parse_args()
    template = SOURCE.read_bytes()
    m = wrapmesh.parse(template)
    verts, tris = meshpack.world_geometry(m, 0)
    tris = [tuple(t) for t in tris]
    new, report = fill(verts, tris)
    for r in sorted(report, key=lambda r: -r['area_km2']):
        print(r)
    blob = meshpack.build_mesh_file(template, {0: (verts, tris + new)})
    # round trip: the authored file decodes to the shipped triangles plus the fill
    again = wrapmesh.parse(blob)
    v2, t2 = meshpack.world_geometry(again, 0)
    assert len(t2) == len(tris) + len(new), (len(t2), len(tris), len(new))
    P1 = np.array([v[(meshpack.POSITION, 0)][:3] for v in verts])
    P2 = np.array([v[(meshpack.POSITION, 0)][:3] for v in v2])
    assert len(P1) == len(P2) and np.abs(P1 - P2).max() < 0.05, 'positions moved'
    out = W.OUT / a.profile / W.PACK / NAME
    W.write(out, blob)
    print(f'{len(tris)} shipped + {len(new)} fill triangles -> {out} ({len(blob)} bytes)')
    if a.png:
        from PIL import Image, ImageDraw
        lo, hi = P2.min(0), P2.max(0)
        s = 1400 / max(hi[0] - lo[0], hi[2] - lo[2])
        im = Image.new('RGB', (1400, 1400), (20, 20, 20)); dr = ImageDraw.Draw(im)
        f = lambda x, z: ((x - lo[0]) * s, (hi[2] - z) * s)
        for i, t in enumerate(t2):
            dr.polygon([f(P2[k][0], P2[k][2]) for k in t], fill=(30, 80, 160) if i < len(tris) else (40, 160, 90))
        im.save(a.png)
    if a.install:
        target = Path(__file__).resolve().parents[2] / 'exWoS' / a.profile / W.PACK / NAME
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(out, target)
        print('installed', target)


if __name__ == '__main__':
    main()
