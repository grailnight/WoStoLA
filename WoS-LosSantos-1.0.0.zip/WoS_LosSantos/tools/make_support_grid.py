"""sa_runtime/support.bin: what a car may stand on, per 4 m cell.

New York's cars (gBodyColor) stay visible in Los Santos mode, but those placed
by New York's own data stand at New York's street height (y ~0): over the low
Santa Maria beach they hang in the air, under downtown they are buried. The
DLL (sa_runtime.h namespace support) keeps a car draw only when some Los
Santos collision top lies just under it. The tops are the installed SCGPC's
type-4 box tops, so the file must be rebuilt with the collision.

    'SASG' u32 version=1, u32 nx, u32 nz, f32 x0, f32 z0, f32 cell
    u32 first[nx*nz+1]    index of a cell's first top (cell = ix*nz + iz)
    i16 tops[]            box tops in decimetres, ascending per cell

    py -3 make_support_grid.py [SA_ls_full] [--install]
"""
import argparse
import math
import shutil
import struct
from pathlib import Path

import numpy as np

import build_sa_world as W
import collision_oracle as O

CELL = 4.0


def build(lo, hi, x0, z0, nx, nz):
    ix0 = np.clip(np.floor((lo[:, 0] - x0) / CELL), 0, nx - 1).astype(np.int64)
    ix1 = np.clip(np.floor((hi[:, 0] - x0) / CELL), 0, nx - 1).astype(np.int64)
    iz0 = np.clip(np.floor((lo[:, 2] - z0) / CELL), 0, nz - 1).astype(np.int64)
    iz1 = np.clip(np.floor((hi[:, 2] - z0) / CELL), 0, nz - 1).astype(np.int64)
    w, d = ix1 - ix0 + 1, iz1 - iz0 + 1
    n = w * d
    which = np.repeat(np.arange(len(lo)), n)
    k = np.arange(n.sum()) - np.repeat(np.cumsum(n) - n, n)
    cell = (ix0[which] + k % w[which]) * nz + iz0[which] + k // w[which]
    top = np.round(hi[which, 1] * 10).astype(np.int64)
    pairs = np.unique(cell * 100000 + (top + 50000))       # one entry per (cell, top)
    cells, tops = pairs // 100000, pairs % 100000 - 50000
    assert tops.min() > -32768 and tops.max() < 32767
    first = np.searchsorted(cells, np.arange(nx * nz + 1)).astype('<u4')
    return first, tops.astype('<i2')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('profile', nargs='?', default='SA_ls_full')
    p.add_argument('--install', action='store_true')
    a = p.parse_args()
    root, manifest = O.load_profile(a.profile, installed=False)
    lo, hi = O.read_boxes(root / 'L23/0x0001D211.L23.scgpc')
    area = manifest['model_bounds']
    x0, z0 = area[0][0], area[0][2]
    nx = math.ceil((area[1][0] - x0) / CELL)
    nz = math.ceil((area[1][2] - z0) / CELL)
    first, tops = build(lo, hi, x0, z0, nx, nz)
    blob = (b'SASG' + struct.pack('<3I3f', 1, nx, nz, x0, z0, CELL) + first.tobytes() + tops.tobytes())
    # self-check against the boxes at a few random cells
    rng = np.random.default_rng(1)
    for _ in range(200):
        i = int(rng.integers(len(lo)))
        cx, cz = (lo[i, 0] + hi[i, 0]) / 2, (lo[i, 2] + hi[i, 2]) / 2
        c = int((cx - x0) // CELL) * nz + int((cz - z0) // CELL)
        assert round(hi[i, 1] * 10) in tops[first[c]:first[c + 1]].tolist()
    out = W.OUT / a.profile / 'sa_runtime' / 'support.bin'
    W.write(out, blob)
    print(f'{a.profile}: {nx}x{nz} cells of {CELL} m, {len(tops)} tops, '
          f'max {int(np.diff(first).max())} per cell, {len(blob)} bytes -> {out}')
    if a.install:
        target = Path(__file__).resolve().parents[2] / 'exWoS' / a.profile / 'sa_runtime' / 'support.bin'
        shutil.copy2(out, target)
        print('installed', target)


if __name__ == '__main__':
    main()
