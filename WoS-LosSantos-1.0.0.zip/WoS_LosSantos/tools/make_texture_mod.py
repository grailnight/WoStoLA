"""
Put San Andreas textures on San Andreas geometry, inside the slot budget.

Atlasing is not available -- the city tiles its textures, 98% of the district's
vertices run outside [0,1], so atlas neighbours would bleed into each other
under wrap addressing. What is available is one texture per mesh SLOT, because
a mesh has exactly as many materials as slots.

So this is the smallest build that proves the whole chain end to end:
  .txd -> DXT blocks -> .tex -> exWoS override -> the texture a slot samples

`s_nat_ocean000` has two slots, and its two materials point at `s_boundry` and
`lod_seawall`, which nothing else in the city uses -- so overriding those two
textures cannot disturb anything but the shoreline. Each slot gets the geometry
of ONE San Andreas texture, picked by surface AREA rather than triangle count:
by triangles the top of the list is traffic lights and lampposts, which are
barely visible, while by area it is walls, tiling and roofs.

The district is therefore INCOMPLETE on purpose -- only the geometry belonging
to the chosen textures is built. Showing everything would mean showing most of
it under the wrong texture, which is what we are trying to stop doing.

    python make_texture_mod.py
"""

import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import make_map_mod as M
import meshpack
import sa_bake
import sa_ipl
import sa_txd
import wos_tex
import wrapmesh

# the textures the carrier's two materials sample, and a template to author
# from; the template only supplies the container, never the image
SLOT_TEXTURES = [0x838FDFD5,    # s_boundry, worn by s_nat_oceanlandy
                 0xB7DC0FC7]    # lod_seawall, worn by s_nat_oceanbreakwater
TEX_DIR = M.APK_DIR
TEMPLATE_TEX = TEX_DIR + "/0x838FDFD5.s_boundry.wrap.tex"

CENTRE = (1500.0, -1700.0)
RADIUS = 150.0
PLACE_AT = (350.0, 0.0, 1900.0)


def group_area(g):
    """Surface area of a baked group, in square metres."""
    total = 0.0
    V = g["vertices"]
    for a, b, c in g["triangles"]:
        pa, pb, pc = V[a], V[b], V[c]
        u = [pb[k] - pa[k] for k in range(3)]
        w = [pc[k] - pa[k] for k in range(3)]
        cx = u[1] * w[2] - u[2] * w[1]
        cy = u[2] * w[0] - u[0] * w[2]
        cz = u[0] * w[1] - u[1] * w[0]
        total += 0.5 * math.sqrt(cx * cx + cy * cy + cz * cz)
    return total


def texture_sources(instances, ide_root, sa_dir):
    """-> {'dictionary::texture': Texture}, for the dictionaries in use.

    A texture name is only unique inside its own dictionary, so the .ide's
    third field decides which .txd to open for a given model.
    """
    ids = sa_ipl.read_ide_dir(ide_root)
    txds = sa_ipl.read_ide_txd(ide_root)
    name2txd = {n.lower(): txds[i] for i, n in ids.items() if i in txds}
    wanted = set()
    for inst in instances:
        model = (inst.get("model") or "").lower()
        if model in name2txd:
            wanted.add(name2txd[model].lower())

    found = {}
    for txd in sorted(wanted):
        path = os.path.join(sa_dir, txd + ".txd")
        if not os.path.exists(path):
            continue
        for name, tex in sa_txd.by_name(path).items():
            found[txd + '::' + name.lower()] = tex
    return found


def to_wos_texture(tex, template, name_hash):
    """Convert a San Andreas texture to a .tex, without touching the pixels.

    Both sides store DXT, so the blocks move across verbatim. Only the mip
    chain needs care: San Andreas routinely ends one with zero-length levels,
    and WoS derives every level's size from the dimensions, so the chain is
    truncated at the first empty level rather than padded.
    """
    if tex.fourcc not in (b"DXT1", b"DXT3", b"DXT5"):
        raise ValueError(f"{tex.name}: {tex.fourcc!r} is not block compressed")
    levels = []
    w, h = tex.width, tex.height
    for mip in tex.mips:
        if not mip:
            break
        want = wos_tex.level_size(w, h, tex.fourcc)
        if len(mip) != want:
            break
        levels.append(mip)
        w, h = max(1, w // 2), max(1, h // 2)
    if not levels:
        raise ValueError(f"{tex.name}: no usable mip level")
    return wos_tex.build(template, b"".join(levels), tex.width, tex.height,
                         tex.fourcc, len(levels), name_hash=name_hash)


def main():
    print("loading San Andreas placement...")
    instances = sa_bake.load_placement(M.SA_DIR, ["*.ipl"], M.IDE_ROOT)
    cache = sa_bake.ModelCache(M.SA_DIR)
    sel = [i for i in instances if sa_bake.in_region(i, CENTRE, RADIUS)]
    groups, skipped = sa_bake.bake(sel, cache)
    print(f"  {len(sel)} instances, {len(groups)} texture groups")

    sources = texture_sources(sel, M.IDE_ROOT, M.SA_DIR)
    print(f"  {len(sources)} textures available from the dictionaries in use")

    # biggest by area, and only ones we can actually ship as DXT
    ranked = sorted(((group_area(g), k) for k, g in groups.items()),
                    reverse=True)
    chosen = []
    for area, name in ranked:
        tex = sources.get(name.lower())
        if tex is None or tex.fourcc not in (b"DXT1", b"DXT3", b"DXT5"):
            continue
        if len(groups[name]["vertices"]) > 0xFFFF:
            continue
        chosen.append((name, tex, area))
        if len(chosen) == len(SLOT_TEXTURES):
            break
    if len(chosen) < len(SLOT_TEXTURES):
        raise SystemExit("not enough usable textures")

    total_area = sum(a for a, _ in ranked)
    for i, (name, tex, area) in enumerate(chosen):
        print(f"  slot{i}: {name!r} {tex.width}x{tex.height} "
              f"{tex.fourcc.decode()}, {area:,.0f} m2 "
              f"({area / total_area:.1%} of the district)")

    # geometry: one slot per chosen texture, placed as a group so the district
    # keeps its shape even though most of it is missing
    lo = [min(min(groups[n]["vertices"], key=lambda v: v[k])[k]
              for n, _, _ in chosen) for k in range(3)]
    hi = [max(max(groups[n]["vertices"], key=lambda v: v[k])[k]
              for n, _, _ in chosen) for k in range(3)]
    mid = [(lo[k] + hi[k]) / 2 for k in range(3)]
    shift = (PLACE_AT[0] - mid[0], PLACE_AT[1] - lo[1], PLACE_AT[2] - mid[2])

    data = open(M.OCEAN, "rb").read()
    replacements = {}
    for i, (name, tex, area) in enumerate(chosen):
        g = dict(groups[name])
        g["vertices"] = [(v[0] + shift[0], v[1] + shift[1], v[2] + shift[2])
                         for v in g["vertices"]]
        verts, tris = M.to_records(g)
        replacements[i] = (verts, tris)
        us = [u for u, v in g["uvs"]]
        vs = [v for u, v in g["uvs"]]
        print(f"  slot{i}: {len(verts):,} verts, {len(tris):,} triangles, "
              f"u {min(us):.1f}..{max(us):.1f} v {min(vs):.1f}..{max(vs):.1f}")

    # only a fraction of the district is here, so it is small and easy to miss;
    # it carries the same marker column the other builds use. The column wears
    # whichever slot's texture it lands in, which does not affect the test.
    column = M.marker_column((PLACE_AT[0], 0.0, PLACE_AT[2]))
    mverts, mtris = M.to_records(column, double_sided=True)
    thin = min(replacements, key=lambda k: len(replacements[k][0]))
    verts, tris = replacements[thin]
    base = len(verts)
    replacements[thin] = (verts + mverts,
                          tris + [(a + base, b + base, c + base)
                                  for a, b, c in mtris])
    print(f"  marker column {M.MARKER_HEIGHT:.0f} m in slot{thin}")

    bounds = meshpack.required_model_bounds(data, replacements)
    mesh = meshpack.build_mesh_file(data, replacements, model_bounds=bounds)
    M.verify(mesh, [{"vertices": [v[(M.POSITION, 0)][:3]
                                  for v in replacements[i][0]]}
                    for i in sorted(replacements)], len(data), "texture")

    template = open(TEMPLATE_TEX, "rb").read()
    out = M.install("LosSantos_Texture",
                    "MEGACITY/0xEE185533.T25.megacity.pcapk",
                    "0xD9CB2AAA.s_nat_ocean000.wrap.mesh", mesh)
    print(f"  wrote {out}")

    for i, (name, tex, area) in enumerate(chosen):
        blob = to_wos_texture(tex, template, SLOT_TEXTURES[i])
        back = wos_tex.Tex(blob)
        resource = f"0x{SLOT_TEXTURES[i]:08X}.{name.lower()}.wrap.tex"
        out = M.install("LosSantos_Texture",
                        "MEGACITY/0xEE185533.T25.megacity.pcapk",
                        resource, blob)
        print(f"  wrote {os.path.basename(out)}  ({back})")

    print("\nenable LosSantos_Texture=1 (and the other LosSantos mods off -- "
          "they claim the same mesh).")
    print("The district is deliberately partial: only the geometry of the "
          "chosen textures is there.")


if __name__ == "__main__":
    main()
