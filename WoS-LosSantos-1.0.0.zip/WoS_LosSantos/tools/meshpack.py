"""
Geometry encoder for wrap.mesh: OBJ / vertex arrays -> vertex + index buffers,
packed to a template mesh's own vertex declaration and stride.

Decoding mirrors viewer.py's read_vertex_data; encoding is its exact inverse
(within quantization). Positions are stored normalized and are reconstructed
by the engine as  p = stored * model.bbox + model.offset, so encoding needs the
template's bbox/offset -- or a refit, which rewrites them.

Index buffers are TRIANGLE STRIPS (viewer.py decodes them with
strip_to_triangles: alternating winding, degenerate triangles dropped), so a
triangle list is stitched into one strip with degenerate joins and explicit
parity control.
"""

import math
import struct

import wrapmesh

# vertex declaration usage ids (D3DDECLUSAGE)
POSITION, NORMAL, TEXCOORD, TANGENT, COLOR = 0, 3, 5, 6, 10

# How a mesh stores positions decides whether model.bbox/offset is a decode
# transform or merely a bounding volume:
#   * integer types are quantized to the model bounding box, so
#     world = stored * model.bbox + model.offset;
#   * float types hold world coordinates already (verified on s_nat_skydome,
#     whose first vertex x equals model.offset.x exactly) and bbox/offset are
#     then only the bounds. viewer.py applies the multiply unconditionally and
#     so misplaces float-position meshes.
QUANTIZED_TYPES = {9, 10, 11, 12}
WORLD_TYPES = {1, 2, 3, 15, 16}


# --------------------------------------------------------------------------
# half float
# --------------------------------------------------------------------------

def f16_decode(h):
    s = (h >> 15) & 1
    e = (h >> 10) & 0x1F
    v = h & 0x3FF
    if e == 0:
        return (-1) ** s * (v / 1024) * 2 ** -14 if v else (-1) ** s * 0.0
    if e == 31:
        return float("inf") if v == 0 else float("nan")
    return (-1) ** s * (1 + v / 1024) * 2 ** (e - 15)


HALF_MAX = 65504.0


def f16_encode(x):
    """Round-to-nearest-even half, matching the decoder above.

    Values outside the half range are clamped rather than raising: shipped SA
    texture coordinates run into the thousands on tiled surfaces, and a UV
    that saturates is better than a build that stops.
    """
    if x != x or x in (float("inf"), float("-inf")):
        return 0
    if x > HALF_MAX:
        x = HALF_MAX
    elif x < -HALF_MAX:
        x = -HALF_MAX
    return struct.unpack("<H", struct.pack("<e", x))[0]


# --------------------------------------------------------------------------
# per-component codecs, keyed by the declaration's data_type
# --------------------------------------------------------------------------

def _q(x, scale):
    """Quantize to a signed/unsigned integer with saturation."""
    return int(round(x * scale))


def _clamp(v, lo, hi):
    return lo if v < lo else hi if v > hi else v


DECODERS = {
    1: lambda b: struct.unpack("<2f", b),
    2: lambda b: struct.unpack("<3f", b),
    3: lambda b: struct.unpack("<4f", b),
    4: lambda b: struct.unpack("<4B", b),
    5: lambda b: struct.unpack("<4B", b),
    6: lambda b: struct.unpack("<2h", b),
    7: lambda b: struct.unpack("<4h", b),
    8: lambda b: tuple(c / 255 for c in struct.unpack("<4B", b)),
    9: lambda b: tuple(c / 32767 for c in struct.unpack("<2h", b)),
    10: lambda b: tuple(c / 32767 for c in struct.unpack("<4h", b)),
    11: lambda b: tuple(c / 65535 for c in struct.unpack("<2H", b)),
    12: lambda b: tuple(c / 65535 for c in struct.unpack("<4H", b)),
    15: lambda b: tuple(f16_decode(h) for h in struct.unpack("<2H", b)),
    16: lambda b: tuple(f16_decode(h) for h in struct.unpack("<4H", b)),
}

ENCODERS = {
    1: lambda v: struct.pack("<2f", *_fit(v, 2)),
    2: lambda v: struct.pack("<3f", *_fit(v, 3)),
    3: lambda v: struct.pack("<4f", *_fit(v, 4)),
    4: lambda v: struct.pack("<4B", *[_clamp(int(round(c)), 0, 255)
                                      for c in _fit(v, 4)]),
    5: lambda v: struct.pack("<4B", *[_clamp(int(round(c)), 0, 255)
                                      for c in _fit(v, 4)]),
    6: lambda v: struct.pack("<2h", *[_clamp(int(round(c)), -32768, 32767)
                                      for c in _fit(v, 2)]),
    7: lambda v: struct.pack("<4h", *[_clamp(int(round(c)), -32768, 32767)
                                      for c in _fit(v, 4)]),
    8: lambda v: struct.pack("<4B", *[_clamp(_q(c, 255), 0, 255)
                                      for c in _fit(v, 4)]),
    9: lambda v: struct.pack("<2h", *[_clamp(_q(c, 32767), -32768, 32767)
                                      for c in _fit(v, 2)]),
    10: lambda v: struct.pack("<4h", *[_clamp(_q(c, 32767), -32768, 32767)
                                       for c in _fit(v, 4)]),
    11: lambda v: struct.pack("<2H", *[_clamp(_q(c, 65535), 0, 65535)
                                       for c in _fit(v, 2)]),
    12: lambda v: struct.pack("<4H", *[_clamp(_q(c, 65535), 0, 65535)
                                       for c in _fit(v, 4)]),
    15: lambda v: struct.pack("<2H", *[f16_encode(c) for c in _fit(v, 2)]),
    16: lambda v: struct.pack("<4H", *[f16_encode(c) for c in _fit(v, 4)]),
}

SIZES = {1: 8, 2: 12, 3: 16, 4: 4, 5: 4, 6: 4, 7: 8, 8: 4, 9: 4,
         10: 8, 11: 4, 12: 8, 15: 4, 16: 8}


def _fit(values, n):
    """Pad/truncate a component tuple to n elements; the shipped data
    stores 0 in the unused 4th slot of positions and normals."""
    v = list(values)
    while len(v) < n:
        v.append(0.0)
    return v[:n]


# --------------------------------------------------------------------------
# vertex buffer
# --------------------------------------------------------------------------

def decode_vertices(m, mesh_index):
    """Raw per-usage component values, exactly as stored (no bbox scaling)."""
    mi = m.meshes[mesh_index]
    stride = mi["vertex_stride"]
    base = mi["vertex_buffer"].target
    verts = []
    for v in range(mi["vertex_count"]):
        rec = {}
        vbase = base + v * stride
        for d in mi["decls"]:
            _, off, dtype, _, usage, usage_idx = d
            size = SIZES.get(dtype)
            if size is None:
                continue
            raw = m.data[vbase + off: vbase + off + size]
            rec[(usage, usage_idx)] = DECODERS[dtype](raw)
        verts.append(rec)
    return verts


def encode_vertices(mi, verts):
    """Pack per-usage values back into the template's stride and layout.

    Bytes of the stride not covered by any declaration are zero-filled; the
    encoder never invents a layout of its own.
    """
    stride = mi["vertex_stride"]
    out = bytearray()
    for rec in verts:
        buf = bytearray(stride)
        for d in mi["decls"]:
            _, off, dtype, _, usage, usage_idx = d
            if dtype not in ENCODERS:
                raise ValueError(f"no encoder for vertex data type {dtype}")
            val = rec.get((usage, usage_idx))
            if val is None:
                continue
            packed = ENCODERS[dtype](val)
            buf[off:off + len(packed)] = packed
        out += buf
    return bytes(out)


def position_type(mi):
    return next((d[2] for d in mi["decls"] if d[4] == POSITION), None)


def normalize_position(p, model):
    """World position -> the quantized-space value for an integer position."""
    out = []
    for i in range(3):
        scale = model["bbox"][i]
        out.append(0.0 if scale == 0 else (p[i] - model["offset"][i]) / scale)
    out.append(0.0)
    return tuple(out)


def denormalize_position(v, model, pos_type=None):
    """Stored position -> world. A float position is already world space."""
    if pos_type in WORLD_TYPES:
        return tuple(v[:3])
    return tuple(v[i] * model["bbox"][i] + model["offset"][i] for i in range(3))


# --------------------------------------------------------------------------
# triangle strips
# --------------------------------------------------------------------------

def strip_to_triangles(indices):
    """Same rule viewer.py uses, kept here so encode/decode stay in lockstep."""
    tris = []
    for i in range(len(indices) - 2):
        a, b, c = indices[i], indices[i + 1], indices[i + 2]
        if a == b or b == c or a == c:
            continue
        tris.append([a, b, c] if i % 2 == 0 else [b, a, c])
    return tris


def triangles_to_strip(tris):
    """Stitch a triangle list into one strip whose decode is exactly `tris`.

    Invariant: every real triangle starts at an even index (so the decoder's
    parity flip leaves its winding alone), and every window spanning a join is
    degenerate. After a triangle the strip has odd length, so the join
    [last, a, a] lands the next triangle on an even index and makes the three
    crossing windows (last, a, a), (a, a, a), (a, a, b) all degenerate.
    """
    strip = []
    for tri in tris:
        a, b, c = tri
        if a == b or b == c or a == c:
            raise ValueError(f"degenerate triangle {tri} cannot survive a strip")
        if not strip:
            strip += [a, b, c]
            continue
        strip += [strip[-1], a, a]
        strip += [a, b, c]
    return strip


def strip_length_for(tris):
    return len(triangles_to_strip(tris))


# --------------------------------------------------------------------------
# whole-mesh replacement
# --------------------------------------------------------------------------

def replace_geometry(template_bytes, mesh_index, verts, tris,
                     positions_are_world=True):
    """
    Build a new wrap.mesh from a template, replacing one mesh's geometry.

    verts: list of {(usage, usage_idx): tuple}. POSITION values are world
           space by default and get normalized against the model bbox.
    tris:  list of (i0, i1, i2) into verts.
    """
    m = wrapmesh.parse(template_bytes)
    mi = m.meshes[mesh_index]

    pos_type = position_type(mi)

    if positions_are_world and pos_type is not None:
        if pos_type not in QUANTIZED_TYPES and pos_type not in WORLD_TYPES:
            raise NotImplementedError(
                f"mesh {mesh_index} stores positions as raw type {pos_type}; "
                f"the mapping from world space for that type is not "
                f"established, so pass positions_are_world=False and supply "
                f"stored-space values")
        if pos_type in QUANTIZED_TYPES:
            verts = [dict(rec) for rec in verts]
            for rec in verts:
                p = rec.get((POSITION, 0))
                if p is not None:
                    rec[(POSITION, 0)] = normalize_position(p, m.model)

    if pos_type in QUANTIZED_TYPES:
        for i, rec in enumerate(verts):
            p = rec.get((POSITION, 0))
            if p is not None and any(not (-1.0001 <= c <= 1.0001)
                                     for c in p[:3]):
                raise ValueError(
                    f"vertex {i} falls outside the template's bounding box "
                    f"(normalized {tuple(round(c, 4) for c in p[:3])}); "
                    f"refit the model bbox or scale the geometry down")

    vb = encode_vertices(mi, verts)
    strip = triangles_to_strip(tris)
    fmt = "<H" if mi["index_size"] == 2 else "<I"
    limit = 0xFFFF if mi["index_size"] == 2 else 0xFFFFFFFF
    if strip and max(strip) > limit:
        raise ValueError(f"index {max(strip)} exceeds the template's "
                         f"{mi['index_size']}-byte index buffer")
    ib = b"".join(struct.pack(fmt, i) for i in strip)

    # the decoder must recover exactly the triangles we were given
    decoded = [tuple(t) for t in strip_to_triangles(strip)]
    if decoded != [tuple(t) for t in tris]:
        raise AssertionError("strip stitching lost or reordered triangles")

    return wrapmesh.rebuild(m, {
        f"mesh{mesh_index}_vertex_buffer": vb,
        f"mesh{mesh_index}_index_buffer": ib,
    })


# --------------------------------------------------------------------------
# OBJ
# --------------------------------------------------------------------------

def load_obj(path):
    """Minimal OBJ reader: v / vt / vn / f (triangles or fans)."""
    pos, uv, nrm = [], [], []
    faces = []
    with open(path, "r") as fh:
        for line in fh:
            parts = line.split()
            if not parts or parts[0].startswith("#"):
                continue
            tag = parts[0]
            if tag == "v":
                pos.append(tuple(float(x) for x in parts[1:4]))
            elif tag == "vt":
                uv.append(tuple(float(x) for x in parts[1:3]))
            elif tag == "vn":
                nrm.append(tuple(float(x) for x in parts[1:4]))
            elif tag == "f":
                corners = []
                for p in parts[1:]:
                    bits = (p.split("/") + ["", ""])[:3]
                    corners.append(tuple(int(b) - 1 if b else None
                                         for b in bits))
                for k in range(1, len(corners) - 1):
                    faces.append((corners[0], corners[k], corners[k + 1]))
    return pos, uv, nrm, faces


def obj_to_vertices(pos, uv, nrm, faces):
    """Flatten OBJ corner tuples into a unique vertex list + triangle list."""
    index_of = {}
    verts = []
    tris = []
    for tri in faces:
        out = []
        for corner in tri:
            if corner not in index_of:
                vi, ti, ni = corner
                rec = {(POSITION, 0): pos[vi] + (0.0,)}
                if ti is not None and ti < len(uv):
                    u, v = uv[ti]
                    rec[(TEXCOORD, 0)] = (u, 1.0 - v)
                if ni is not None and ni < len(nrm):
                    rec[(NORMAL, 0)] = nrm[ni] + (0.0,)
                index_of[corner] = len(verts)
                verts.append(rec)
            out.append(index_of[corner])
        tris.append(tuple(out))
    return verts, tris


# --------------------------------------------------------------------------
# whole-file authoring: replace several meshes, refit the bounds
# --------------------------------------------------------------------------

def world_geometry(m, mesh_index):
    """Decode one mesh into world-space vertex records + triangle list."""
    import struct as _struct
    mi = m.meshes[mesh_index]
    pt = position_type(mi)
    verts = decode_vertices(m, mesh_index)
    if pt in QUANTIZED_TYPES:
        for rec in verts:
            p = rec.get((POSITION, 0))
            if p is not None:
                rec[(POSITION, 0)] = denormalize_position(p, m.model, pt) + (0.0,)
    fmt = "<H" if mi["index_size"] == 2 else "<I"
    base = mi["index_buffer"].target
    idx = [_struct.unpack_from(fmt, m.data, base + k * mi["index_size"])[0]
           for k in range(mi["index_count"])]
    return verts, [tuple(t) for t in strip_to_triangles(idx)]


def bounds_of(verts):
    pts = [rec[(POSITION, 0)] for rec in verts if (POSITION, 0) in rec]
    if not pts:
        return None
    lo = [min(p[i] for p in pts) for i in range(3)]
    hi = [max(p[i] for p in pts) for i in range(3)]
    return lo, hi


def center_and_extent(lo, hi):
    """The convention the shipped files use: offset is the box centre and
    bbox is its half-extent, so stored values land in [-1, 1]."""
    centre = [(lo[i] + hi[i]) / 2 for i in range(3)]
    half = [(hi[i] - lo[i]) / 2 for i in range(3)]
    return centre, half


def _patch_bounds(region_bytes, float_offset, centre, half, template):
    """Rewrite an offset[4]/bbox[4] pair in place, keeping the 4th slots."""
    buf = bytearray(region_bytes)
    for i in range(3):
        struct.pack_into("<f", buf, float_offset + 4 * i, centre[i])
        struct.pack_into("<f", buf, float_offset + 16 + 4 * i, half[i])
    return bytes(buf)


def build_mesh_file(template_bytes, replacements=None, model_bounds=None,
                    update_mesh_bounds=True):
    """
    Author a wrap.mesh from a template.

    replacements: {mesh_index: (verts, tris)} with POSITION in world space.
    model_bounds: (lo, hi) world AABB to quantize against. Pass this when the
                  new geometry does not fit the template's box; every mesh with
                  a quantized position type is then re-encoded against it, so
                  untouched meshes keep their world positions.
    update_mesh_bounds: recompute each mesh's own bbox/offset from its
                  geometry, which is what the shipped files store.
    """
    replacements = dict(replacements or {})
    m = wrapmesh.parse(template_bytes)
    regions = {r.name: r for r in m.regions}

    # world-space geometry for every mesh: replaced ones from the caller,
    # the rest decoded from the template
    geom = {}
    for i in range(len(m.meshes)):
        if i in replacements:
            verts, tris = replacements[i]
            geom[i] = ([dict(rec) for rec in verts], list(tris))
        else:
            geom[i] = world_geometry(m, i)

    # new model box
    if model_bounds is None:
        centre = list(m.model["offset"][:3])
        half = list(m.model["bbox"][:3])
        box_changed = False
    else:
        lo, hi = model_bounds
        centre, half = center_and_extent(lo, hi)
        box_changed = any(
            abs(centre[i] - m.model["offset"][i]) > 1e-9
            or abs(half[i] - m.model["bbox"][i]) > 1e-9 for i in range(3))

    if box_changed:
        # a mesh we cannot re-encode would silently change meaning: its stored
        # values stay put while the box they are read against moves
        for i, mi in enumerate(m.meshes):
            pt = position_type(mi)
            if pt is not None and pt not in QUANTIZED_TYPES                     and pt not in WORLD_TYPES:
                raise NotImplementedError(
                    f"cannot move the model box: mesh {i} stores positions as "
                    f"raw type {pt}, which this encoder cannot re-quantize")

    new_model = {"offset": centre + [m.model["offset"][3]],
                 "bbox": half + [m.model["bbox"][3]]}

    edits = {}
    for i, mi in enumerate(m.meshes):
        verts, tris = geom[i]
        pt = position_type(mi)
        touched = i in replacements or (box_changed and pt in QUANTIZED_TYPES)

        if touched:
            packed = [dict(rec) for rec in verts]
            if pt in QUANTIZED_TYPES:
                for k, rec in enumerate(packed):
                    p = rec.get((POSITION, 0))
                    if p is None:
                        continue
                    q = normalize_position(p, new_model)
                    if any(not (-1.0001 <= c <= 1.0001) for c in q[:3]):
                        raise ValueError(
                            f"mesh {i} vertex {k} at {tuple(round(c,3) for c in p[:3])} "
                            f"falls outside the model box centre "
                            f"{[round(c,3) for c in centre]} half-extent "
                            f"{[round(c,3) for c in half]}; pass model_bounds "
                            f"that cover it")
                    rec[(POSITION, 0)] = q
            elif pt not in WORLD_TYPES and i in replacements:
                raise NotImplementedError(
                    f"mesh {i} stores positions as raw type {pt}; world-space "
                    f"authoring is not established for that type")
            edits[f"mesh{i}_vertex_buffer"] = encode_vertices(mi, packed)
            strip = triangles_to_strip(tris)
            limit = 0xFFFF if mi["index_size"] == 2 else 0xFFFFFFFF
            if strip and max(strip) > limit:
                raise ValueError(f"mesh {i}: index {max(strip)} exceeds the "
                                 f"template's {mi['index_size']}-byte indices")
            fmt = "<H" if mi["index_size"] == 2 else "<I"
            edits[f"mesh{i}_index_buffer"] = b"".join(
                struct.pack(fmt, k) for k in strip)
            decoded = [tuple(t) for t in strip_to_triangles(strip)]
            if decoded != [tuple(t) for t in tris]:
                raise AssertionError(f"mesh {i}: strip stitching lost triangles")

        if update_mesh_bounds:
            b = bounds_of(verts)
            if b is not None:
                mc, mh = center_and_extent(*b)
                r = regions[f"mesh{i}_info"]
                edits[f"mesh{i}_info"] = _patch_bounds(
                    m.data[r.start:r.end], 0, mc, mh, m)

    if model_bounds is not None or update_mesh_bounds:
        r = regions["model_header"]
        edits["model_header"] = _patch_bounds(
            m.data[r.start:r.end], 32, centre, half, m)

    return wrapmesh.rebuild(m, edits)


def required_model_bounds(template_bytes, replacements=None, margin=0.0):
    """The world AABB a model box must cover for these replacements.

    The model box quantizes EVERY mesh in the file, so it has to span the
    replaced geometry together with the meshes left alone.
    """
    replacements = dict(replacements or {})
    m = wrapmesh.parse(template_bytes)
    lo = [float("inf")] * 3
    hi = [float("-inf")] * 3
    for i in range(len(m.meshes)):
        if position_type(m.meshes[i]) not in QUANTIZED_TYPES \
                and i not in replacements:
            continue
        verts = (replacements[i][0] if i in replacements
                 else world_geometry(m, i)[0])
        b = bounds_of(verts)
        if b is None:
            continue
        for k in range(3):
            lo[k] = min(lo[k], b[0][k])
            hi[k] = max(hi[k], b[1][k])
    if any(x == float("inf") for x in lo):
        return None
    if margin:
        for k in range(3):
            span = hi[k] - lo[k]
            lo[k] -= span * margin
            hi[k] += span * margin
    return lo, hi


def _lerp_component(a, b):
    return tuple((x + y) / 2 for x, y in zip(a, b))


def subdivide_once(verts, tris):
    """One level of 1-to-4 subdivision, interpolating every vertex component.

    Midpoints are shared between adjacent triangles, so the result stays a
    closed surface with no seams.
    """
    verts = [dict(rec) for rec in verts]
    mid = {}

    def midpoint(i, j):
        key = (i, j) if i < j else (j, i)
        if key not in mid:
            rec = {}
            for usage in set(verts[i]) | set(verts[j]):
                if usage in verts[i] and usage in verts[j]:
                    rec[usage] = _lerp_component(verts[i][usage],
                                                 verts[j][usage])
                else:
                    rec[usage] = verts[i].get(usage, verts[j].get(usage))
            mid[key] = len(verts)
            verts.append(rec)
        return mid[key]

    out = []
    for a, b, c in tris:
        ab, bc, ca = midpoint(a, b), midpoint(b, c), midpoint(c, a)
        out += [(a, ab, ca), (ab, b, bc), (ca, bc, c), (ab, bc, ca)]
    return verts, out


def transform_positions(verts, fn):
    """Apply fn(x, y, z) -> (x, y, z) to every world-space position."""
    out = []
    for rec in verts:
        rec = dict(rec)
        p = rec.get((POSITION, 0))
        if p is not None:
            rec[(POSITION, 0)] = tuple(fn(*p[:3])) + (0.0,)
        out.append(rec)
    return out
