"""Replace an installed SA profile's collision with layered boxes.

Only the L23 SCGPC, the collision fields of the manifest, the teleports and
collision_loader/foundation_profile.h change; mesh, runtime textures and
anchors stay. The DLL must be rebuilt afterwards (its constants move).

    py -3 rebuild_collision.py SA_district_FoundationCOL
"""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import time

import build_district_foundation as F
import build_sa_world as W
import col_heightfield_boxes as C
import col_layer_boxes as B

SCENE = Path('L23/0x0001D211.L23.scgpc')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('profile')
    p.add_argument('--cell', type=float, default=2.0)
    p.add_argument('--step', type=float, default=0.25)
    p.add_argument('--fine', type=float, default=1.0,
                   help='sub-line spacing for cells along walls (col_fine_boxes); 0 = old one line per cell')
    p.add_argument('--staged-only', action='store_true',
                   help='write out/full_map only; exWoS and the DLL header stay as they are')
    a = p.parse_args()
    staged_root = W.OUT / a.profile
    installed_root = Path(__file__).resolve().parents[2] / 'exWoS' / a.profile
    manifest = json.loads((staged_root / 'manifest.json').read_text())
    shift = tuple(manifest['world_shift'])
    area = manifest['model_bounds']

    region = C.manifest_region(manifest)
    tris = C.district_triangles(shift, region=region, prop_test=C.is_walk_through)
    if a.fine:
        import col_fine_boxes as FB
        boxes, stats = FB.build_boxes(area, a.cell, a.step, tris, fine=a.fine)
    else:
        boxes, stats = B.build_boxes(area, a.cell, a.step, tris)
    # the street teleport keeps the 2.5D rules: there a pole is a column
    heights, _, _ = C.heightfield(C.district_triangles(shift, region=region), area, a.cell)
    ground_clear = C.street_teleport(heights, area, a.cell)
    original = (W.OUT / 'collision_research/L23/type_74_0001D211.bin').read_bytes()
    scene, info = F.build(original, boxes, F.NATIVE_CENTER_Y)
    control = info['native_control']
    native_teleport = (control['center'][0], control['hi'][1] + 2, control['center'][2])

    stamp = time.strftime('%Y%m%d_%H%M%S')
    backup = W.OUT / 'profile_backups' / f'{a.profile}_before_layered_collision_{stamp}'
    backup.mkdir(parents=True, exist_ok=True)
    for label, root in (('staged', staged_root), ('installed', installed_root)):
        if (root / SCENE).exists():
            (backup / label / 'L23').mkdir(parents=True, exist_ok=True)
            shutil.copy2(root / SCENE, backup / label / SCENE)
            shutil.copy2(root / 'manifest.json', backup / label / 'manifest.json')
    shutil.copy2(F.PROFILE_HEADER, backup / 'foundation_profile.h')

    manifest.update(
        collision=(f'{len(boxes)} type-4 boxes, layered: every solid interval along each '
                   f'{a.cell} m cell (depth count over closed SA COL volumes, {a.step} m bins); '
                   + (f'{stats["split_cells"]} cells along walls split into {a.fine} m lines (col_fine_boxes)'
                      if a.fine else
                      f'{stats["layered_cells"]} cells keep a gap (overpasses, awnings, the storm drain)')),
        collision_layout={k: v for k, v in info.items() if k != 'boxes'},
        probes=[{'name': 'sa_native_box', 'teleport': native_teleport},
                {'name': 'sa_ground_clear', 'teleport': ground_clear}],
        scene_sha256=hashlib.sha256(scene).hexdigest())
    text = json.dumps(manifest, indent=2).encode()
    for root in (staged_root, installed_root):
        if not root.exists() or (a.staged_only and root == installed_root):
            continue
        W.write(root / SCENE, scene)
        W.write(root / 'manifest.json', text)
        W.write(root / 'teleports/sa_native_box.txt', (' '.join(map(str, native_teleport)) + '\n').encode())
        W.write(root / 'teleports/sa_ground_clear.txt', (' '.join(map(str, ground_clear)) + '\n').encode())
    if a.staged_only:
        # the header for this scene waits beside it; install copies it to
        # collision_loader/profiles/<profile>.h before the DLL is built
        F.write_profile_header(staged_root / 'foundation_profile.h', scene, info, F.CONTROL_LEAF_OFFSET, a.profile)
    else:
        F.write_profile_header(F.PROFILE_HEADER, scene, info, F.CONTROL_LEAF_OFFSET, a.profile)
        # foundation_profile.h names one profile at a time; keep each profile's copy
        profiles = F.PROFILE_HEADER.parent / 'profiles'
        profiles.mkdir(exist_ok=True)
        shutil.copy2(F.PROFILE_HEADER, profiles / f'{a.profile}.h')
    print(json.dumps({'profile': a.profile, 'backup': str(backup), **stats,
                      'tree_depth': info['tree_depth'], 'leaf_count': info['leaf_count'],
                      'scene_bytes': len(scene), 'ground_clear': ground_clear}, indent=2))


if __name__ == '__main__':
    main()
