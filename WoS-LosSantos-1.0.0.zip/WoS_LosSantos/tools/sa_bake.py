"""
Bake a region of a San Andreas map into world-space triangle soup, ready for
the WoS mesh encoder.

Two conventions have to be pinned down before anything is trusted:

  * axes. SA is Z-up; WoS is Y-up (its meshes put height in y -- the dumpster
    spans y 0..2.3 while x and z are its footprint). SA is right-handed and
    WoS (Direct3D) left-handed, so (x, y, z)_SA maps to (x, z, y)_WoS, a
    reflection. The rotation (x, z, -y) used until 2026-09-30 mirrored the
    whole map (shop signs read backwards in game). A reflection reverses the
    winding, so bake() emits every triangle as (a, c, b): front faces stay
    front faces and make_map_mod.vertex_normals (-cross) still points out.
  * the IPL rotation quaternion. RenderWare stores the conjugate, so the
    rotation has to be applied with w negated. `pick_quaternion_convention`
    measures both against the city grid instead of taking it on faith.
"""

import collections
import math
import os

import sa_dff
import sa_ipl


def quat_matrix(q, conjugate=True):
    x, y, z, w = q
    if conjugate:
        w = -w
    n = math.sqrt(x * x + y * y + z * z + w * w)
    if n < 1e-12:
        return ((1, 0, 0), (0, 1, 0), (0, 0, 1))
    x, y, z, w = x / n, y / n, z / n, w / n
    return (
        (1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)),
        (2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)),
        (2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)),
    )


def transform(matrix, position, v):
    x = matrix[0][0] * v[0] + matrix[0][1] * v[1] + matrix[0][2] * v[2]
    y = matrix[1][0] * v[0] + matrix[1][1] * v[1] + matrix[1][2] * v[2]
    z = matrix[2][0] * v[0] + matrix[2][1] * v[1] + matrix[2][2] * v[2]
    return x + position[0], y + position[1], z + position[2]


def sa_to_wos(p):
    """SA is Z-up and right-handed, WoS is Y-up and left-handed."""
    return p[0], p[2], p[1]


class ModelCache:
    def __init__(self, dff_dir):
        self.dff_dir = dff_dir
        self.models = {}
        self.misses = set()

    def get(self, name):
        if name in self.models:
            return self.models[name]
        path = os.path.join(self.dff_dir, name + ".dff")
        if not os.path.exists(path):
            self.misses.add(name)
            self.models[name] = None
            return None
        try:
            self.models[name] = sa_dff.read_dff(path)
        except Exception:
            self.misses.add(name)
            self.models[name] = None
        return self.models[name]


def load_placement(ipl_dir, patterns, ide_root):
    return sa_ipl.load_world(ipl_dir, ide_root, patterns)[0]


def in_box(inst, box):
    """SA-space x/y rectangle (x0, y0, x1, y1), bounds included."""
    x0, y0, x1, y1 = box
    return x0 <= inst["pos"][0] <= x1 and y0 <= inst["pos"][1] <= y1


def in_area(inst, area):
    """area: (centre, radius) or ('box', (x0, y0, x1, y1)), SA space."""
    if area[0] == 'box':
        return in_box(inst, area[1])
    return in_region(inst, *area)


def in_region(inst, centre, radius):
    """SA-space test, before the axis swap: x/y are the ground plane."""
    dx = inst["pos"][0] - centre[0]
    dy = inst["pos"][1] - centre[1]
    return dx * dx + dy * dy <= radius * radius


def bake(instances, cache, conjugate=True, per_texture=True):
    """-> {group key: {"vertices": [...], "triangles": [...], "uvs": [...]}}

    Groups are keyed by texture name so each can later take one WoS material.
    """
    groups = {}
    skipped = collections.Counter()
    for inst in instances:
        name = inst.get("model")
        if not name:
            skipped["no_model_name"] += 1
            continue
        model = cache.get(name)
        if model is None:
            skipped["no_dff"] += 1
            continue
        m = quat_matrix(inst["rot"], conjugate)
        for g in model["geometries"]:
            if not g.vertices or not g.triangles:
                skipped["empty_geometry"] += 1
                continue
            by_mat = g.triangles_by_material()
            for mat_idx, tris in by_mat.items():
                valid = [t for t in tris if len(set(t)) == 3]
                skipped['degenerate_index_triangles'] += len(tris) - len(valid)
                tris = valid
                if not tris:
                    continue
                tex = ""
                if per_texture and mat_idx < len(g.materials):
                    tex = g.materials[mat_idx]["texture"].lower()
                    if inst.get('txd'):
                        tex = inst['txd'].lower() + '::' + tex
                grp = groups.setdefault(tex, {"vertices": [], "uvs": [],
                                              "triangles": []})
                base = len(grp["vertices"])
                used = sorted({k for tri in tris for k in tri})
                remap = {old: base + new for new, old in enumerate(used)}
                for k in used:
                    v = g.vertices[k]
                    world = transform(m, inst["pos"], v)
                    grp["vertices"].append(sa_to_wos(world))
                    grp["uvs"].append(g.uvs[k] if k < len(g.uvs) else (0.0, 0.0))
                for a, b, c in tris:  # the reflection reverses the winding
                    grp["triangles"].append((remap[a], remap[c], remap[b]))
    return groups, skipped


def compact(group):
    """Drop vertices no triangle references and renumber."""
    used = sorted({i for t in group["triangles"] for i in t})
    remap = {old: new for new, old in enumerate(used)}
    return {
        "vertices": [group["vertices"][i] for i in used],
        "uvs": [group["uvs"][i] for i in used],
        "triangles": [tuple(remap[i] for i in t) for t in group["triangles"]],
    }


def axis_alignment_score(group):
    """Fraction of triangle normals that point along a world axis.

    A city grid should score high; the wrong quaternion convention smears the
    street directions and scores lower.
    """
    hits = total = 0
    for a, b, c in group["triangles"]:
        pa, pb, pc = (group["vertices"][i] for i in (a, b, c))
        ux, uy, uz = (pb[0] - pa[0], pb[1] - pa[1], pb[2] - pa[2])
        vx, vy, vz = (pc[0] - pa[0], pc[1] - pa[1], pc[2] - pa[2])
        nx, ny, nz = (uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx)
        n = math.sqrt(nx * nx + ny * ny + nz * nz)
        if n < 1e-9:
            continue
        total += 1
        if max(abs(nx), abs(ny), abs(nz)) / n > 0.999:
            hits += 1
    return hits / total if total else 0.0


def pick_quaternion_convention(instances, cache):
    """Bake a sample both ways and report the axis-alignment of each."""
    out = {}
    for conjugate in (True, False):
        groups, _ = bake(instances, cache, conjugate=conjugate,
                         per_texture=False)
        merged = groups.get("", {"vertices": [], "uvs": [], "triangles": []})
        out[conjugate] = axis_alignment_score(merged)
    return out


def chunks(group, limit=0xFFFF):
    """Split a group into pieces that fit a 16-bit index buffer."""
    if limit < 3 or limit > 0xFFFF:
        raise ValueError("vertex limit must be between 3 and 65535")
    out = []
    current = {"vertices": [], "uvs": [], "triangles": []}
    remap = {}
    for tri in group["triangles"]:
        needed = sum(i not in remap for i in set(tri))
        if current["triangles"] and len(current["vertices"]) + needed > limit:
            out.append(current)
            current = {"vertices": [], "uvs": [], "triangles": []}
            remap = {}
        new = []
        for i in tri:
            if i not in remap:
                remap[i] = len(current["vertices"])
                current["vertices"].append(group["vertices"][i])
                current["uvs"].append(group["uvs"][i])
            new.append(remap[i])
        current["triangles"].append(tuple(new))
    if current["triangles"]:
        out.append(current)
    return out


def bounds(group):
    vs = group["vertices"]
    lo = [min(v[i] for v in vs) for i in range(3)]
    hi = [max(v[i] for v in vs) for i in range(3)]
    return lo, hi
