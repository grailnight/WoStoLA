"""
GTA San Andreas collision: COLL / COL2 / COL3 archives.

A .col file is a sequence of collision models, each:

    char[4]  "COLL" | "COL2" | "COL3"
    u32      size of everything after this field
    char[22] model name
    u16      model id
    -- bounds --
    COLL: float radius, float centre[3], float min[3], float max[3]
    COL2/3: float min[3], max[3], centre[3], radius
    -- counts and offsets (COL2/COL3 only; COLL inlines its arrays) --
    u16 spheres, u16 boxes, u16 faces, u8 lines, u8 pad, u32 flags,
    u32 off_spheres, off_boxes, off_lines, off_vertices, off_faces, off_planes
    COL3 also: u32 shadow_faces, u32 off_shadow_vertices, off_shadow_faces

COL2/3/4 section offsets are measured from the size field (start + 4),
four bytes before the model name. Model size still advances from start + 8.

Vertices in COL2/COL3 are int16 with a 1/128 scale; in COLL they are floats.
Faces are triangles with a 4-byte surface descriptor.

For WoS we need convex pieces: the boxes map to hulls one for one, the spheres
are approximable, and the face soup needs decomposition.
"""

import struct

SURFACE = struct.Struct("<4B")


class ColModel:
    def __init__(self, data, start):
        self.start = start
        self.fourcc = data[start:start + 4]
        if self.fourcc not in (b"COLL", b"COL2", b"COL3", b"COL4"):
            raise ValueError(f"unknown collision magic {self.fourcc!r} "
                             f"at 0x{start:X}")
        self.size = struct.unpack_from("<I", data, start + 4)[0]
        base = start + 8                      # model name and size start here
        offset_base = start + 4              # COL2/3/4 section offsets
        self.body_start = base
        self.end = base + self.size
        self.name = data[base:base + 22].split(b"\x00")[0].decode("latin-1")
        if self.end > len(data):
            raise ValueError(f"{self.fourcc.decode()} {self.name}: model exceeds archive")
        self.model_id = struct.unpack_from("<H", data, base + 22)[0]
        o = base + 24

        self.spheres = []
        self.boxes = []
        self.vertices = []
        self.faces = []

        if self.fourcc == b"COLL":
            self.radius, cx, cy, cz = struct.unpack_from("<4f", data, o)
            self.centre = (cx, cy, cz)
            self.bounds = struct.unpack_from("<6f", data, o + 16)
            o += 40
            n_spheres = struct.unpack_from("<I", data, o)[0]
            o += 4
            for i in range(n_spheres):
                r, x, y, z = struct.unpack_from("<4f", data, o)
                self.spheres.append({"radius": r, "centre": (x, y, z)})
                o += 20                        # + surface
            o += 4                             # unknown count, always 0
            n_boxes = struct.unpack_from("<I", data, o)[0]
            o += 4
            for i in range(n_boxes):
                mn = struct.unpack_from("<3f", data, o)
                mx = struct.unpack_from("<3f", data, o + 12)
                self.boxes.append({"min": mn, "max": mx})
                o += 28
            n_vertices = struct.unpack_from("<I", data, o)[0]
            o += 4
            self.vertices = [struct.unpack_from("<3f", data, o + 12 * i)
                             for i in range(n_vertices)]
            o += 12 * n_vertices
            n_faces = struct.unpack_from("<I", data, o)[0]
            o += 4
            for i in range(n_faces):
                a, b, c = struct.unpack_from("<3I", data, o)
                self.faces.append((a, b, c))
                o += 16
            return

        mn = struct.unpack_from("<3f", data, o)
        mx = struct.unpack_from("<3f", data, o + 12)
        self.bounds = mn + mx
        self.centre = struct.unpack_from("<3f", data, o + 24)
        self.radius = struct.unpack_from("<f", data, o + 36)[0]
        o += 40

        (n_spheres, n_boxes, n_faces, n_lines, pad,
         self.flags) = struct.unpack_from("<3H2BI", data, o)
        o += 12
        (off_spheres, off_boxes, off_lines, off_vertices, off_faces,
         off_planes) = struct.unpack_from("<6I", data, o)
        o += 24
        self.shadow = None
        if self.fourcc in (b"COL3", b"COL4"):
            n_shadow, off_shadow_v, off_shadow_f = struct.unpack_from(
                "<3I", data, o)
            o += 12
            if self.fourcc == b"COL4":
                o += 4
            self.shadow = {"faces": n_shadow, "vertices": off_shadow_v,
                           "faces_offset": off_shadow_f}

        def section(offset, stride, index):
            p = offset_base + offset + stride * index
            if offset == 0 or p < base or p + stride > self.end:
                raise ValueError(f"{self.name}: collision section outside model")
            return p

        for i in range(n_spheres):
            p = section(off_spheres, 20, i)
            r, x, y, z = struct.unpack_from("<4f", data, p)
            self.spheres.append({"radius": r, "centre": (x, y, z)})
        for i in range(n_boxes):
            p = section(off_boxes, 28, i)
            self.boxes.append({
                "min": struct.unpack_from("<3f", data, p),
                "max": struct.unpack_from("<3f", data, p + 12),
            })

        # the vertex count is not stored: it follows from the highest index
        max_index = -1
        raw_faces = []
        for i in range(n_faces):
            p = section(off_faces, 8, i)
            a, b, c = struct.unpack_from("<3H", data, p)
            raw_faces.append((a, b, c))
            max_index = max(max_index, a, b, c)
        self.faces = raw_faces
        n_vertices = max_index + 1
        for i in range(n_vertices):
            p = section(off_vertices, 6, i)
            x, y, z = struct.unpack_from("<3h", data, p)
            self.vertices.append((x / 128.0, y / 128.0, z / 128.0))

    def face_bounds(self):
        if not self.vertices:
            return None
        lo = [min(v[i] for v in self.vertices) for i in range(3)]
        hi = [max(v[i] for v in self.vertices) for i in range(3)]
        return lo, hi

    def __repr__(self):
        return (f"{self.fourcc.decode()} {self.name!r} id={self.model_id} "
                f"spheres={len(self.spheres)} boxes={len(self.boxes)} "
                f"faces={len(self.faces)} verts={len(self.vertices)}")


def read_col(path_or_bytes):
    data = (open(path_or_bytes, "rb").read()
            if isinstance(path_or_bytes, str) else path_or_bytes)
    models = []
    pos = 0
    while pos + 8 <= len(data):
        if data[pos:pos + 4] not in (b"COLL", b"COL2", b"COL3", b"COL4"):
            break
        m = ColModel(data, pos)
        models.append(m)
        if m.end <= pos:
            raise ValueError("collision model does not advance")
        pos = m.end
    return models, pos
