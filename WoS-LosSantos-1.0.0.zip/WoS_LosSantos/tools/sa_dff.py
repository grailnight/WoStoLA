"""
RenderWare DFF reader: enough of the clump format to get world-ready triangles.

Every RenderWare file is a tree of chunks:
    u32 type, u32 size, u32 library id   then `size` bytes of body

The parts that matter for geometry:
    Clump (0x10)
      FrameList (0x0E)      -> frame transforms, parents
      GeometryList (0x1A)
        Geometry (0x0F)     -> vertices, normals, colours, UVs, triangles
          MaterialList (0x08) -> Material (0x07) -> Texture (0x06)
          Extension (0x03)  -> BinMeshPLG (0x50E) gives the real draw order,
                               as either a triangle list or strips
      Atomic (0x14)         -> binds a geometry to a frame
"""

import struct

# chunk ids
STRUCT = 0x01
STRING = 0x02
EXTENSION = 0x03
TEXTURE = 0x06
MATERIAL = 0x07
MATERIAL_LIST = 0x08
FRAME_LIST = 0x0E
GEOMETRY = 0x0F
CLUMP = 0x10
ATOMIC = 0x14
GEOMETRY_LIST = 0x1A
BIN_MESH_PLG = 0x50E

# geometry flags
FLAG_TRISTRIP = 0x01
FLAG_POSITIONS = 0x02
FLAG_TEXTURED = 0x04
FLAG_PRELIT = 0x08
FLAG_NORMALS = 0x10
FLAG_TEXTURED2 = 0x80


class Chunk:
    __slots__ = ("type", "size", "version", "body_start", "body_end", "data")

    def __init__(self, data, offset):
        self.type, self.size, self.version = struct.unpack_from(
            "<3I", data, offset)
        self.body_start = offset + 12
        self.body_end = self.body_start + self.size
        self.data = data

    def children(self):
        pos = self.body_start
        while pos + 12 <= self.body_end:
            c = Chunk(self.data, pos)
            if c.body_end > self.body_end:
                break
            yield c
            pos = c.body_end

    def child(self, type_id):
        for c in self.children():
            if c.type == type_id:
                return c
        return None

    def __repr__(self):
        return f"Chunk(0x{self.type:X}, {self.size} bytes)"


def chunks(data):
    pos = 0
    while pos + 12 <= len(data):
        c = Chunk(data, pos)
        if c.body_end > len(data):
            break
        yield c
        pos = c.body_end


class Geometry:
    def __init__(self, chunk):
        d = chunk.data
        st = chunk.child(STRUCT)
        if st is None:
            raise ValueError("geometry without a struct chunk")
        o = st.body_start
        self.flags, self.triangle_count, self.vertex_count, morph_count = \
            struct.unpack_from("<I3i", d, o)
        o += 16
        if chunk.version < 0x34000:
            o += 12   # ambient, diffuse, specular
        self.colours = []
        self.uvs = []
        self.triangles = []
        if self.flags & FLAG_PRELIT:
            self.colours = [struct.unpack_from("<4B", d, o + 4 * i)
                            for i in range(self.vertex_count)]
            o += 4 * self.vertex_count
        uv_sets = 2 if self.flags & FLAG_TEXTURED2 else \
            (1 if self.flags & FLAG_TEXTURED else 0)
        # the high nibble can also carry the count
        uv_sets = max(uv_sets, (self.flags >> 16) & 0xFF)
        for s in range(uv_sets):
            uvs = [struct.unpack_from("<2f", d, o + 8 * i)
                   for i in range(self.vertex_count)]
            o += 8 * self.vertex_count
            if s == 0:
                self.uvs = uvs
        for i in range(self.triangle_count):
            # RenderWare stores the indices as (v2, v1, mat, v3), and the
            # obvious reading is to put them back as (v1, v2, v3). That is
            # backwards for us: built both ways side by side in game, the
            # district wearing THIS order is the one whose near wall is culled
            # away, leaving its far wall seen from inside. Keeping the stored
            # order is what gives WoS front faces. Vertex normals are built
            # from these triangles and must be -cross(b-a, c-a) in this order
            # (make_map_mod.vertex_normals); +cross points into the building.
            v2, v1, mat, v3 = struct.unpack_from("<4H", d, o + 8 * i)
            self.triangles.append((v2, v1, v3, mat))
        o += 8 * self.triangle_count

        # morph target: bounding sphere, then the vertex arrays
        self.sphere = struct.unpack_from("<4f", d, o)
        has_vertices, has_normals = struct.unpack_from("<2I", d, o + 16)
        o += 24
        self.vertices = []
        self.normals = []
        if has_vertices:
            self.vertices = [struct.unpack_from("<3f", d, o + 12 * i)
                             for i in range(self.vertex_count)]
            o += 12 * self.vertex_count
        if has_normals:
            self.normals = [struct.unpack_from("<3f", d, o + 12 * i)
                            for i in range(self.vertex_count)]
            o += 12 * self.vertex_count
        self.struct_end = o

        # materials
        self.materials = []
        ml = chunk.child(MATERIAL_LIST)
        if ml is not None:
            for m in ml.children():
                if m.type != MATERIAL:
                    continue
                tex = m.child(TEXTURE)
                name = ""
                if tex is not None:
                    s = tex.child(STRING)
                    if s is not None:
                        name = d[s.body_start:s.body_end].split(b"\x00")[0] \
                            .decode("latin-1")
                mst = m.child(STRUCT)
                colour = struct.unpack_from("<4B", d, mst.body_start + 4) \
                    if mst is not None else (255, 255, 255, 255)
                self.materials.append({"texture": name, "colour": colour})

        # draw order
        self.bin_mesh = None
        ext = chunk.child(EXTENSION)
        if ext is not None:
            bm = ext.child(BIN_MESH_PLG)
            if bm is not None:
                self.bin_mesh = self._read_bin_mesh(d, bm)

    @staticmethod
    def _read_bin_mesh(d, chunk):
        o = chunk.body_start
        flags, count, total = struct.unpack_from("<3I", d, o)
        o += 12
        meshes = []
        for _ in range(count):
            n_indices, material = struct.unpack_from("<2I", d, o)
            o += 8
            indices = list(struct.unpack_from(f"<{n_indices}I", d, o))
            o += 4 * n_indices
            meshes.append({"material": material, "indices": indices})
        return {"is_strip": bool(flags & 1), "meshes": meshes}

    def triangles_by_material(self):
        """{material index: [(i0, i1, i2)]} from the triangle list."""
        out = {}
        for v1, v2, v3, mat in self.triangles:
            out.setdefault(mat, []).append((v1, v2, v3))
        return out

    def bounds(self):
        if not self.vertices:
            return None
        lo = [min(v[i] for v in self.vertices) for i in range(3)]
        hi = [max(v[i] for v in self.vertices) for i in range(3)]
        return lo, hi


class Frame:
    def __init__(self, matrix, position, parent):
        self.matrix = matrix        # 3x3 rotation, row major
        self.position = position
        self.parent = parent


def read_dff(path_or_bytes):
    data = (open(path_or_bytes, "rb").read()
            if isinstance(path_or_bytes, str) else path_or_bytes)
    clump = None
    for c in chunks(data):
        if c.type == CLUMP:
            clump = c
            break
    if clump is None:
        raise ValueError("no clump chunk")

    frames = []
    fl = clump.child(FRAME_LIST)
    if fl is not None:
        st = fl.child(STRUCT)
        n = struct.unpack_from("<I", data, st.body_start)[0]
        o = st.body_start + 4
        for _ in range(n):
            vals = struct.unpack_from("<12f", data, o)
            parent = struct.unpack_from("<i", data, o + 48)[0]
            frames.append(Frame((vals[0:3], vals[3:6], vals[6:9]),
                                vals[9:12], parent))
            o += 56

    geometries = []
    gl = clump.child(GEOMETRY_LIST)
    if gl is not None:
        for g in gl.children():
            if g.type == GEOMETRY:
                geometries.append(Geometry(g))

    atomics = []
    for c in clump.children():
        if c.type != ATOMIC:
            continue
        st = c.child(STRUCT)
        frame_idx, geom_idx = struct.unpack_from("<2I", data, st.body_start)
        atomics.append((frame_idx, geom_idx))

    return {"frames": frames, "geometries": geometries, "atomics": atomics}
