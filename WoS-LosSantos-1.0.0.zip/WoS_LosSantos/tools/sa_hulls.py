"""
Convex collision for baked San Andreas geometry.

WoS collision is a set of CONVEX hulls, so SA's triangle soup cannot go in as
it stands. The cheap decomposition that is actually true to the source: one box
per placed instance, being that instance's model bounds rotated into the world
and re-fitted to an axis-aligned box. Los Santos is mostly boxy buildings and
flat road patches, so a box per instance is a fair first approximation -- what
it loses is overhangs, arches and the space under raised freeways.

Hulls are built the way the shipped ones are: an outward plane per face with
`n . v == d`, a bounding sphere, and an AABB grown by the 0.1 collision margin.
"""

import math

import colmesh
import sa_bake

# the six faces of a box as vertex quads, in the vertex order built below
FACES = [
    (0, 1, 3, 2),   # -x
    (4, 6, 7, 5),   # +x
    (0, 4, 5, 1),   # -y
    (2, 3, 7, 6),   # +y
    (0, 2, 6, 4),   # -z
    (1, 5, 7, 3),   # +z
]


# No shipped hull in the city has zero extent on any axis -- the thinnest in
# cell M04 measures 0.0002. A flat road plate boxes to exactly zero thickness,
# which is a convex hull with no volume; the first build shipped one and the
# game died on approach. Every box is inflated to at least this.
MIN_THICKNESS = 0.05


def box_hull(lo, hi, min_thickness=MIN_THICKNESS):
    """A Hull covering the axis-aligned box, ready for colmesh.build_pccvx."""
    lo, hi = list(lo), list(hi)
    for k in range(3):
        short = min_thickness - (hi[k] - lo[k])
        if short > 0:
            lo[k] -= short / 2
            hi[k] += short / 2
    verts = [(x, y, z)
             for x in (lo[0], hi[0])
             for y in (lo[1], hi[1])
             for z in (lo[2], hi[2])]
    centre = tuple((lo[i] + hi[i]) / 2 for i in range(3))

    faces = []
    for quad in FACES:
        for a, b, c in ((quad[0], quad[1], quad[2]),
                        (quad[0], quad[2], quad[3])):
            n = _normal(verts[a], verts[b], verts[c])
            # outward: away from the box centre
            if sum(n[i] * (verts[a][i] - centre[i]) for i in range(3)) < 0:
                a, c = c, a
                n = tuple(-v for v in n)
            d = sum(n[i] * verts[a][i] for i in range(3))
            faces.append({"indices": (a, b, c), "pad": 0,
                          "plane": n + (d,)})

    radius = math.sqrt(sum(((hi[i] - lo[i]) / 2) ** 2 for i in range(3)))
    h = colmesh.Hull.__new__(colmesh.Hull)
    h.vertices = verts
    h.faces = faces
    h.sphere = centre + (radius,)
    h.aabb = tuple(c - colmesh.AABB_MARGIN for c in lo) + \
             tuple(c + colmesh.AABB_MARGIN for c in hi)
    h.vertex_count = len(verts)
    h.face_count = len(faces)
    return h


def _normal(a, b, c):
    u = tuple(b[i] - a[i] for i in range(3))
    v = tuple(c[i] - a[i] for i in range(3))
    n = (u[1] * v[2] - u[2] * v[1],
         u[2] * v[0] - u[0] * v[2],
         u[0] * v[1] - u[1] * v[0])
    length = math.sqrt(sum(k * k for k in n))
    return tuple(k / length for k in n) if length > 1e-12 else (0.0, 1.0, 0.0)


def instance_box(inst, model, shift=(0.0, 0.0, 0.0)):
    """The instance's model bounds, rotated into WoS world space, re-boxed.

    Returns None for a model with no geometry. `shift` is added afterwards, so
    the same translation that moved the baked mesh moves its collision.
    """
    lo = [float("inf")] * 3
    hi = [float("-inf")] * 3
    for g in model["geometries"]:
        b = g.bounds()
        if not b:
            continue
        for k in range(3):
            lo[k] = min(lo[k], b[0][k])
            hi[k] = max(hi[k], b[1][k])
    if lo[0] == float("inf"):
        return None

    m = sa_bake.quat_matrix(inst["rot"], conjugate=True)
    wlo = [float("inf")] * 3
    whi = [float("-inf")] * 3
    for cx in (lo[0], hi[0]):
        for cy in (lo[1], hi[1]):
            for cz in (lo[2], hi[2]):
                p = sa_bake.sa_to_wos(
                    sa_bake.transform(m, inst["pos"], (cx, cy, cz)))
                for k in range(3):
                    wlo[k] = min(wlo[k], p[k])
                    whi[k] = max(whi[k], p[k])
    return ([wlo[k] + shift[k] for k in range(3)],
            [whi[k] + shift[k] for k in range(3)])


def hulls_for(instances, cache, shift=(0.0, 0.0, 0.0), min_size=0.5,
              limit=None):
    """One box hull per instance, biggest first.

    `limit` keeps only that many, chosen by volume: a cell has a fixed number
    of hull slots, so when the district has more instances than the cell has
    room for, the buildings should win over the street furniture.
    """
    boxes = []
    for inst in instances:
        model = cache.get(inst.get("model"))
        if model is None:
            continue
        box = instance_box(inst, model, shift)
        if box is None:
            continue
        lo, hi = box
        if max(hi[k] - lo[k] for k in range(3)) < min_size:
            continue
        volume = 1.0
        for k in range(3):
            volume *= max(hi[k] - lo[k], MIN_THICKNESS)
        boxes.append((volume, lo, hi))
    boxes.sort(key=lambda b: -b[0])
    if limit is not None:
        boxes = boxes[:limit]
    return [box_hull(lo, hi) for _, lo, hi in boxes]


def degenerate(hulls, floor=1e-4):
    """Hulls with no volume -- the shape that crashed the game."""
    bad = []
    for h in hulls:
        lo = [min(v[i] for v in h.vertices) for i in range(3)]
        hi = [max(v[i] for v in h.vertices) for i in range(3)]
        if min(hi[i] - lo[i] for i in range(3)) <= floor:
            bad.append(h)
    return bad


def worst_plane_error(hulls):
    """Sanity check: every face's own vertices must lie on its stored plane."""
    return max((h.plane_error(f) for h in hulls for f in h.faces), default=0.0)
