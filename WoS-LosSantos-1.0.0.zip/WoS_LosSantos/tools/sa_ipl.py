"""
GTA San Andreas placement: binary IPL ("bnry") readers, plus IDE lookup so an
object id becomes a model name.

Binary IPL header: "bnry", then counts for the INST / unknown / CARS sections
and the offset of the INST table. Each INST entry is 40 bytes:
    float32 x3  position
    float32 x4  rotation quaternion (x, y, z, w)
    int32       object id  (maps to a model name through the .ide files)
    int32       interior
    int32       lod index: the index in the parent text IPL table of the coarse
                stand-in for THIS object, or -1 when it has none. It does not
                mark the instance as a stand-in -- the stand-ins are the
                parent-table instances other entries point at. Binary stream
                entries must NOT be removed by their local array index.
                Filtering on lod == -1
                throws away every building and road (they all have LODs) while
                keeping only small props.
"""

import os
import struct

INST = struct.Struct("<3f4f3i")
# Area code 13 is not an interior: the object is drawn in EVERY area, the
# outside world included (roads, plazas, lamps and traffic lights near interior
# entrances carry it). Dropping it with the interiors left 219 exterior objects
# out of the Los Santos box -- the ground around the Bonaventure hotel and the
# courthouse, GSFreeway spans, East LS roads, 70 traffic lights (2026-09-30).
EVERY_AREA = 13


def read_ipl(path):
    with open(path, "rb") as fh:
        data = fh.read()
    if data[:4] != b"bnry":
        raise ValueError(f"{os.path.basename(path)} is not a binary IPL")
    (n_inst, n_unk1, n_unk2, n_unk3, n_cars, n_unk4,
     inst_offset) = struct.unpack_from("<7i", data, 4)
    out = []
    for i in range(n_inst):
        x, y, z, rx, ry, rz, rw, obj_id, interior, lod = INST.unpack_from(
            data, inst_offset + i * INST.size)
        out.append({
            "pos": (x, y, z),
            "rot": (rx, ry, rz, rw),
            "id": obj_id,
            "interior": interior,
            "lod": lod,
        })
    return out, {"n_inst": n_inst, "n_cars": n_cars}


def read_ide_dir(*dirs):
    """{object id: model name} from every .ide under the given directories.

    Only the objects sections matter here: each line starts with the id, then
    the model name, then the texture dictionary.
    """
    names = {}
    for d in dirs:
        for dirpath, _, files in os.walk(d):
            for n in files:
                if not n.lower().endswith(".ide"):
                    continue
                section = None
                with open(os.path.join(dirpath, n), "r",
                          errors="replace") as fh:
                    for line in fh:
                        line = line.split("#")[0].strip()
                        if not line:
                            continue
                        low = line.lower()
                        if low in ("objs", "tobj", "anim", "cars", "peds",
                                   "weap", "hier", "txdp", "2dfx", "path"):
                            section = low
                            continue
                        if low == "end":
                            section = None
                            continue
                        if section in ("objs", "tobj", "anim"):
                            parts = [p.strip() for p in line.split(",")]
                            if len(parts) >= 3 and parts[0].isdigit():
                                names[int(parts[0])] = parts[1]
    return names


def read_ide_txd(*dirs):
    """{object id: texture dictionary name} from every .ide.

    The same lines `read_ide_dir` walks, keeping the third field instead of the
    second. Textures are looked up by name inside a dictionary, and a name is
    only unique within one -- `ws_rooftarmac1` appears in hundreds -- so
    getting a model's pixels means knowing which .txd to open for it.
    """
    txds = {}
    for d in dirs:
        for dirpath, _, files in os.walk(d):
            for n in files:
                if not n.lower().endswith(".ide"):
                    continue
                section = None
                with open(os.path.join(dirpath, n), "r",
                          errors="replace") as fh:
                    for line in fh:
                        line = line.split("#")[0].strip()
                        if not line:
                            continue
                        low = line.lower()
                        if low in ("objs", "tobj", "anim", "cars", "peds",
                                   "weap", "hier", "txdp", "2dfx", "path"):
                            section = low
                            continue
                        if low == "end":
                            section = None
                            continue
                        if section in ("objs", "tobj", "anim"):
                            parts = [p.strip() for p in line.split(",")]
                            if len(parts) >= 3 and parts[0].isdigit():
                                txds[int(parts[0])] = parts[2]
    return txds



def read_ide_draw(*dirs):
    """{object id: draw distance in metres} from every .ide.

    SA lines: objs `id, model, txd, dist, flags` (or `id, model, txd,
    meshcount, dist, flags`), tobj the same plus timeOn/timeOff, anim
    `id, model, txd, anim, dist, flags`.
    """
    dist = {}
    for d in dirs:
        for dirpath, _, files in os.walk(d):
            for n in files:
                if not n.lower().endswith(".ide"):
                    continue
                section = None
                with open(os.path.join(dirpath, n), "r",
                          errors="replace") as fh:
                    for line in fh:
                        line = line.split("#")[0].strip()
                        if not line:
                            continue
                        low = line.lower()
                        if low in ("objs", "tobj", "anim", "cars", "peds",
                                   "weap", "hier", "txdp", "2dfx", "path"):
                            section = low
                            continue
                        if low == "end":
                            section = None
                            continue
                        if section not in ("objs", "tobj", "anim"):
                            continue
                        parts = [p.strip() for p in line.split(",")]
                        if len(parts) < 5 or not parts[0].isdigit():
                            continue
                        core = len(parts) - (2 if section == "tobj" else 0)
                        field = 3 if (core == 5 and section != "anim") else 4
                        try:
                            dist[int(parts[0])] = float(parts[field])
                        except (ValueError, IndexError):
                            pass
    return dist


def real_instances(instances):
    """Filter a standalone TEXT IPL only; not valid for binary stream IPLs.

    Full-map import must use load_world(), which resolves parent/stream links.
    """
    stand_ins = {i["lod"] for i in instances if i["lod"] >= 0}
    return [i for n, i in enumerate(instances) if n not in stand_ins]


def read_text_ipl(path):
    out = []
    section = None
    with open(path, encoding='latin-1') as fh:
        for number, line in enumerate(fh, 1):
            line = line.split('#', 1)[0].strip()
            if not line:
                continue
            if line.lower() == 'end':
                section = None
            elif ',' not in line:
                section = line.lower()
            elif section == 'inst':
                p = [v.strip() for v in line.split(',')]
                if len(p) != 11:
                    raise ValueError(f'{path}:{number}: expected 11 SA INST fields')
                out.append({'id': int(p[0]), 'model': p[1], 'interior': int(p[2]),
                            'pos': tuple(map(float,p[3:6])),
                            'rot': tuple(map(float,p[6:10])), 'lod': int(p[10])})
    return out


def load_world(ipl_dir, ide_root, patterns=None):
    """Join registered text IPLs with their *_streamN.ipl files.

    CIplStore::LoadIpl resolves stream LODs through IplEntityIndexArrays[staticIdx].
    CFileLoader::LoadScene fills that array from the parent text IPL.
    Source: github.com/gta-reversed/gta-reversed/source/game_sa/IplStore.cpp
    and FileLoader.cpp (LoadScene / SetupRelatedIpls / LinkLods).
    """
    import glob
    import fnmatch
    import collections
    names = read_ide_dir(ide_root)
    txds = read_ide_txd(ide_root)
    root = os.path.dirname(os.path.abspath(ide_root))
    dat = os.path.join(ide_root, 'gta.dat')
    parents = []
    with open(dat, encoding='latin-1') as fh:
        for line in fh:
            p = line.split('#',1)[0].strip().split(None,1)
            if len(p)==2 and p[0].lower()=='ipl' and p[1].lower().endswith('.ipl'):
                parents.append(os.path.join(root,p[1].replace('\\',os.sep)))
    # escape: a folder like "Web of Shadows [repack]" is not a glob pattern
    streams = sorted(glob.glob(os.path.join(glob.escape(ipl_dir),'*.ipl')))
    used = set()
    out = []
    stats = collections.Counter()
    for path in parents:
        stem = os.path.splitext(os.path.basename(path))[0].lower()
        related = [p for p in streams if os.path.basename(p).lower().startswith(stem+'_stream')]
        if patterns and not any(fnmatch.fnmatch(os.path.basename(p).lower(),pat.lower())
                                for pat in patterns for p in [path]+related):
            continue
        text = read_text_ipl(path)
        binary = []
        for p in related:
            rows,_ = read_ipl(p)
            for i in rows:
                i['src'] = os.path.basename(p)
            binary.extend(rows)
            used.add(p)
        targets = {i['lod'] for i in text+binary if i['lod'] >= 0}
        bad = [i for i in targets if i >= len(text)]
        if bad:
            raise ValueError(f'{path}: LOD references outside parent table: {bad[:8]}')
        stats['text_instances'] += len(text)
        stats['binary_instances'] += len(binary)
        stats['lod_instances_removed'] += len(targets)
        for n,i in enumerate(text):
            i['src'] = os.path.basename(path)
        candidates = [i for n,i in enumerate(text) if n not in targets]+binary
        for i in candidates:
            # Area code is the low byte; high bits include don't-stream flags.
            area = i['interior'] & 255
            if area and area != EVERY_AREA:
                stats['interior_instances_removed'] += 1
                continue
            if area == EVERY_AREA:
                stats['every_area_instances_kept'] += 1
            i['model'] = names.get(i['id'], i.get('model'))
            i['txd'] = txds.get(i['id'], '').lower()
            out.append(i)
    stats['world_instances'] = len(out)
    stats['stream_files_loaded'] = len(used)
    stats['unassociated_stream_files'] = [os.path.basename(p) for p in streams if p not in used]
    return out,dict(stats)


def bounds_of(instances):
    lo = [min(i["pos"][k] for i in instances) for k in range(3)]
    hi = [max(i["pos"][k] for i in instances) for k in range(3)]
    return lo, hi
