"""GTA SA path nodes (nodes0..63.dat): vehicle and pedestrian graphs.

Layout (per area file, SA PC):
    header: u32 nodes, vehicle nodes, ped nodes, navi nodes, links
    node (28 B): u32 mem, u32 zero, i16 x, y, z (/8), i16 heuristic,
                 u16 link id, u16 area id, u16 node id, u8 path width (/8),
                 u8 flood fill, u32 flags (bits 0-3 link count, ...)
    navi node (14 B): i16 x, y (/8), u16 area, u16 node, i8 dir x, y, u32 flags
    link (4 B): u16 area, u16 node
    then 768 filler bytes, navi links (2 B each), link lengths (1 B each),
    path intersection flags (1 B each)
Vehicle nodes come first, then pedestrian nodes.

    py -3 sa_paths.py [x0,y0,x1,y1]   # counts inside a SA box
"""
import struct
import sys
from pathlib import Path

import make_map_mod as M


def read_area(data):
    n, nveh, nped, nnavi, nlinks = struct.unpack_from('<5I', data, 0)
    off = 20
    nodes = []
    for i in range(n):
        (_, _, x, y, z, _, link, area, node, width, flood, flags) = struct.unpack_from('<IIhhhhHHHBBI', data, off)
        nodes.append({'pos': (x / 8.0, y / 8.0, z / 8.0), 'link': link, 'links': flags & 0xF,
                      'area': area, 'node': node, 'width': width / 8.0, 'flags': flags,
                      'ped': i >= nveh})
        off += 28
    off += 14 * nnavi
    links = [struct.unpack_from('<HH', data, off + 4 * k) for k in range(nlinks)]
    return nodes, links


def read_area_full(data):
    """Nodes, links and the lane data of each link (via its navi node).

    Navi node flags: bits 0-7 median width (/8), 8-10 lanes along the navi
    direction, 11-13 lanes against it. Which way "along" drives was settled
    on the divided avenues of Los Santos (right-hand traffic puts the other
    carriageway on the left): the bits 8-10 lanes run along the direction.
    """
    n, nveh, nped, nnavi, nlinks = struct.unpack_from('<5I', data, 0)
    nodes = []
    for i in range(n):
        (_, _, x, y, z, _, link, area, node, width, flood, flags) = struct.unpack_from('<IIhhhhHHHBBI', data, 20 + 28 * i)
        nodes.append({'pos': (x / 8.0, y / 8.0, z / 8.0), 'link': link, 'links': flags & 0xF,
                      'area': area, 'node': node, 'width': width / 8.0, 'flags': flags,
                      'ped': i >= nveh})
    off = 20 + 28 * n
    navi = []
    for i in range(nnavi):
        x, y, area, node, dx, dy, fl = struct.unpack_from('<hhHHbbI', data, off + 14 * i)
        navi.append({'pos': (x / 8.0, y / 8.0), 'dir': (dx / 100.0, dy / 100.0),
                     'along': (fl >> 8) & 7, 'against': (fl >> 11) & 7, 'median': (fl & 0xFF) / 8.0})
    off += 14 * nnavi
    links = [struct.unpack_from('<HH', data, off + 4 * k) for k in range(nlinks)]
    off += 4 * nlinks + 768
    navi_links = [struct.unpack_from('<H', data, off + 2 * k)[0] for k in range(nlinks)]
    navi_links = [(v >> 10, v & 0x3FF) for v in navi_links]
    return nodes, links, navi, navi_links


def load_full(sa_dir=M.SA_DIR):
    return {i: read_area_full((Path(sa_dir) / f'nodes{i}.dat').read_bytes())
            for i in range(64) if (Path(sa_dir) / f'nodes{i}.dat').exists()}


def load_all(sa_dir=M.SA_DIR):
    areas = {}
    for i in range(64):
        p = Path(sa_dir) / f'nodes{i}.dat'
        if p.exists():
            areas[i] = read_area(p.read_bytes())
    return areas


def edges(areas):
    """-> list of (node a, node b) dicts, each undirected edge once."""
    out = []
    for aid, (nodes, links) in areas.items():
        for nd in nodes:
            for k in range(nd['links']):
                la, ln = links[nd['link'] + k]
                if la not in areas or ln >= len(areas[la][0]):
                    continue
                other = areas[la][0][ln]
                if (la, ln) > (aid, nd['node']):
                    out.append((nd, other))
    return out


if __name__ == '__main__':
    box = tuple(float(v) for v in sys.argv[1].split(',')) if len(sys.argv) > 1 else (0, -2800, 3000, -500)
    areas = load_all()
    inside = lambda nd: box[0] <= nd['pos'][0] <= box[2] and box[1] <= nd['pos'][1] <= box[3]
    allnodes = [nd for nodes, _ in areas.values() for nd in nodes]
    sel = [nd for nd in allnodes if inside(nd)]
    es = [e for e in edges(areas) if inside(e[0]) and inside(e[1])]
    print(f'areas {len(areas)}, nodes {len(allnodes)}; in box: vehicle {sum(not n["ped"] for n in sel)}, '
          f'ped {sum(n["ped"] for n in sel)}; edges vehicle {sum(not a["ped"] for a, b in es)}, '
          f'ped {sum(a["ped"] for a, b in es)}; total length '
          f'{sum(((a["pos"][0]-b["pos"][0])**2+(a["pos"][1]-b["pos"][1])**2)**0.5 for a, b in es)/1000:.1f} km')
