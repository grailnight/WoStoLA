"""Runtime textures and web-swing anchors for an SA district profile.

Textures: instead of overwriting NYC textures that one material samples (the
old victim scheme, 112 files, and 59 SA groups got no texture at all), every
slot now wears the stock facade material unchanged and SA_CollisionLoader.dll
swaps the SA texture in at draw time. Slots are told apart by primitive
count, made unique with degenerate strip padding. sa_runtime/textures.bin:

    'SATX' u32 version=3, u32 slots, u32 textures
    match texture: u32 fourcc, width, height, mips, level0 size, level0 bytes
    per slot:      u32 primitives, u32 vertices, i32 texture (-1 = keep facade),
                   u32 flags (bit 0 = cutout: the DLL alpha-tests the draw,
                   bit 1 = two-sided: drawn with culling off, as SA draws
                   its foliage and flag planes; bits 8..15 = D3DRS_ALPHAREF),
                   float3 lo, float3 hi: the slot's box in carrier space,
                   for culling it as a sun shadow caster
    per texture:   u32 fourcc, width, height, mips, size, the mip chain

The facade material is a final-LOD one; the LOD shader writes texture alpha
times vertex and material alpha to oC0.a (WoS_Deferred LOD_README), so plain
hardware alpha testing cuts SA foliage, flags and fences out.

Anchors: WoS swings from anchor_marker entities (native .pcac points, almost
all 20 m above the street, ~14 m apart). The DLL creates such entities from
the game's own anchor pool at these points. sa_runtime/anchors.bin:

    'SAAN' u32 version=1, u32 count, count x float3 (world)

    py -3 sa_runtime_assets.py SA_district_FoundationCOL
"""
import argparse
import hashlib
import io
import json
import math
from pathlib import Path
import shutil
import struct
import time

from PIL import Image

import build_sa_world as W
import carrier_offset
import col_heightfield_boxes as C
import make_cell_mod as MC
import make_texture_mod as T
import meshpack
import sa_bake
import sa_ipl
import sa_texture_convert
import static_map_mesh
import wos_tex
import wrapmesh

RUNTIME = 'sa_runtime'
DISTRICT = ((1500.0, -1700.0), 150.0)  # build_sa_world's district scope

ANCHOR_STEP = 12.0     # lattice spacing; native nearest neighbour ~14 m
ANCHOR_RISE = 20.0     # native anchors sit 20 m above the street
GROUND_RADIUS = 16.0   # street level = low percentile of the surface nearby
CLEAR_RADIUS = 5.0     # nothing within this may reach the anchor
HEADROOM = 4.0
STREET_SLACK = 3.0     # only above streets and plazas, as native anchors are


def texture_levels(tex):
    """DXT mip chain as bytes, truncated at SA's zero-length tail levels."""
    tex = sa_texture_convert.compressed(tex)
    levels, w, h = [], tex.width, tex.height
    for mip in tex.mips:
        if not mip or len(mip) != wos_tex.level_size(w, h, tex.fourcc):
            break
        levels.append(mip)
        w, h = max(1, w // 2), max(1, h // 2)
    if not levels:
        raise ValueError(f'{tex.name}: no usable mip level')
    return tex.fourcc, tex.width, tex.height, levels


def facade_texture():
    """The stock texture every runtime slot is drawn with, to recognise it."""
    mat = next(Path(T.TEX_DIR).glob(f'0x{W.FALLBACK:08X}.*.wrap.mat'))
    th, _ = MC.material_texture(mat.read_bytes())
    tex = wos_tex.Tex(next(Path(T.TEX_DIR).glob(f'0x{th:08X}.*.wrap.tex')).read_bytes())
    if not tex.compressed:
        raise ValueError('facade texture is not block compressed')
    return tex


def cutout_ref(fourcc, w, h, level0):
    """D3DRS_ALPHAREF for this texture, 0 = draw it opaque.

    Foliage, flags and fences (some texels transparent, some solid) cut at
    128. Decals with no solid texels only lose their fully transparent part
    (ref 1). Uniformly translucent surfaces (the fountain water, alpha < 128
    everywhere) stay opaque rather than vanish under an alpha test.
    """
    if fourcc not in (b'DXT1', b'DXT3', b'DXT5'):
        return 0
    hdr = bytearray(128)
    struct.pack_into('<4sIIIIIII', hdr, 0, b'DDS ', 124, 0x1007 | 0x80000, h, w, len(level0), 0, 1)
    struct.pack_into('<II4s', hdr, 76, 32, 4, fourcc)
    struct.pack_into('<I', hdr, 108, 0x1000)
    hist = Image.open(io.BytesIO(bytes(hdr) + level0)).convert('RGBA').getchannel('A').histogram()
    n = float(w * h)
    low, solid, clear = sum(hist[:128]) / n, sum(hist[128:]) / n, hist[0] / n
    if low >= 0.01 and solid >= 0.05:
        return 128
    if clear >= 0.01:
        return 1
    return 0


def slot_boxes(meshes):
    """Per-slot (lo, hi) in carrier space from each mesh info's centre/half."""
    return [([mi['offset'][k] - mi['bbox'][k] for k in range(3)],
             [mi['offset'][k] + mi['bbox'][k] for k in range(3)]) for mi in meshes]


def textures_bin(slot_keys, primitives, vertices, sources, boxes):
    images, index_of, per_slot, failed = [], {}, [], {}
    for key in slot_keys:
        tex = sources.get(key)
        if tex is None:
            failed.setdefault(key, 'missing_texture')
            per_slot.append(-1)
            continue
        try:
            fourcc, w, h, levels = texture_levels(tex)
        except ValueError as exc:
            failed.setdefault(key, str(exc))
            per_slot.append(-1)
            continue
        blob = b''.join(levels)
        fingerprint = hashlib.sha256(fourcc + struct.pack('<2I', w, h) + blob).digest()
        if fingerprint not in index_of:
            index_of[fingerprint] = len(images)
            images.append((fourcc, w, h, len(levels), blob, cutout_ref(fourcc, w, h, levels[0])))
        per_slot.append(index_of[fingerprint])
    facade = facade_texture()
    level0 = facade.levels()[0]
    out = bytearray(b'SATX' + struct.pack('<3I', 3, len(slot_keys), len(images)))
    out += facade.fourcc + struct.pack('<4I', facade.width, facade.height, facade.mips, len(level0))
    out += level0
    for p, v, t, (lo, hi) in zip(primitives, vertices, per_slot, boxes):
        ref = images[t][5] if t >= 0 else 0
        out += struct.pack('<IIiI', p, v, t, (ref << 8 | 3) if ref else 0)
        out += struct.pack('<6f', *lo, *hi)
    for fourcc, w, h, mips, blob, _ in images:
        out += fourcc + struct.pack('<4I', w, h, mips, len(blob)) + blob
    report = {'textures': len(images), 'slots_textured': sum(t >= 0 for t in per_slot),
              'slots_facade': sum(t < 0 for t in per_slot), 'untextured_sources': failed,
              'cutout_textures': sum(1 for im in images if im[5]),
              'cutout_slots': sum(1 for t in per_slot if t >= 0 and images[t][5]),
              'bytes': len(out), 'match_texture': f'0x{facade.name_hash:08X}'}
    return bytes(out), report


def anchors(heights, area, cell):
    """Points 20 m above streets and plazas with clear air around them."""
    nx, nz = len(heights), len(heights[0])

    def around(ix, iz, radius):
        r = int(math.ceil(radius / cell))
        for a in range(max(0, ix - r), min(nx, ix + r + 1)):
            for b in range(max(0, iz - r), min(nz, iz + r + 1)):
                if (a - ix) ** 2 + (b - iz) ** 2 <= r * r and heights[a][b] is not None:
                    yield heights[a][b]

    points = []
    x = area[0][0] + ANCHOR_STEP / 2
    while x < area[1][0]:
        z = area[0][2] + ANCHOR_STEP / 2
        while z < area[1][2]:
            ix, iz = int((x - area[0][0]) / cell), int((z - area[0][2]) / cell)
            here = heights[ix][iz] if ix < nx and iz < nz else None
            if here is not None:
                nearby = sorted(around(ix, iz, GROUND_RADIUS))
                ground = nearby[len(nearby) // 5]
                y = ground + ANCHOR_RISE
                if here <= ground + STREET_SLACK and max(around(ix, iz, CLEAR_RADIUS)) <= y - HEADROOM:
                    points.append((x, y, z))
            z += ANCHOR_STEP
        x += ANCHOR_STEP
    return points


def district_sources(region=DISTRICT):
    instances, _ = sa_ipl.load_world(W.M.SA_DIR, W.M.IDE_ROOT)
    selected = [i for i in instances if sa_bake.in_area(i, region)]
    return T.texture_sources(selected, W.M.IDE_ROOT, W.M.SA_DIR)


def rebuild_textures(profile, staged_root, installed_root, manifest):
    if 'runtime_textures' not in manifest:
        raise SystemExit(f'{profile} does not use runtime textures yet; run without --textures-only')
    mesh = (staged_root / W.PACK / W.RESOURCE).read_bytes()
    if hashlib.sha256(mesh).hexdigest() != manifest['mesh_sha256']:
        raise SystemExit('staged mesh does not match its manifest')
    meshes = wrapmesh.parse(mesh).meshes
    keys = [row['source'] for row in manifest['slot_sources']]
    tex_bin, report = textures_bin(keys, [mi['index_count'] - 2 for mi in meshes],
                                   [mi['vertex_count'] for mi in meshes],
                                   district_sources(C.manifest_region(manifest)), slot_boxes(meshes))
    manifest['runtime_textures'] = report
    text = json.dumps(manifest, indent=2).encode()
    for root in (staged_root, installed_root):
        if root.exists():
            W.write(root / RUNTIME / 'textures.bin', tex_bin)
            W.write(root / 'manifest.json', text)
    print(json.dumps({k: v for k, v in report.items() if k != 'untextured_sources'}, indent=2))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('profile')
    p.add_argument('--textures-only', action='store_true',
                   help='rebuild sa_runtime/textures.bin of an already converted profile')
    a = p.parse_args()
    staged_root = W.OUT / a.profile
    installed_root = Path(__file__).resolve().parents[2] / 'exWoS' / a.profile
    manifest = json.loads((staged_root / 'manifest.json').read_text())
    if a.textures_only:
        rebuild_textures(a.profile, staged_root, installed_root, manifest)
        return
    if 'runtime_textures' in manifest:
        raise SystemExit(f'{a.profile} already uses runtime textures')
    if 'carrier_translation' not in manifest:
        raise SystemExit('run carrier_offset.py first')
    mesh_path = staged_root / W.PACK / W.RESOURCE
    before = mesh_path.read_bytes()
    if hashlib.sha256(before).hexdigest() != manifest['mesh_sha256']:
        raise SystemExit('staged mesh does not match its manifest')
    old = wrapmesh.parse(before)
    slots = carrier_offset.slots_of(old)
    keys = [row['source'] for row in manifest['slot_sources']]
    if len(keys) != len(slots):
        raise SystemExit('slot_sources does not line up with the mesh slots')

    # every slot on the stock facade material; strips padded to unique counts
    points = [r[carrier_offset.POSITION] for records, _, _ in slots for r in records]
    bounds = ([min(q[k] for q in points) - .01 for k in range(3)],
              [max(q[k] for q in points) + .01 for k in range(3)])
    after, _ = static_map_mesh.build(Path(W.M.OCEAN).read_bytes(),
                                     ((v, t, W.FALLBACK) for v, t, _ in slots),
                                     bounds, unique_primitives=True)
    new = static_map_mesh.validate(after)
    primitives = [mi['index_count'] - 2 for mi in new.meshes]
    vertices = [mi['vertex_count'] for mi in new.meshes]
    assert len(set(primitives)) == len(primitives), 'primitive counts not unique'
    for i, ((va, ta, _), (vb, tb, mb)) in enumerate(zip(slots, carrier_offset.slots_of(new))):
        assert ta == tb and len(va) == len(vb) and mb == W.FALLBACK, f'slot {i} changed'
        worst = max(abs(ra[carrier_offset.POSITION][k] - rb[carrier_offset.POSITION][k])
                    for ra, rb in zip(va, vb) for k in range(3))
        assert worst < .02, f'slot {i} moved {worst} m'

    region = C.manifest_region(manifest)
    tex_bin, tex_report = textures_bin(keys, primitives, vertices, district_sources(region),
                                       slot_boxes(new.meshes))

    shift = tuple(manifest['world_shift'])
    area = manifest['model_bounds']
    cell = 2.0
    heights, _, _ = C.heightfield(C.district_triangles(shift, region=region), area, cell)
    anchor_points = anchors(heights, area, cell)
    anchor_bin = b'SAAN' + struct.pack('<2I', 1, len(anchor_points)) + b''.join(
        struct.pack('<3f', *q) for q in anchor_points)

    stamp = time.strftime('%Y%m%d_%H%M%S')
    backup = W.OUT / 'profile_backups' / f'{a.profile}_before_runtime_textures_{stamp}'
    for label, root in (('staged', staged_root), ('installed', installed_root)):
        pack = root / W.PACK
        if pack.exists():
            shutil.copytree(pack, backup / label / W.PACK)
            for f in pack.iterdir():
                if f.name != W.RESOURCE:
                    f.unlink()  # the NYC texture/material overrides
        if (root / 'manifest.json').exists():
            shutil.copy2(root / 'manifest.json', backup / label / 'manifest.json')

    manifest.update(mesh_sha256=hashlib.sha256(after).hexdigest(), bytes=len(after),
                    texture_bindings=[], runtime_textures=tex_report,
                    anchors={'count': len(anchor_points), 'rise_m': ANCHOR_RISE,
                             'step_m': ANCHOR_STEP},
                    slot_primitives=primitives)
    text = json.dumps(manifest, indent=2).encode()
    for root in (staged_root, installed_root):
        if not root.exists():
            continue
        W.write(root / W.PACK / W.RESOURCE, after)
        W.write(root / RUNTIME / 'textures.bin', tex_bin)
        W.write(root / RUNTIME / 'anchors.bin', anchor_bin)
        W.write(root / 'manifest.json', text)
    print(json.dumps({'profile': a.profile, 'backup': str(backup), 'anchors': len(anchor_points),
                      **{k: v for k, v in tex_report.items() if k != 'untextured_sources'},
                      'untextured_sources': len(tex_report['untextured_sources'])}, indent=2))


if __name__ == '__main__':
    main()
