"""Convert supported SA raw BGRA rasters to BC3; leave native BC data intact."""
import copy
import io
from PIL import Image


def compressed(tex):
    if tex.fourcc in (b'DXT1', b'DXT3', b'DXT5'):
        return tex
    if tex.palette is not None or tex.depth != 32 or tex.d3d_format not in (21, 22):
        raise ValueError(f'unsupported raw texture: {tex.name}, format {tex.d3d_format}')
    result = copy.copy(tex)
    result.d3d_format = int.from_bytes(b'DXT5', 'little')
    result.mips = []
    w, h = tex.width, tex.height
    for raw in tex.mips:
        if len(raw) != w*h*4:
            break
        img = Image.frombytes('RGBA', (w,h), raw, 'raw', 'BGRA')
        if tex.d3d_format == 22:
            img.putalpha(255)
        stream = io.BytesIO()
        img.save(stream, format='DDS', pixel_format='DXT5')
        dds = stream.getvalue()
        if dds[:4] != b'DDS ' or dds[84:88] != b'DXT5':
            raise ValueError('unexpected DDS encoder output')
        result.mips.append(dds[128:])
        w,h = max(1,w//2),max(1,h//2)
    if not result.mips:
        raise ValueError('no complete raw mip')
    return result
