"""
RenderWare TXD reader: San Andreas texture dictionaries, down to the pixels.

Same chunk tree as the DFF side, so this leans on `sa_dff.Chunk`:

    TextureDictionary (0x16)
      Struct (0x01)         -> texture count
      TextureNative (0x15)  -> one per texture
        Struct (0x01)       -> the header below, then palette, then mip data
      Extension (0x03)

A TextureNative's Struct, for the D3D9 platform San Andreas ships:

    u32   platform id (9 = D3D9, 8 = D3D8)
    u32   filter flags
    char  name[32], maskName[32]      -- NUL padded
    u32   raster format
    u32   d3d format, as a fourcc ("DXT1") or a D3DFMT number when uncompressed
    u16   width, height
    u8    depth, mip count, raster type, compression flags
    then, when the raster is palettised, the palette; then per mip:
    u32   size, followed by that many bytes

Why it matters that WoS stores DXT1 and DXT5: so does San Andreas, so most of
the city's textures can be moved across without ever being decoded. The ones
that cannot are the palettised and plain-BGRA rasters, which is why this keeps
the raw bytes and the format rather than handing back images.
"""

import os
import struct

import sa_dff

TEXTURE_DICTIONARY = 0x16
TEXTURE_NATIVE = 0x15

PLATFORM_D3D8 = 8
PLATFORM_D3D9 = 9

# compression flags in the last header byte
COMP_DXT1 = 1
COMP_DXT3 = 3

# raster format bits
FORMAT_MASK = 0x0F00
FORMAT_EXT_AUTO_MIPMAP = 0x1000
FORMAT_EXT_PAL8 = 0x2000
FORMAT_EXT_PAL4 = 0x4000
FORMAT_EXT_MIPMAP = 0x8000

# the raster formats that carry their own palette
PALETTE_SIZES = {FORMAT_EXT_PAL8: 256, FORMAT_EXT_PAL4: 32}


class Texture:
    """One texture: its name, size, pixel format and mip chain as raw bytes."""

    def __init__(self):
        self.name = ""
        self.mask_name = ""
        self.platform = 0
        self.width = 0
        self.height = 0
        self.depth = 0
        self.mips = []          # list of bytes, largest first
        self.raster_format = 0
        self.d3d_format = 0
        self.compression = 0
        self.palette = None

    @property
    def fourcc(self):
        """b"DXT1"/b"DXT5" when block compressed, else None."""
        raw = struct.pack("<I", self.d3d_format)
        return raw if raw[:3] == b"DXT" else None

    @property
    def has_alpha(self):
        return self.fourcc in (b"DXT3", b"DXT5") or bool(
            self.raster_format & 0x0100)

    def __repr__(self):
        f = self.fourcc.decode() if self.fourcc else f"fmt{self.d3d_format}"
        return (f"<Texture {self.name!r} {self.width}x{self.height} {f} "
                f"{len(self.mips)} mips>")


def _cstr(data, offset, length):
    raw = data[offset:offset + length]
    return raw.split(b"\x00", 1)[0].decode("latin-1")


def _read_native(chunk):
    """Parse one TextureNative chunk; -> Texture, or None if unsupported."""
    body = None
    for c in chunk.children():
        if c.type == sa_dff.STRUCT:
            body = c
            break
    if body is None:
        return None

    d = chunk.data
    o = body.body_start
    t = Texture()
    t.platform, filter_flags = struct.unpack_from("<2I", d, o)
    o += 8
    if t.platform not in (PLATFORM_D3D8, PLATFORM_D3D9):
        return None            # console dictionaries use a different layout
    t.name = _cstr(d, o, 32)
    t.mask_name = _cstr(d, o + 32, 32)
    o += 64
    (t.raster_format, t.d3d_format, t.width, t.height, t.depth,
     mip_count, raster_type, t.compression) = struct.unpack_from(
        "<2I2H4B", d, o)
    o += 16

    # a palettised raster stores its table before the mip chain, and the table
    # is sized by the raster format rather than by the bit depth
    for bit, entries in PALETTE_SIZES.items():
        if t.raster_format & bit:
            t.palette = d[o:o + entries * 4]
            o += entries * 4
            break

    for _ in range(mip_count):
        if o + 4 > body.body_end:
            break
        size, = struct.unpack_from("<I", d, o)
        o += 4
        if o + size > body.body_end:
            break                       # truncated dictionary: keep what we
        t.mips.append(d[o:o + size])    # have rather than throwing the lot
        o += size
    return t if t.mips else None


def read(path_or_bytes):
    """-> [Texture] for a .txd."""
    if isinstance(path_or_bytes, (str, os.PathLike)):
        data = open(path_or_bytes, "rb").read()
    else:
        data = path_or_bytes
    out = []
    root = sa_dff.Chunk(data, 0)
    if root.type != TEXTURE_DICTIONARY:
        return out
    for c in root.children():
        if c.type == TEXTURE_NATIVE:
            t = _read_native(c)
            if t is not None:
                out.append(t)
    return out


def by_name(path_or_bytes):
    """-> {lowercased texture name: Texture}."""
    return {t.name.lower(): t for t in read(path_or_bytes)}


def expected_size(width, height, fourcc, depth=32):
    """Bytes one mip level should occupy, for checking a dictionary."""
    if fourcc in (b"DXT1",):
        return max(1, (width + 3) // 4) * max(1, (height + 3) // 4) * 8
    if fourcc in (b"DXT3", b"DXT5"):
        return max(1, (width + 3) // 4) * max(1, (height + 3) // 4) * 16
    return width * height * depth // 8
