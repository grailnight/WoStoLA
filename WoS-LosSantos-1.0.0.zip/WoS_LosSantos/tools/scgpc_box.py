"""Native WoS type-4 box authoring; scene insertion/index rebuilding is separate.

Decoded from FUN_00773ED0 and the aabb_leaf_node_methods dispatch table.
Preserve opaque metadata from a native 48-byte template. Never treat a box
record as a complete SCGPC or insert it without updating spatial references.
"""
import math
import struct

SCALE = struct.unpack('<f', struct.pack('<f', 0.0010681315))[0]


def decode(record):
    if len(record) != 48 or record[0] & 0x7f != 4:
        raise ValueError('expected a 48-byte native type-4 box')
    center = struct.unpack_from('<3f', record, 0x14)
    half = tuple(x * SCALE for x in struct.unpack_from('<3H', record, 0x2a))
    return center, half


def create(template, center, half):
    decode(template)
    if len(center) != 3 or len(half) != 3:
        raise ValueError('expected three coordinates and three half extents')
    if not all(math.isfinite(x) for x in (*center, *half)):
        raise ValueError('non-finite box')
    encoded = tuple(math.ceil(x / SCALE) for x in half)
    if not all(x > 0 for x in half) or not all(1 <= x <= 65535 for x in encoded):
        raise ValueError('box half extents must be positive and at most about 70m')
    result = bytearray(template)
    struct.pack_into('<3f', result, 0x14, *center)
    struct.pack_into('<3H', result, 0x2a, *encoded)
    return bytes(result)


if __name__ == '__main__':
    from pathlib import Path
    source = Path(__file__).resolve().parents[1] / 'out/full_map/collision_research/L23/type_74_0001D211.bin'
    native = source.read_bytes()[0x80:0xb0]
    center, half = decode(native)
    assert center[0] == -216 and center[2] == 1512
    assert struct.unpack_from('<3H', native, 0x2a) == (290, 171, 703)
    box = create(native, (640.57, 0, 1809.44), (10, 1, 10))
    got_center, got_half = decode(box)
    assert all(want <= got < want + SCALE for want, got in zip((10, 1, 10), got_half))
    assert all(a == b for i, (a, b) in enumerate(zip(native, box))
               if not 0x14 <= i < 0x20 and not 0x2a <= i < 0x30)
    for invalid in ((0, 1, 1), (-1, 1, 1), (71, 1, 1), (float('nan'), 1, 1)):
        try:
            create(native, center, invalid)
        except ValueError:
            pass
        else:
            raise AssertionError('invalid extent accepted')
    print('Native box decode, metadata preservation, quantization and invalid extents: PASS')
    print('Scene registration and in-game support: NOT VERIFIED; no profile changed')
