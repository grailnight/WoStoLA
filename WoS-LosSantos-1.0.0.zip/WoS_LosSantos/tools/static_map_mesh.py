"""Author any number of static mesh slots in an existing WRAP resource.

Restricted to the proven two-component, unskinned, no-global-export layout.
The carrier identity stays unchanged. Slot count is no longer inherited from
the carrier. All internal and external relocation records are regenerated.
Runtime acceptance of increased slot counts must be tested separately.
"""
import math
import struct
import meshpack
import wrapmesh


def align(buf, n=16):
    buf.extend(b'\xa1' * (-len(buf) % n))


def put_u32(buf, off, value):
    struct.pack_into('<I', buf, off, value & 0xffffffff)


def build(template, slots, model_bounds, unique_primitives=False):
    """slots yields (world-space records, triangles, existing material hash).

    Encode each yielded slot before requesting another, allowing a map builder
    to bake one spatial cell at a time without keeping the entire map in RAM.
    unique_primitives pads strips with degenerate triangles until every slot
    draws a different primitive count, so a draw hook can tell slots apart.
    Returns (WRAP bytes, per-slot statistics).
    """
    m = wrapmesh.parse(template)
    if m.component_count != 2 or m.global_count or m.model['ext_mesh_count']:
        raise ValueError('only standalone two-component static templates supported')
    if any(t not in (b'NAME', b'MAT\0') for t, _, _, _ in m.ext_patches):
        raise ValueError('template has unsupported external dependencies')
    mi = m.meshes[0]
    if mi['bone_palette_count'] or mi['bone_palette'].raw or m.model['skeleton'].raw:
        raise ValueError('skinned templates are not supported')
    if mi['index_size'] != 2:
        raise ValueError('expected 16-bit indices')
    regions = {r.name:r for r in m.regions}
    def original(name):
        r = regions[name]
        return template[r.start:r.end]
    centre, half = meshpack.center_and_extent(*model_bounds)
    new_model = {'offset': centre + [math.sqrt(sum(x*x for x in half))],
                 'bbox': half + [0.0]}
    pt = meshpack.position_type(mi)
    if pt not in meshpack.QUANTIZED_TYPES | meshpack.WORLD_TYPES:
        raise ValueError('unsupported vertex position encoding')
    phys = bytearray()
    encoded = []
    stats = []
    primitives_used = set()
    for records, triangles, material_hash in slots:
        if not records or not triangles or len(records) > 65535:
            raise ValueError('each slot requires 1..65535 vertices and nonempty triangles')
        if any(len(t) != 3 or min(t) < 0 or max(t) >= len(records)
               or len(set(t)) != 3 for t in triangles):
            raise ValueError('invalid or degenerate index triangle')
        positions = [r[meshpack.POSITION, 0][:3] for r in records]
        if any(not math.isfinite(x) for p in positions for x in p):
            raise ValueError('non-finite position')
        lo = [min(p[k] for p in positions) for k in range(3)]
        hi = [max(p[k] for p in positions) for k in range(3)]
        if any(lo[k] < model_bounds[0][k]-1e-5 or hi[k] > model_bounds[1][k]+1e-5
               for k in range(3)):
            raise ValueError('geometry exceeds declared map bounds')
        packed = [dict(r) for r in records]
        if pt in meshpack.QUANTIZED_TYPES:
            for r in packed:
                r[meshpack.POSITION, 0] = meshpack.normalize_position(
                    r[meshpack.POSITION, 0], new_model)
        align(phys, 4)
        vb = len(phys)
        phys.extend(meshpack.encode_vertices(mi, packed))
        align(phys, 4)
        ib = len(phys)
        strip = meshpack.triangles_to_strip(triangles)
        if unique_primitives:
            # repeating the last index only adds zero-area triangles
            while len(strip) - 2 in primitives_used:
                strip.append(strip[-1])
            primitives_used.add(len(strip) - 2)
        if [tuple(t) for t in meshpack.strip_to_triangles(strip)] != [tuple(t) for t in triangles]:
            raise AssertionError('triangle strip did not preserve winding/order')
        phys.extend(struct.pack('<%dH' % len(strip), *strip))
        mc, mh = meshpack.center_and_extent(lo, hi)
        encoded.append((material_hash, vb, ib, len(records), len(strip), mc, mh))
        stats.append({'vertices':len(records), 'triangles':len(triangles),
                      'material':f'0x{material_hash:08X}', 'lo':lo, 'hi':hi})
    n = len(encoded)
    if not n:
        raise ValueError('map has no mesh slots')

    # WRAP head, patch table, external records, internal relocations, IMG.
    out = bytearray(template[:48])
    out.extend(b'\xa1' * 32)
    ext = len(out)
    out.extend(b'\0' * (16 * (n + 1)))
    internal = len(out)
    out.extend(b'\0' * (4 * (1 + 5*n)))
    global_target = len(out)  # no global exports, same convention as template
    align(out)
    img = len(out)
    out.extend(original('model_header'))
    # Preserve opaque bytes between the header and the mesh table.
    out.extend(template[m.img.target+64:m.model['mesh_table'].target])
    table = len(out)
    out.extend(b'\0' * (8*n))
    relocs = []
    phys_ptrs = []
    material_fields = []
    def ptr(pos, target):
        put_u32(out, pos, target-pos)
        relocs.append(pos)
    ptr(img+16, table)
    put_u32(out, img+12, n)
    struct.pack_into('<8f', out, img+32, *(new_model['offset']+new_model['bbox']))
    for i, (mh, vb, ib, vc, ic, mc, half_box) in enumerate(encoded):
        align(out)
        info = len(out)
        out.extend(original('mesh0_info'))
        struct.pack_into('<8f', out, info,
                         *(mc+[math.sqrt(sum(x*x for x in half_box))]+half_box+[0.0]))
        ptr(table+8*i+4, info)
        material_fields.append(info+32)
        put_u32(out, info+52, vc)
        put_u32(out, info+68, ic)
        phys_ptrs.extend([(info+44, vb), (info+60, ib)])
        schema = regions['mesh0_schema_table']
        out.extend(template[schema.start-8:schema.start])
        st = len(out)
        out.extend(original('mesh0_schema_table'))
        decl = len(out)
        out.extend(original('mesh0_vertex_decl'))
        ptr(info+76, st)
        ptr(st+4, decl)
    img_size = len(out)-img
    # PHYS marker is outside both components, immediately before PHYS data.
    out.extend(b'\xa1' * (-(len(out)+4) % 16))
    out.extend(b'PHYS')
    phys_start = len(out)
    for pos, target in phys_ptrs:
        ptr(pos, phys_start+target)
    out.extend(phys)
    if len(relocs) != 1+5*n:
        raise AssertionError('wrong internal relocation count')
    put_u32(out, 8, 48-8)
    put_u32(out, 12, 2)
    put_u32(out, 16, 4)
    put_u32(out, 20, img_size)
    put_u32(out, 24, img-24)
    put_u32(out, 28, len(phys))
    put_u32(out, 32, phys_start-32)
    struct.pack_into('<6I',out,48,n+1,ext-52,len(relocs),internal-60,0,global_target-68)
    name = next((t,h,idx) for t,h,idx,_ in m.ext_patches if t==b'NAME')
    for i,(tag,h,idx,target) in enumerate(
            [(*name,img)] + [(b'MAT\0',row[0],0xffffffff,p)
                            for row,p in zip(encoded,material_fields)]):
        pos=ext+16*i
        struct.pack_into('<4sIII',out,pos,tag,h,idx,target-(pos+12))
    for i,pos in enumerate(sorted(relocs)):
        at=internal+4*i
        put_u32(out,at,pos-at)
    result=bytes(out)
    validate(result)
    return result,stats


def validate(data):
    """Structural check independent of build's saved relocation list."""
    m=wrapmesh.parse(data)
    expected={m.model['mesh_table'].pos}
    for mi in m.meshes:
        for key in ('info_ptr','vertex_buffer','index_buffer','schema_table','vertex_schema'):
            expected.add(mi[key].pos)
            p=mi[key]
            if not 0 <= p.target < len(data):
                raise ValueError('pointer outside resource')
    if len(m.reloc_positions()) != len(expected) or set(m.reloc_positions()) != expected:
        raise ValueError('internal relocation table mismatch')
    ext_targets=[p.target for _,_,_,p in m.ext_patches]
    if set(ext_targets) != {m.img.target} | {mi['material'].pos for mi in m.meshes}:
        raise ValueError('external relocation table mismatch')
    for r in m.regions:
        if r.start < 0 or r.end > len(data):
            raise ValueError('region outside resource: '+r.name)
    return m
