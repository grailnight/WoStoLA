"""Decode a profile's sa_runtime/world.bin exactly as SA_CollisionLoader will,
and check it: every index stays inside its batch, every decoded vertex inside
its batch and tile boxes, normals face outward (WoS: -cross(b-a, c-a)), the
trigger matches the carrier mesh, and images exist for every batch.

    py -3 test_sa_tiles.py SA_tiles_test [--png top.png]
"""
import argparse
import json
import struct
import sys
from pathlib import Path

import numpy as np

import build_sa_tiles as B
import build_sa_world as W
import meshpack
import wrapmesh


def read(path):
    d = Path(path).read_bytes()
    magic, version, nt, nb, tprims, tverts, stride, _ = B.HEADER.unpack_from(d, 0)
    assert magic == b'SAWD' and version == B.VERSION, (magic, version)
    at = B.HEADER.size
    tiles = [B.TILE_REC.unpack_from(d, at + i * B.TILE_REC.size) for i in range(nt)]
    at += nt * B.TILE_REC.size
    batches = [B.BATCH_REC.unpack_from(d, at + i * B.BATCH_REC.size) for i in range(nb)]
    return d, (tprims, tverts, stride), tiles, batches


def decode_tile(d, t, stride):
    scale, bias = np.array(t[6:9]), np.array(t[10:13])
    n = t[15]
    raw = np.frombuffer(d, np.uint8, n * stride, t[14]).reshape(n, stride)
    pos = raw[:, 4:12].copy().view('<i2').astype(np.float64)[:, :3] / 32767.0
    pos = np.clip(pos, -1, 1) * scale + bias
    nrm = raw[:, 12:20].copy().view('<f2').astype(np.float64)[:, :3]
    idx = np.frombuffer(d, '<u2', t[17], t[16])
    return pos, nrm, idx


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('profile')
    p.add_argument('--png')
    a = p.parse_args()
    root = W.OUT / a.profile
    manifest = json.loads((root / 'manifest.json').read_text())
    d, (tprims, tverts, stride), tiles, batches = read(root / 'sa_runtime/world.bin')
    carrier = wrapmesh.parse((root / W.PACK / W.RESOURCE).read_bytes())
    mi = carrier.meshes[0]
    assert len(carrier.meshes) == 1 and (mi['index_count'] - 2, mi['vertex_count']) == (tprims, tverts), 'trigger'
    assert stride == mi['vertex_stride'] == 24
    tex = (root / 'sa_runtime/textures.bin').read_bytes()
    images = struct.unpack_from('<I', tex, 12)[0]
    against = along = 0
    tris_total = 0
    top = []
    for ti, t in enumerate(tiles):
        pos, nrm, idx = decode_tile(d, t, stride)
        lo, hi = np.array(t[0:3]), np.array(t[3:6])
        assert (pos >= lo - 0.02).all() and (pos <= hi + 0.02).all(), f'tile {ti} vertex outside its box'
        for bi in range(t[18], t[18] + t[19]):
            b = batches[bi]
            assert b[0] == ti and -1 <= b[1] < images
            base, nv, start, prims = b[3:7]
            local = idx[start:start + 3 * prims].astype(np.int64)
            assert len(local) == 3 * prims and local.max() < nv, f'batch {bi} index outside'
            vi = local + base
            assert vi.max() < t[15]
            bp = pos[base:base + nv]
            assert (bp >= np.array(b[7:10]) - 0.02).all() and (bp <= np.array(b[10:13]) + 0.02).all(), f'batch {bi} box'
            tri = pos[vi].reshape(-1, 3, 3)
            g = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
            n = nrm[vi].reshape(-1, 3, 3).sum(1)
            dot = (g * n).sum(1) / (np.linalg.norm(g, axis=1) * np.linalg.norm(n, axis=1) + 1e-12)
            against += int((dot < -.5).sum()); along += int((dot > .5).sum())
            tris_total += prims
            if a.png:
                top.append(tri)
    assert tris_total == manifest['world']['triangles']
    assert against > 20 * max(along, 1), f'normals: against {against}, along {along}'
    print(json.dumps({'tiles': len(tiles), 'batches': len(batches), 'triangles': tris_total,
                      'normals_against_cross': against, 'normals_along_cross': along, 'images': images}))
    if a.png:
        from PIL import Image, ImageDraw
        allt = np.concatenate(top)
        lo, hi = allt.reshape(-1, 3).min(0), allt.reshape(-1, 3).max(0)
        s = 1024 / max(hi[0] - lo[0], hi[2] - lo[2])
        im = Image.new('L', (1024, 1024), 0); dr = ImageDraw.Draw(im)
        for t3 in allt[:: max(1, len(allt) // 200000)]:
            shade = int(min(255, 40 + (t3[:, 1].max() - lo[1]) * 2))
            dr.polygon([((q[0] - lo[0]) * s, (q[2] - lo[2]) * s) for q in t3], fill=shade)
        im.save(a.png)
    print('PASS')


if __name__ == '__main__':
    main()
