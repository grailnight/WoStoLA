"""
Pull single resources out of the game's PCPACK archives, standard library only.

The public Los Santos installer cannot ship python-lzo or the WebOfShadowsTools
unpacker, and it needs only a handful of files, so this module reads just the
blocks under the requested ranges.

PCPACK (see also wospack.py):
  * a run of "NCH\\0" blocks, one every 0x80000 bytes of the file. Header:
    magic, compressed size, ?, decompressed size, 0, ?, compressed end, flag;
    the LZO1X payload ends at "compressed end" inside the block.
  * blocks decompress independently; their outputs concatenated are the image.
  * image u32[14] = file count; the table starts at 0x408 after one u32 per
    file; an entry is 11 u32 (19 when [8] != 0): name hash, type, offset, size.

APKF (pack entry type 25) holds the meshes, materials and textures that exWoS
overrides as standalone WRAP files. Every pointer in both formats is relative
to the field that holds it. APKF:
  * header: magic, version, 2 flags, component count, component table pointer
    (field +20), file table at +28;
  * component header (24 bytes): 4CC, 3 u32, data size, data pointer (field +20);
  * file table: per type, 5 u32 (4CC, ?, active components, pointer to the file
    headers (field +12), file count) and one alignment u32 per component; ends
    with a zero u32. A file header is (name pointer from the header, name hash,
    one size per active component). Each file's components are carved, in
    table order, from the running cursor of their component's data region.
  * after the last component's data (4-aligned): the relocation list, u32
    (component << 26 | slot) until 0xFFFFFFFF; the slot holds the reference
    encoded the same way (component 63 = the name table after the file
    headers). Then the global list, 16-byte entries (relocation, 4CC, name
    offset, name hash) until 0xFFFFFFFF.

wrap_file() lays a file out the way exWoS reads an override: the WRAP header,
the component table, the patch table (external, internal and global lists,
each 16-aligned, 0xA1 padding), then IMG and, for two components, "PHYS" and
the PHYS bytes. A reference into the file itself becomes an internal entry and
the slot is rewritten relative to itself; any other reference becomes an
external entry naming the target file's 4CC and hash.

Checked against the WebOfShadowsTools extraction (test_wos_extract.py).
"""

import bisect
import struct
from pathlib import Path

BLOCK_SIZE = 0x80000
TABLE_OFFSET = 0x408
ENDIAN_MARKER = 0x12345678
NAME_COMPONENT = 63
PAD = b"\xA1"


class LzoError(ValueError):
    pass


def lzo1x_decompress(src, dst_len):
    """LZO1X decompression (the format of lzo1x_decompress_safe)."""
    out = bytearray()
    ip = 0
    state = 0
    t = src[0]
    if t > 17:
        t -= 17
        ip = 1
        out += src[ip:ip + t]
        ip += t
        state = 4 if t >= 4 else t
    while True:
        t = src[ip]
        ip += 1
        if t < 16:
            if state == 0:
                # literal run
                if t == 0:
                    while src[ip] == 0:
                        t += 255
                        ip += 1
                    t += 15 + src[ip]
                    ip += 1
                t += 3
                out += src[ip:ip + t]
                ip += t
                state = 4
                continue
            nxt = t & 3
            if state != 4:
                m = len(out) - 1 - (t >> 2) - (src[ip] << 2)
                length = 2
            else:
                m = len(out) - 1 - 0x800 - (t >> 2) - (src[ip] << 2)
                length = 3
            ip += 1
        elif t >= 64:
            nxt = t & 3
            m = len(out) - 1 - ((t >> 2) & 7) - (src[ip] << 3)
            ip += 1
            length = (t >> 5) + 1
        elif t >= 32:
            length = t & 31
            if length == 0:
                while src[ip] == 0:
                    length += 255
                    ip += 1
                length += 31 + src[ip]
                ip += 1
            length += 2
            v = src[ip] | (src[ip + 1] << 8)
            ip += 2
            m = len(out) - 1 - (v >> 2)
            nxt = v & 3
        else:
            length = t & 7
            if length == 0:
                while src[ip] == 0:
                    length += 255
                    ip += 1
                length += 7 + src[ip]
                ip += 1
            length += 2
            v = src[ip] | (src[ip + 1] << 8)
            ip += 2
            dist = ((t & 8) << 11) + (v >> 2)
            if dist == 0:
                break
            m = len(out) - dist - 0x4000
            nxt = v & 3
        if m < 0:
            raise LzoError(f"match before the start of the output at input 0x{ip:X}")
        d = len(out) - m
        if d >= length:
            out += out[m:m + length]
        else:
            run = out[m:]
            out += (run * (length // d + 1))[:length]
        if nxt:
            out += src[ip:ip + nxt]
            ip += nxt
        state = nxt
    if len(out) != dst_len:
        raise LzoError(f"decompressed {len(out)} bytes, header says {dst_len}")
    return bytes(out)


class PackEntry:
    __slots__ = ("index", "name_hash", "type_id", "offset", "size")

    def __init__(self, index, fields):
        self.index = index
        self.name_hash, self.type_id, self.offset, self.size = fields[:4]

    def __repr__(self):
        return (f"F{self.index + 1:03} 0x{self.name_hash:08X} type {self.type_id} "
                f"@0x{self.offset:X}+{self.size}")


class Pack:
    """A PCPACK whose blocks are decompressed on first use."""

    def __init__(self, path):
        self.path = Path(path)
        raw = self.path.read_bytes()
        self.raw = raw
        self.blocks = []  # (image start, size, payload start, payload size, flag)
        pos = image = 0
        while pos + 32 <= len(raw) and raw[pos:pos + 4] == b"NCH\x00":
            _, csize, _, dsize, _, _, cend, flag = struct.unpack_from("<4s7I", raw, pos)
            self.blocks.append((image, dsize, pos + cend - csize, csize, flag))
            image += dsize
            pos += BLOCK_SIZE
        if not self.blocks:
            raise ValueError(f"{self.path.name}: no NCH block at the start")
        self.size = image
        self.starts = [b[0] for b in self.blocks]
        self.cache = {}
        head = struct.unpack_from("<16I", self.read(0, 64))
        if head[8] != ENDIAN_MARKER:
            raise ValueError(f"{self.path.name}: endianness marker 0x{head[8]:08X}")
        self.file_count = head[14]
        self.entries = []
        off = TABLE_OFFSET + 4 * self.file_count
        for i in range(self.file_count):
            f = struct.unpack("<11I", self.read(off, 44))
            self.entries.append(PackEntry(i, f))
            off += 44 + (32 if f[8] else 0)

    def block(self, i):
        data = self.cache.get(i)
        if data is None:
            start, dsize, p, csize, flag = self.blocks[i]
            payload = self.raw[p:p + csize]
            data = payload if (flag == 0 or csize == dsize) else lzo1x_decompress(payload, dsize)
            self.cache[i] = data
        return data

    def read(self, off, n):
        if off < 0 or off + n > self.size:
            raise ValueError(f"{self.path.name}: read 0x{off:X}+{n} outside the image")
        out = bytearray()
        i = bisect.bisect_right(self.starts, off) - 1
        while n > 0:
            start = self.blocks[i][0]
            data = self.block(i)
            take = min(n, len(data) - (off - start))
            out += data[off - start:off - start + take]
            off += take
            n -= take
            i += 1
        return bytes(out)

    def find(self, name_hash, type_id):
        for e in self.entries:
            if e.name_hash == name_hash and e.type_id == type_id:
                return e
        raise KeyError(f"{self.path.name}: no entry 0x{name_hash:08X} of type {type_id}")

    def data(self, entry):
        return self.read(entry.offset, entry.size)


class ApkFile:
    __slots__ = ("type", "name", "name_hash", "parts")

    def __init__(self, type_, name, name_hash, parts):
        self.type = type_
        self.name = name
        self.name_hash = name_hash
        self.parts = parts  # [(start, end)] per active component, apk offsets

    @property
    def out_name(self):
        return f"0x{self.name_hash:08X}.{self.name}.wrap.{self.type.lower()}"


class Apk:
    """APKF archive read through a pack entry, so only touched blocks expand."""

    def __init__(self, pack, entry):
        self.pack = pack
        self.entry = entry
        self.hash = entry.name_hash
        magic, _, _, _, ncomp, comp_ptr, _ = struct.unpack("<4s6I", self.rd(0, 28))
        if magic != b"APKF":
            raise ValueError(f"entry 0x{entry.name_hash:08X} is not APKF ({magic!r})")
        self.comp_table = 20 + comp_ptr
        self.base, self.comp_size = [], []
        for i in range(ncomp):
            h = self.comp_table + 24 * i
            size, data_ptr = struct.unpack("<2I", self.rd(h + 16, 8))
            self.base.append(h + 20 + data_ptr)
            self.comp_size.append(size)
        self.files = []
        cursor = [0] * ncomp
        off = 28
        names_at = None
        while self.u32(off) != 0:
            type_id, _, active, fh_ptr, count = struct.unpack("<5I", self.rd(off, 20))
            type_ = type_id.to_bytes(4, "little").decode("utf-8").replace("\x00", "")
            fh = off + 12 + fh_ptr
            aligns = struct.unpack(f"<{ncomp}I", self.rd(off + 20, 4 * ncomp))
            off += 20 + 4 * ncomp
            for _ in range(count):
                name_ptr, name_hash = struct.unpack("<2I", self.rd(fh, 8))
                sizes = struct.unpack(f"<{active}I", self.rd(fh + 8, 4 * active))
                parts = []
                for i, size in enumerate(sizes):
                    align = aligns[i] & 0xFFFFFF
                    pos = ((cursor[i] - 1) + align) & ~(align - 1)
                    start = self.base[i] + pos
                    parts.append((start, start + size))
                    cursor[i] = pos + size
                self.files.append(ApkFile(type_, self.cstring(fh + name_ptr), name_hash, parts))
                fh += 8 + 4 * active
            names_at = fh
        self.names_at = names_at
        spans = sorted(((s, e, f) for f in self.files for (s, e) in f.parts),
                       key=lambda t: t[0])
        self.spans = spans
        self.span_starts = [s[0] for s in spans]
        self._relocs = None

    # --- raw access -----------------------------------------------------
    def rd(self, off, n):
        if off < 0 or off + n > self.entry.size:
            raise ValueError(f"apk read 0x{off:X}+{n} outside 0x{self.entry.size:X}")
        return self.pack.read(self.entry.offset + off, n)

    def u32(self, off):
        return struct.unpack("<I", self.rd(off, 4))[0]

    def cstring(self, off):
        out = bytearray()
        while True:
            chunk = self.rd(off, min(64, self.entry.size - off))
            if not chunk:
                raise ValueError(f"unterminated file name at 0x{off:X} (damaged pack?)")
            z = chunk.find(b"\x00")
            if z >= 0:
                out += chunk[:z]
                return out.decode("utf-8")
            out += chunk
            off += len(chunk)
            if len(out) > 256:
                raise ValueError("file name longer than 256 bytes")

    # --- lookups --------------------------------------------------------
    def file_at(self, address):
        i = bisect.bisect_right(self.span_starts, address) - 1
        if i >= 0:
            s, e, f = self.spans[i]
            if s <= address < e:
                return f
        return None

    def find(self, type_, name_hash):
        for f in self.files:
            if f.type == type_ and f.name_hash == name_hash:
                return f
        raise KeyError(f"no {type_} 0x{name_hash:08X} in apk 0x{self.hash:08X}")

    def slot(self, encoded):
        comp, index = encoded >> 26, encoded & 0x3FFFFFF
        return self.base[comp] + 4 * index

    def relocations(self):
        """(regular, global) lists, read once: [(target, encoded ref)], [(target, 4CC, hash)]."""
        if self._relocs is None:
            last = len(self.base) - 1
            start = self.base[last] + self.comp_size[last]
            start += (-start) & 3
            regular_raw = self._until_ffffffff(start)
            regular = [self.slot(p) for p in regular_raw]
            gstart = start + 4 * len(regular_raw) + 4
            glob = []
            off = gstart
            while self.u32(off) != 0xFFFFFFFF:
                p, tag, _, name_hash = struct.unpack("<I4sII", self.rd(off, 16))
                glob.append((self.slot(p), tag, name_hash))
                off += 16
            self._relocs = (regular, glob)
        return self._relocs

    def _until_ffffffff(self, off):
        out = []
        while True:
            n = min(1 << 16, self.entry.size - off) & ~3
            if n <= 0:
                raise ValueError(f"relocation list runs past the apk end at 0x{off:X} (damaged pack?)")
            vals = struct.unpack(f"<{n // 4}I", self.rd(off, n))
            for v in vals:
                if v == 0xFFFFFFFF:
                    return out
                out.append(v)
            off += n

    def ref_address(self, encoded):
        comp, index = encoded >> 26, encoded & 0x3FFFFFF
        if comp == NAME_COMPONENT:
            return self.names_at + 4 * index
        return self.base[comp] + 4 * index

    # --- standalone file --------------------------------------------------
    def wrap_file(self, f):
        regular, glob = self.relocations()
        parts = f.parts
        # The archive is used with every relocation applied (slot = absolute
        # target); bytes that become relocation entries are rewritten below.
        comps = [bytearray(self.rd(s, e - s)) for (s, e) in parts]
        mine = []
        for target in regular:
            for k, (s, e) in enumerate(parts):
                if s <= target < e:
                    raw = struct.unpack_from("<I", comps[k], target - s)[0]
                    struct.pack_into("<I", comps[k], target - s, self.ref_address(raw))
                    break
            if self.file_at(target) is f:
                mine.append(target)
        patches = []
        for target in mine:
            raw = self.u32(target)  # unrelocated slot value
            patches.append((target, 0, raw))
        for target, tag, name_hash in glob:
            if self.file_at(target) is f:
                patches.append((target, 1, (tag, name_hash)))
        patches.sort(key=lambda p: p[0])

        c0_start, c0_end = parts[0]
        c1 = parts[1] if len(parts) > 1 else None
        comp_base = [0, (c0_end - c0_start) + 4]
        img = comps[0]
        relocated = bytes(img)  # global entries keep the relocated value
        ints, exts, globs = [], [], []
        for target, kind, info in patches:
            toff = target - c0_start
            if kind == 1:
                tag, name_hash = info
                value = struct.unpack_from("<I", relocated, toff)[0]
                globs.append((tag.rstrip(b"\x00").ljust(4, b"\x00"), name_hash, toff))
                struct.pack_into("<I", img, toff, value)
                continue
            raw = info
            ref = self.ref_address(raw)
            comp = raw >> 26
            internal = (c0_start < ref < c0_end) or (c1 is not None and c1[0] <= ref < c1[1])
            if internal:
                value = comp_base[comp] + (ref - parts[comp][0]) - toff
                ints.append(toff)
                struct.pack_into("<i", img, toff, value)
            else:
                if comp == NAME_COMPONENT:
                    tag, name_hash = b"NAME", 0
                else:
                    other = self.file_at(ref)
                    if other is None:
                        raise ValueError(f"reference 0x{ref:X} is in no file")
                    tag = other.type.encode("utf-8").ljust(4, b"\x00")
                    name_hash = other.name_hash
                exts.append((tag, name_hash, toff))
                struct.pack_into("<I", img, toff, raw)
        return layout_wrap(self.hash, comps, exts, ints, globs)


def _align16(n):
    return (n + 15) & ~15


def layout_wrap(apk_hash, comps, exts, ints, globs):
    n = len(comps)
    pt = _align16(20 + 8 * n)
    ext_off = _align16(pt + 24)
    int_off = _align16(ext_off + 16 * len(exts))
    gl_off = _align16(int_off + 4 * len(ints))
    c0 = _align16(gl_off + 16 * len(globs))
    offsets = [c0]
    if n > 1:
        offsets.append(c0 + len(comps[0]) + 4)
    out = bytearray()
    out += b"WRAP" + struct.pack("<4I", apk_hash, pt - 8, n, 4)
    for i, c in enumerate(comps):
        field = len(out) + 4
        out += struct.pack("<2I", len(c), offsets[i] - field)
    out += PAD * (pt - len(out))
    out += struct.pack("<6I", len(exts), ext_off - (pt + 4), len(ints), int_off - (pt + 12),
                       len(globs), gl_off - (pt + 20))
    out += PAD * (ext_off - len(out))
    for tag, name_hash, toff in exts:
        field = len(out) + 12
        out += tag + struct.pack("<Iii", name_hash, -1, c0 + toff - field)
    out += PAD * (int_off - len(out))
    for toff in ints:
        out += struct.pack("<i", c0 + toff - len(out))
    out += PAD * (gl_off - len(out))
    for tag, name_hash, toff in globs:
        field = len(out) + 12
        out += tag + struct.pack("<I", name_hash) + b"GLBL" + struct.pack("<i", c0 + toff - field)
    out += PAD * (c0 - len(out))
    out += comps[0]
    if n > 1:
        out += b"PHYS" + comps[1]
    if n > 2:
        raise ValueError("files with more than two components are not supported")
    return bytes(out)


def extract_wrap(pack_path, apk_hash, type_, name_hash):
    """-> (file name, bytes) of one APKF member as a standalone WRAP file."""
    pack = Pack(pack_path)
    apk = Apk(pack, pack.find(apk_hash, 25))
    f = apk.find(type_, name_hash)
    return f.out_name, apk.wrap_file(f)


def extract_entry(pack_path, name_hash, type_id):
    pack = Pack(pack_path)
    return pack.data(pack.find(name_hash, type_id))


if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    p.add_argument("pack")
    p.add_argument("--list", action="store_true")
    a = p.parse_args()
    pk = Pack(a.pack)
    for e in pk.entries:
        print(e)
