"""megacity.gbmap (resource type 12, class gb_map): the city street graph.

Pedestrians spawn and walk on it and traffic drives on it, so replacing it
is how Los Santos gets its own NPCs (see build_gbmap.py).

Mashed container, the same as every mashable resource:
    +0x00 u32 0x12345678, +0x04 u32 0x10 (image start), +0x08 u32 image end,
    +0x0C u32 0 (1 once loaded); image [0x10, end); then the COUNT STREAM:
    one u32 per vector in unmash order. The loader takes vector sizes from
    that stream, not from the inline count (they agree in shipped files).
Unmash (FUN_0075a010 -> FUN_007dee40, simulated exactly by `layout`): a
cursor starts at 0x10, every allocation is aligned to 4 (u16 arrays to 2),
a vector is {rt, count, ptr, capacity}; a pointer vector allocates the
pointer array, then each pointee (and its own vectors) in order. `rt` is
set to (cursor after the data) - &vector. The layout was checked against
the live process: all 9663 pointers and 5150 rt values match.

gb_map root (0x94, at 0x10):
    +0x04 u32 12, +0x08 u32 0x4fccc (unused by the traffic/ped code)
    +0x0C vector<vec3>          verts      intersection points (y used)
    +0x1C vector<segment*>      segs       0x38 + 2 sub-vectors of u16
    +0x30 vector<corner*>       corners    0x14
    +0x44 vector<?*>            unused     0x24 + 2 u16 vectors, empty
    +0x58 vector<node*>         nodes      0x14 + u16 vector (segments)
    +0x6C vector<profile*>      profiles   0x24
    +0x2C/+0x40/+0x54/+0x68/+0x7C u8 1 (after each vector)
    +0x80..+0x88 runtime (FLT_MAX), +0x8C u32 name hash, +0x90 u32 12

segment (0x38):
    +0x00 u16 vert a, +0x02 u16 vert b
    +0x04 u16 node at a, +0x06 u16 node at b (index into nodes, or 0xFFFF)
    +0x08 u16 corner at a, side 0 (this segment is its s2: leaves a)
    +0x0A u16 corner at a, side 1 (this segment is its s1: arrives at a)
    +0x0C u16 corner at b, side 0 (s1: arrives at b)
    +0x0E u16 corner at b, side 1 (s2: leaves b)     0xFFFF = no sidewalk
    +0x10 u16 profile
    +0x14 u8 side-0 flags, +0x15 u8 side-1 flags (bit0 no sidewalk: the
          loader sets it when a corner is missing; bit1 closed end)
    +0x16 u8, +0x17 u8 (1/2), +0x18 u8 1, +0x19 u8 bits, +0x1A/+0x1C u16,
    +0x1E u8 13|15 (bit1: one lane less), +0x1F/+0x20 i8 traffic light
          phase at a / b (-1 none)
    +0x24/+0x28 runtime, +0x2C u32 1|2, +0x30 u16 own index, +0x32 u8,
    +0x33 u8 runtime, +0x34 ptr to the two sub-vectors (per-side lane
          lists, filled at runtime by FUN_005a0f70)
corner (0x14): block-sidewalk turn at vertex v from s1 into s2, s2 being the
    next segment CLOCKWISE (atan2(dz, dx) order) after s1 around v.
    +0x00 u16 s1, +0x02 u16 s2, +0x04 u16 v, +0x06 i8 s1 dir (1: s1 ends
    at v), +0x07 i8 s2 dir (1: s2 starts at v), +0x08 u16 0, +0x0A u8 1,
    +0x0B u8 flags (2: widths differ, 4: no segments, 8: a zero-width road),
    +0x0C/+0x10 runtime (geometry built lazily by FUN_007b69e0)
node (0x14): +0x00 u16 vert, +0x02 u8 traffic light phases (0 none),
    +0x04 vector<u16> incident segments
profile (0x24): +0x00 f32 median half-width, +0x04 f32 lane width per side
    (lanes = width / 5), +0x08 f32 sidewalk width - 0.2, +0x0C u16 0xFFFF,
    +0x11 u8 1 one-way / 2 two-way, +0x12 i8 one-way side, +0x13..+0x16
    u8 1, +0x18/+0x1C f32 5.0, +0x20 u8 flags (bit1 drivable)

    py -3 wos_gbmap.py <file>          # parse, re-serialize, compare
"""
import struct
import sys

MAGIC = 0x12345678
ROOT_SIZE = 0x94
SEG_SIZE = 0x38
CORNER_SIZE = 0x14
NODE_SIZE = 0x14
PROFILE_SIZE = 0x24
ROOT_VECTORS = (0x0C, 0x1C, 0x30, 0x44, 0x58, 0x6C)


class GbMap:
    def __init__(self):
        self.root = bytearray(ROOT_SIZE)
        self.verts = []        # (x, y, z)
        self.segs = []         # bytearray(0x38)
        self.seg_sub = []      # ([u16...], [u16...]) per segment
        self.corners = []      # bytearray(0x14)
        self.nodes = []        # (bytearray(0x14), [u16 segments])
        self.profiles = []     # bytearray(0x24)
        self.caps = {}         # root vector offset -> capacity (round trip)
        self.trailer_extra = b''


def _align(v, a):
    return (v + a - 1) & ~(a - 1)


class _Counts:
    def __init__(self, data, start):
        self.d, self.pos = data, start

    def __call__(self):
        self.pos = _align(self.pos, 4)
        v = struct.unpack_from('<I', self.d, self.pos)[0]
        self.pos += 4
        return v


def parse(data):
    mag, start, end, _ = struct.unpack_from('<4I', data, 0)
    if mag != MAGIC or start != 0x10:
        raise ValueError('not a mashed resource')
    g = GbMap()
    count = _Counts(data, end)
    cur = [0x10]

    def alloc(n, a=4):
        cur[0] = _align(cur[0], a)
        o = cur[0]
        cur[0] += n
        if cur[0] > end:
            raise ValueError('image overrun')
        return o

    root = alloc(ROOT_SIZE)
    g.root[:] = data[root:root + ROOT_SIZE]
    for v in ROOT_VECTORS:
        g.caps[v] = struct.unpack_from('<I', data, root + v + 12)[0]

    n = count()
    o = alloc(12 * n) if n else 0
    g.verts = [struct.unpack_from('<3f', data, o + 12 * k) for k in range(n)]

    n = count()
    if n:
        alloc(4 * n)
    for _ in range(n):
        s = alloc(SEG_SIZE)
        g.segs.append(bytearray(data[s:s + SEG_SIZE]))
        sub = alloc(0x20)
        lists = []
        for k in range(2):
            c = count()
            if c:
                o = alloc(2 * c, 2)
                lists.append(list(struct.unpack_from(f'<{c}H', data, o)))
            else:
                lists.append([])
        g.seg_sub.append(tuple(lists))

    n = count()
    if n:
        alloc(4 * n)
    for _ in range(n):
        c = alloc(CORNER_SIZE)
        g.corners.append(bytearray(data[c:c + CORNER_SIZE]))

    if count():
        raise ValueError('vector at root+0x44 is not empty: unsupported')

    n = count()
    if n:
        alloc(4 * n)
    for _ in range(n):
        o = alloc(NODE_SIZE)
        c = count()
        segs = []
        if c:
            p = alloc(2 * c, 2)
            segs = list(struct.unpack_from(f'<{c}H', data, p))
        g.nodes.append((bytearray(data[o:o + NODE_SIZE]), segs))

    n = count()
    if n:
        alloc(4 * n)
    for _ in range(n):
        o = alloc(PROFILE_SIZE)
        g.profiles.append(bytearray(data[o:o + PROFILE_SIZE]))
    if cur[0] > end:
        raise ValueError('image overrun')
    g.image_end = end
    g.trailer_extra = data[count.pos:]
    return g


def _vec(buf, at, count, cap=None):
    cap = count if cap is None else max(cap, count)
    struct.pack_into('<4I', buf, at, 0, count, 1 if count else 0, cap if count else 0)


def serialize(g, keep_caps=False):
    """Lay the map out exactly the way the loader will read it back."""
    img = bytearray(16)
    counts = []
    cover = []   # (start, end) of every byte range the writer owns

    def alloc(n, a=4):
        pad = -len(img) % a
        img.extend(b'\0' * pad)
        o = len(img)
        img.extend(b'\0' * n)
        cover.append((o, o + n))
        return o

    cap = (lambda v, n: g.caps.get(v, n)) if keep_caps else (lambda v, n: n)
    root = alloc(ROOT_SIZE)
    img[root:root + ROOT_SIZE] = g.root
    rv = lambda k, n: _vec(img, root + ROOT_VECTORS[k], n, cap(ROOT_VECTORS[k], n))

    n = len(g.verts)
    rv(0, n)
    counts.append(n)
    if n:
        o = alloc(12 * n)
        for k, p in enumerate(g.verts):
            struct.pack_into('<3f', img, o + 12 * k, *p)

    n = len(g.segs)
    rv(1, n)
    counts.append(n)
    if n:
        alloc(4 * n)
    for k, s in enumerate(g.segs):
        o = alloc(SEG_SIZE)
        img[o:o + SEG_SIZE] = s
        struct.pack_into('<I', img, o + 0x34, 1)
        sub = alloc(0x20)
        for j, lst in enumerate(g.seg_sub[k]):
            counts.append(len(lst))
            _vec(img, sub + 0x10 * j, len(lst))
            if lst:
                p = alloc(2 * len(lst), 2)
                struct.pack_into(f'<{len(lst)}H', img, p, *lst)

    n = len(g.corners)
    rv(2, n)
    counts.append(n)
    if n:
        alloc(4 * n)
    for c in g.corners:
        o = alloc(CORNER_SIZE)
        img[o:o + CORNER_SIZE] = c

    rv(3, 0)
    counts.append(0)

    n = len(g.nodes)
    rv(4, n)
    counts.append(n)
    if n:
        alloc(4 * n)
    for hdr, segs in g.nodes:
        o = alloc(NODE_SIZE)
        img[o:o + NODE_SIZE] = hdr
        counts.append(len(segs))
        cap_old = struct.unpack_from('<I', hdr, 0x10)[0] if keep_caps else 0
        _vec(img, o + 4, len(segs), cap_old)
        if segs:
            p = alloc(2 * len(segs), 2)
            struct.pack_into(f'<{len(segs)}H', img, p, *segs)

    n = len(g.profiles)
    rv(5, n)
    counts.append(n)
    if n:
        alloc(4 * n)
    for pr in g.profiles:
        o = alloc(PROFILE_SIZE)
        img[o:o + PROFILE_SIZE] = pr

    img.extend(b'\0' * (-len(img) % 16))
    end = len(img)
    struct.pack_into('<4I', img, 0, MAGIC, 0x10, end, 0)
    img.extend(struct.pack(f'<{len(counts)}I', *counts))
    return bytes(img), cover


def main():
    data = open(sys.argv[1], 'rb').read()
    g = parse(data)
    print(f'verts {len(g.verts)} segs {len(g.segs)} corners {len(g.corners)} nodes {len(g.nodes)} '
          f'profiles {len(g.profiles)} image end {g.image_end:#x} trailer extra {len(g.trailer_extra)} B')
    out, cover = serialize(g, keep_caps=True)
    end = struct.unpack_from('<I', out, 8)[0]
    diff = 0
    for a, b in cover:
        if out[a:b] != data[a:b]:
            diff += sum(1 for k in range(a, b) if out[k] != data[k])
    print(f'round trip: image end {end:#x} vs {g.image_end:#x}; differing owned bytes {diff}; '
          f'count stream {"same" if out[end:] == data[g.image_end:g.image_end + len(out) - end] else "DIFFERS"}')


if __name__ == '__main__':
    main()
