"""
WoS `.tex`: read a texture, and author one from a template.

A `.tex` is the same WRAP container as a `.mesh` -- header, IMG and PHYS
components, and the patch tables that make it relocatable -- so it reuses
`wrapmesh.parse_container` and `wrapmesh.rebuild`. Only the start of IMG
differs, and it is a flat header with no pointers in it:

    +0x00  pointer to the filename
    +0x0C  name hash
    +0x18  width
    +0x1C  height
    +0x20  depth: 1 for a normal texture, 6 for a cube map
    +0x24  mip count
    +0x28  pixel format, a fourcc ("DXT1"/"DXT5") or a D3DFMT number

PHYS holds the mip chain back to back, largest first, with no per-level header
-- each level's size follows from the dimensions and the format, and levels
below 4x4 still occupy a whole block. Confirmed across every shipped texture:
of 1057, 1050 match this exactly, 5 use uncompressed D3DFMT numbers, and the
remaining 2 are cube maps whose PHYS is exactly six times one chain, which is
what `depth` says.

Authoring reuses `wrapmesh.rebuild`, which is not mesh-specific once the mesh
loop has nothing to iterate: it moves regions, then fixes every pointer,
relocation entry and component size. So a texture of a different size than the
template is fine -- PHYS grows and the container follows.
"""

import struct

import wrapmesh

# offsets into the IMG component
OFF_NAME_HASH = 0x0C
OFF_WIDTH = 0x18
OFF_HEIGHT = 0x1C
OFF_DEPTH = 0x20
OFF_MIPS = 0x24
OFF_FORMAT = 0x28
HEADER_SIZE = 0x40

BLOCK_BYTES = {b"DXT1": 8, b"DXT3": 16, b"DXT5": 16}


def level_size(width, height, fourcc):
    """Bytes one mip level occupies. Sub-4x4 levels still cost a full block."""
    n = BLOCK_BYTES.get(fourcc)
    if n is None:
        raise ValueError(f"not a block-compressed format: {fourcc!r}")
    return max(1, (width + 3) // 4) * max(1, (height + 3) // 4) * n


def chain_size(width, height, fourcc, mips):
    total = 0
    w, h = width, height
    for _ in range(mips):
        total += level_size(w, h, fourcc)
        w, h = max(1, w // 2), max(1, h // 2)
    return total


def full_mip_count(width, height):
    """How many levels it takes to get down to 1x1."""
    n = 1
    w, h = width, height
    while w > 1 or h > 1:
        w, h = max(1, w // 2), max(1, h // 2)
        n += 1
    return n


class Tex:
    def __init__(self, data):
        self.data = data
        self.container, _ = wrapmesh.parse_container(data)
        o = self.container.img.target
        self.img_offset = o
        self.name_hash, = struct.unpack_from("<I", data, o + OFF_NAME_HASH)
        (self.width, self.height, self.depth,
         self.mips) = struct.unpack_from("<4I", data, o + OFF_WIDTH)
        self.fourcc = data[o + OFF_FORMAT:o + OFF_FORMAT + 4]

    @property
    def compressed(self):
        return self.fourcc in BLOCK_BYTES

    @property
    def pixels(self):
        p = self.container.phys
        return self.data[p.target:p.target + self.container.phys_size]

    def levels(self):
        """-> [bytes] per mip, largest first (one face only for cube maps)."""
        out = []
        pos = 0
        raw = self.pixels
        w, h = self.width, self.height
        for _ in range(self.mips):
            n = level_size(w, h, self.fourcc)
            out.append(raw[pos:pos + n])
            pos += n
            w, h = max(1, w // 2), max(1, h // 2)
        return out

    def __repr__(self):
        f = (self.fourcc.decode() if self.compressed
             else f"fmt{struct.unpack('<I', self.fourcc)[0]}")
        cube = " cube" if self.depth == 6 else ""
        return (f"<Tex 0x{self.name_hash:08X} {self.width}x{self.height} {f} "
                f"{self.mips} mips{cube}>")


def build(template_bytes, pixels, width, height, fourcc, mips=None,
          depth=1, name_hash=None):
    """Author a .tex carrying `pixels`, using `template_bytes` as the shell.

    The template supplies the container, the name pointer and the patch tables;
    everything that describes the image is overwritten. `pixels` must be the
    whole mip chain, largest first.
    """
    if fourcc not in BLOCK_BYTES:
        raise ValueError(f"can only write block-compressed textures, "
                         f"not {fourcc!r}")
    if mips is None:
        mips = full_mip_count(width, height)
    want = chain_size(width, height, fourcc, mips) * depth
    if len(pixels) != want:
        raise ValueError(f"{width}x{height} {fourcc.decode()} x{mips} mips "
                         f"needs {want} bytes, got {len(pixels)}")

    t = Tex(template_bytes)
    m = t.container
    # PHYS is not in the container's own region list -- it is a component, not
    # a structure -- so name it here for rebuild to move
    m.regions.append(wrapmesh.Region("pixels", m.phys.target, m.phys_size))
    out = bytearray(wrapmesh.rebuild(m, {"pixels": pixels}))

    o = t.img_offset          # IMG precedes PHYS, so its offset is unmoved
    struct.pack_into("<4I", out, o + OFF_WIDTH, width, height, depth, mips)
    out[o + OFF_FORMAT:o + OFF_FORMAT + 4] = fourcc
    if name_hash is not None:
        struct.pack_into("<I", out, o + OFF_NAME_HASH, name_hash)

    check = Tex(bytes(out))
    if (check.width, check.height, check.mips, check.fourcc,
            check.depth) != (width, height, mips, fourcc, depth):
        raise AssertionError("the written header does not read back")
    if check.pixels != pixels:
        raise AssertionError("the written pixels do not read back")
    return bytes(out)
