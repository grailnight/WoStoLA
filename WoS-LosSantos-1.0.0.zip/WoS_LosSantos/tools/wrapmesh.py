"""
wrap.mesh: structural read -> rebuild -> resize.

Format notes established by validation over the extracted corpus:

  * every in-file pointer is SELF-RELATIVE: absolute = field_pos + stored_u32.
  * the file carries its own relocation list (the patch table's "internal"
    list). Entry i lives at int_base + 4*i and is itself self-relative; its
    target is the POSITION of a pointer field the loader must fix up.
    Validated: that set is exactly the set of internal pointers reachable by
    walking the structures (3347/3347 parseable files, exact match).
  * the fixed head chain (wrap header + patch table + ext patch list) is NOT
    in the relocation list -- the loader walks it by structure.
  * pointers left out of the relocation list and holding garbage are fixed at
    load time from the EXTERNAL patch list, whose entries are
    (4CC tag, name hash, expected index, self-relative ptr to the field).
    Tags seen: NAME, MAT, SKEL, MESH.
  * component 0 ("IMG") is the CPU-side structure block and begins with the
    model header; component 1 ("PHYS") holds the vertex/index buffers. Do not
    look for the model header via the global pointer: that only coincides
    with the image base when global_count == 0.
  * structures are not reliably 4-aligned: a mesh_info can start 2-aligned
    when it follows a u16 bone palette of odd length.
"""

import struct
from dataclasses import dataclass, field

DECL_END = bytes([0xFF, 0x00, 0x00, 0x00, 0x11, 0x00, 0x00, 0x00])
PAD_BYTE = 0xA1


@dataclass
class Ptr:
    pos: int
    raw: int

    @property
    def target(self):
        return self.pos + self.raw

    def __repr__(self):
        return f"Ptr(@0x{self.pos:04X}->0x{self.target:04X})"


@dataclass
class Region:
    name: str
    start: int
    size: int

    @property
    def end(self):
        return self.start + self.size


class Cursor:
    def __init__(self, data):
        self.data = data
        self.pos = 0

    def seek(self, pos):
        self.pos = pos

    def u16(self):
        v = struct.unpack_from("<H", self.data, self.pos)[0]
        self.pos += 2
        return v

    def u32(self):
        v = struct.unpack_from("<I", self.data, self.pos)[0]
        self.pos += 4
        return v

    def f32(self):
        v = struct.unpack_from("<f", self.data, self.pos)[0]
        self.pos += 4
        return v

    def ptr(self):
        p = self.pos
        return Ptr(p, self.u32())

    def align(self, n):
        self.pos += (-self.pos) & (n - 1)


@dataclass
class WrapMesh:
    data: bytes = b""
    magic: int = 0
    pcapk_hash: int = 0
    patch_table: Ptr = None
    component_count: int = 0
    components: Ptr = None
    components_raw: list = field(default_factory=list)  # (size_pos, size, Ptr)
    ext_count: int = 0
    ext: Ptr = None
    int_count: int = 0
    int_: Ptr = None
    global_count: int = 0
    global_: Ptr = None
    int_patches: list = field(default_factory=list)
    ext_patches: list = field(default_factory=list)
    model: dict = field(default_factory=dict)
    meshes: list = field(default_factory=list)
    regions: list = field(default_factory=list)

    @property
    def img(self):
        return self.components_raw[0][2]

    @property
    def img_size(self):
        return self.components_raw[0][1]

    @property
    def phys(self):
        return self.components_raw[1][2] if self.component_count > 1 else None

    @property
    def phys_size(self):
        return self.components_raw[1][1] if self.component_count > 1 else 0

    def reloc_positions(self):
        base = self.int_.target
        return [base + 4 * i + v for i, v in enumerate(self.int_patches)]

    def reloc_entry_pos(self, i):
        return self.int_.target + 4 * i

    def head_pointers(self):
        out = [self.patch_table, self.components, self.ext, self.int_,
               self.global_]
        out += [p for (_, _, p) in self.components_raw]
        out += [p for (_, _, _, p) in self.ext_patches]
        return [p for p in out if p is not None]


def parse_container(data):
    """Read the WRAP envelope every resource shares; -> (record, cursor).

    Meshes, materials and textures are all the same container: the header, the
    IMG/PHYS components, and the patch tables that make it relocatable. Only
    what sits at the start of IMG differs. `parse` continues from here into the
    mesh's model header; `wos_tex` reads a texture's instead.
    """
    m = WrapMesh(data=data)
    c = Cursor(data)

    m.magic = c.u32()
    m.pcapk_hash = c.u32()
    m.patch_table = c.ptr()
    m.component_count = c.u32()
    m.components = c.ptr()
    for _ in range(m.component_count):
        size_pos = c.pos
        size = c.u32()
        m.components_raw.append((size_pos, size, c.ptr()))
    c.align(16)
    m.regions.append(Region("head", 0, c.pos))

    c.seek(m.patch_table.target)
    s = c.pos
    m.ext_count = c.u32()
    m.ext = c.ptr()
    m.int_count = c.u32()
    m.int_ = c.ptr()
    m.global_count = c.u32()
    m.global_ = c.ptr()
    c.align(16)
    m.regions.append(Region("patch_table", s, c.pos - s))

    if m.ext_count:
        c.seek(m.ext.target)
        s = c.pos
        for _ in range(m.ext_count):
            tag = m.data[c.pos:c.pos + 4]
            c.pos += 4
            name_hash = c.u32()
            expected_idx = c.u32()
            m.ext_patches.append((tag, name_hash, expected_idx, c.ptr()))
        m.regions.append(Region("ext_patches", s, c.pos - s))

    if m.int_count:
        c.seek(m.int_.target)
        s = c.pos
        m.int_patches = [c.u32() for _ in range(m.int_count)]
        m.regions.append(Region("int_patches", s, c.pos - s))

    if m.global_count:
        m.regions.append(Region("global_table", m.global_.target,
                                16 * m.global_count))
    return m, c


def parse(data):
    m, c = parse_container(data)

    c.seek(m.img.target)
    s = c.pos
    model = {}
    model["filename_ptr"] = c.ptr()
    model["filename_hash"] = c.u32()
    model["parsed_flag"] = c.u32()
    model["mesh_count"] = c.u32()
    model["mesh_table"] = c.ptr()
    model["skeleton"] = c.ptr()
    model["ext_mesh_count"] = c.u32()
    model["ext_mesh_table"] = c.ptr()
    model["offset"] = [c.f32() for _ in range(4)]
    model["bbox"] = [c.f32() for _ in range(4)]
    m.model = model
    m.regions.append(Region("model_header", s, c.pos - s))

    mt = model["mesh_table"].target
    m.regions.append(Region("mesh_table", mt, 8 * model["mesh_count"]))
    for i in range(model["mesh_count"]):
        c.seek(mt + i * 8)
        mi = {"index": i, "parsed_flag": c.u32(), "info_ptr": c.ptr()}
        c.seek(mi["info_ptr"].target)
        s = c.pos
        mi["offset"] = [c.f32() for _ in range(4)]
        mi["bbox"] = [c.f32() for _ in range(4)]
        mi["material"] = c.ptr()
        mi["bone_palette"] = c.ptr()
        mi["bone_palette_count"] = c.u32()
        mi["vertex_buffer"] = c.ptr()
        mi["unknown1"] = c.u32()
        mi["vertex_count_pos"] = c.pos
        mi["vertex_count"] = c.u32()
        mi["unknown2"] = c.u32()
        mi["index_buffer"] = c.ptr()
        mi["unknown3"] = c.u32()
        mi["index_count_pos"] = c.pos
        mi["index_count"] = c.u32()
        mi["index_size"] = c.u32()
        mi["schema_table"] = c.ptr()
        m.regions.append(Region(f"mesh{i}_info", s, c.pos - s))

        if mi["bone_palette"].raw:
            m.regions.append(Region(f"mesh{i}_bone_palette",
                                    mi["bone_palette"].target,
                                    2 * mi["bone_palette_count"]))

        c.seek(mi["schema_table"].target)
        s = c.pos
        mi["vertex_stride"] = c.u32()
        mi["vertex_schema"] = c.ptr()
        mi["schema_unknown"] = c.u32()
        m.regions.append(Region(f"mesh{i}_schema_table", s, c.pos - s))

        c.seek(mi["vertex_schema"].target)
        s = c.pos
        decls = []
        while True:
            peek = m.data[c.pos:c.pos + 8]
            if len(peek) < 8:
                break
            c.pos += 8
            if peek == DECL_END:
                break
            decls.append(struct.unpack("<HHBBBB", peek))
        mi["decls"] = decls
        m.regions.append(Region(f"mesh{i}_vertex_decl", s, c.pos - s))

        m.regions.append(Region(f"mesh{i}_vertex_buffer",
                                mi["vertex_buffer"].target,
                                mi["vertex_stride"] * mi["vertex_count"]))
        m.regions.append(Region(f"mesh{i}_index_buffer",
                                mi["index_buffer"].target,
                                mi["index_size"] * mi["index_count"]))
        m.meshes.append(mi)

    return m


def all_pointers(m):
    """Every pointer field, as {pos: target}. Relocatable ones come from the
    file's own relocation list; the head chain is added structurally."""
    ptrs = {}
    for p in m.head_pointers():
        ptrs[p.pos] = p.target
    for pos in m.reloc_positions():
        raw = struct.unpack_from("<I", m.data, pos)[0]
        ptrs[pos] = pos + raw
    return ptrs


def rebuild(m, edits=None):
    """
    Re-serialize the file. `edits` maps region name -> new bytes; a region may
    change size, in which case everything after it shifts and every pointer,
    relocation entry, component size and element count is recomputed.

    With edits=None this reproduces the input byte for byte.
    """
    edits = dict(edits or {})
    regions = {r.name: r for r in m.regions}
    for name in edits:
        if name not in regions:
            raise KeyError(f"unknown region {name!r}")

    moved = sorted((regions[n] for n in edits), key=lambda r: r.start)
    for a, b in zip(moved, moved[1:]):
        if a.end > b.start:
            raise ValueError(f"overlapping edits: {a.name} / {b.name}")

    deltas = []
    cum = 0
    for r in moved:
        cum += len(edits[r.name]) - r.size
        deltas.append((r.end, cum))

    def remap(off):
        d = 0
        for boundary, cumdelta in deltas:
            if off >= boundary:
                d = cumdelta
        return off + d

    out = bytearray()
    cursor = 0
    for r in moved:
        out += m.data[cursor:r.start]
        out += edits[r.name]
        cursor = r.end
    out += m.data[cursor:]

    ptrs = all_pointers(m)
    ext_patched = {p.target for (_, _, _, p) in m.ext_patches}
    for pos, target in ptrs.items():
        if pos in ext_patched:
            continue  # holds a load-time placeholder, not a real offset
        new_pos = remap(pos)
        struct.pack_into("<I", out, new_pos,
                         (remap(target) - new_pos) & 0xFFFFFFFF)

    reloc_fields = m.reloc_positions()
    for i in range(len(m.int_patches)):
        entry_pos = remap(m.reloc_entry_pos(i))
        struct.pack_into("<I", out, entry_pos,
                         (remap(reloc_fields[i]) - entry_pos) & 0xFFFFFFFF)

    for size_pos, size, ptr in m.components_raw:
        struct.pack_into("<I", out, remap(size_pos),
                         remap(ptr.target + size) - remap(ptr.target))

    for mi in m.meshes:
        i = mi["index"]
        vb = edits.get(f"mesh{i}_vertex_buffer")
        if vb is not None:
            if not mi["vertex_stride"] or len(vb) % mi["vertex_stride"]:
                raise ValueError(f"mesh{i}: vertex buffer of {len(vb)} bytes is "
                                 f"not a multiple of stride "
                                 f"{mi['vertex_stride']}")
            struct.pack_into("<I", out, remap(mi["vertex_count_pos"]),
                             len(vb) // mi["vertex_stride"])
        ib = edits.get(f"mesh{i}_index_buffer")
        if ib is not None:
            if not mi["index_size"] or len(ib) % mi["index_size"]:
                raise ValueError(f"mesh{i}: index buffer of {len(ib)} bytes is "
                                 f"not a multiple of index size "
                                 f"{mi['index_size']}")
            struct.pack_into("<I", out, remap(mi["index_count_pos"]),
                             len(ib) // mi["index_size"])

    return bytes(out)
